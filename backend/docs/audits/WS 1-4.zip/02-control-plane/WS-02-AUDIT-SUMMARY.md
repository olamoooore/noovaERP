# WS-02 Control Plane — Audit Summary

**Audit Date:** 2026-04-24  
**Workstream:** WS-02 (Control Plane Projection)  
**Gate:** G2 (Runtime Access Truth)  
**Verdict:** **HIGH RISK** — 1 CRITICAL issue blocking closure

---

## Quick Facts

| Metric | Value |
|--------|-------|
| **Critical Issues** | 1 |
| **High Issues** | 1 |
| **Medium Issues** | 0 |
| **Low Issues** | 0 |
| **Verified Safe Areas** | 11 |
| **Files Inspected** | 11 |
| **Entry Points Covered** | 6 |
| **Verdict** | HIGH RISK |
| **Closure Status** | BLOCKED |

---

## The Issue (CRITICAL-001)

**Subscription creation does NOT trigger entitlement rebuild.**

When a new subscription is created via `SubscriptionService::createSubscription()`:

1. ✅ Subscription row is written
2. ✅ Plan version is linked
3. ❌ **Entitlements are NOT rebuilt**
4. ❌ New tenant has zero entitlements
5. ❌ All feature checks fail (403 Forbidden)

**Impact:** New tenants cannot use the product until entitlements are manually rebuilt.

**Severity:** CRITICAL — blocks new tenant onboarding

---

## What Works (11 Verified Areas)

- ✅ Plan change rebuild trigger (correct)
- ✅ Configuration selection rebuild trigger (correct)
- ✅ Cache invalidation atomicity (correct)
- ✅ Cache key includes tenant context (correct)
- ✅ Cache TTL and invalidation (correct)
- ✅ Middleware enforcement consistency (correct)
- ✅ Module-specific enforcement (correct)
- ✅ Tenant context resolution (correct)
- ✅ Rebuild resolution algorithm (correct)
- ✅ Test coverage (correct, but incomplete)
- ✅ Legacy feature table is retired (correct)

---

## What's Broken (2 Issues)

### CRITICAL-001 — Subscription Creation Missing Rebuild

**File:** `backend/app/SuperAdmin/Application/SubscriptionService.php`  
**Method:** `createSubscription()` (lines 24-60)

**Problem:**
```php
// ❌ NO rebuild call
return DB::transaction(function () use (...) {
    $subscription = Subscription::create([...]);
    if ($status === 'active') {
        $this->billingService->generateInvoice($subscription, $billingInterval);
    }
    $this->auditLogger->log(...);
    return $subscription;
    // Missing: $this->entitlements->rebuild($tenantId, $adminId, 'subscription_created');
});
```

**Contrast (PlanChangeService — CORRECT):**
```php
// ✅ Rebuild IS called
$this->entitlements->rebuild(
    $planChange->tenant_id,
    $adminId,
    'plan_change_applied',
);
```

**Fix:** Add rebuild call after subscription is created.

---

### HIGH-001 — Seeder Bypasses Rebuild

**File:** `backend/database/seeders/Subscription360Seeder.php`  
**Lines:** 109-130

**Problem:** Demo seeder creates subscriptions directly without triggering rebuild.

**Impact:** Demo tenants have empty entitlements.

**Fix:** Add rebuild call after `Subscription::create()`.

---

## Blocking Gates

- **G2 (Runtime Access Truth):** Cannot be satisfied while new tenants have no entitlements
- **G3 (Domain Ownership Truth):** Blocked on G2
- **G4 (Channel Orchestration):** Blocked on G3
- **G5 (Financial Integrity):** Blocked on G4
- **G6 (Cutover Readiness):** Blocked on G5

---

## Next Steps

1. **Add rebuild trigger to SubscriptionService::createSubscription()**
   - Add: `$this->entitlements->rebuild($tenantId, $adminId, 'subscription_created');`
   - Location: After `$this->auditLogger->log()` call

2. **Add rebuild trigger to Subscription360Seeder**
   - Add: `app(EntitlementService::class)->rebuild($tenantId, null, 'seeder_subscription_created');`
   - Location: After `Subscription::create()` call

3. **Add test case to ControlPlaneProjectionTest**
   - Test: `test_subscription_creation_triggers_rebuild()`
   - Verify: New subscription → entitlements populated → feature checks pass

4. **Re-run audit after fixes**
   - Verify CRITICAL-001 is resolved
   - Verify HIGH-001 is resolved
   - Confirm WS-02 can be marked CLOSED

---

## Evidence Summary

**Full Trace for CRITICAL-001:**

```
SubscriptionService::createSubscription()
  ↓
Subscription::create() [writes to subscriptions table]
  ↓
DB::transaction() completes
  ↓
❌ NO EntitlementService::rebuild() call
  ↓
tenant_entitlements table remains empty
  ↓
FeatureGateService::check() returns is_entitled = false
  ↓
EnsureEntitlementAccess middleware returns 403 Forbidden
```

**Contrast (PlanChangeService — CORRECT):**

```
PlanChangeService::applyChange()
  ↓
Subscription::migratePlan() [updates subscriptions table]
  ↓
DB::transaction() completes
  ↓
✅ EntitlementService::rebuild() IS called
  ↓
tenant_entitlements table is rebuilt
  ↓
FeatureGateService cache is invalidated
  ↓
FeatureGateService::check() returns is_entitled = true
  ↓
EnsureEntitlementAccess middleware returns 200 OK
```

---

## Audit Integrity

- ✅ No assumptions made without code evidence
- ✅ All findings traceable to code
- ✅ Full projection traces provided
- ✅ Uncertain areas marked properly
- ✅ Verified safe areas explicitly listed

---

## Related Documents

- **Full Report:** `WS-02-HOSTILE-AUDIT-REPORT.md`
- **Steering Pack:** `.kiro/steering/02-gates.md`
- **Fast-Fail Checks:** `.kiro/steering/08-checks.md`

---

**Audit Authority:** Tier 1 Hardening + Platform Integrity  
**Last Updated:** 2026-04-24  
**Status:** COMPLETE — Ready for remediation
