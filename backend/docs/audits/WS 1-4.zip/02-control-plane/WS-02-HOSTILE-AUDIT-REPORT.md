# WS-02 Control Plane — Hostile Audit Report

**Audit Date:** 2026-04-24  
**Scope:** Control Plane Projection Integrity (WS-02)  
**Authority:** Tier 1 Hardening + Platform Integrity  
**Verdict:** **HIGH RISK** — Critical projection gap identified

---

## Executive Summary

WS-02 Control Plane projection system is **PARTIALLY CONVERGED** with **ONE CRITICAL ISSUE** blocking closure:

**CRITICAL-001:** Subscription creation does NOT trigger entitlement rebuild, leaving new tenants with stale/empty entitlements until manual rebuild or configuration change.

**Impact:** New tenants cannot access any features until entitlements are manually rebuilt. This violates PI-2 (Deployment Safety) and breaks the control plane projection contract.

**Evidence Confidence:** VALIDATED (code trace complete)

---

## Critical Issues

### CRITICAL-001 — Subscription Creation Missing Rebuild Trigger

**File:** `backend/app/SuperAdmin/Application/SubscriptionService.php`  
**Class/Method:** `SubscriptionService::createSubscription()`  
**Lines:** 24-60

**Execution Path:**
```
SubscriptionService::createSubscription()
  → Subscription::create() [line 41]
  → DB::transaction() completes
  → NO EntitlementService::rebuild() call
  → Entitlements remain empty/stale
```

**Control Plane Source:**
- `subscriptions` table: new row created with `plan_version_id`
- `plan_versions` → `plan_families` → `plan_item_defaults` (tier matrix)

**Projection Path:**
- `EntitlementService::rebuild()` should be called to resolve tier defaults
- `TenantEntitlement` table should be populated with tier-included items
- `FeatureGateService` cache should be invalidated

**Runtime Enforcement Path:**
- `EnsureEntitlementAccess` middleware reads `tenant_entitlements`
- If table is empty: all feature checks return `is_entitled = false`
- Result: 403 Forbidden on all feature-gated endpoints

**Mismatch Description:**

When a new subscription is created via `SubscriptionService::createSubscription()`:

1. ✅ Subscription row is written to `subscriptions` table
2. ✅ Plan version is linked (contains tier matrix reference)
3. ❌ **NO rebuild is triggered**
4. ❌ `tenant_entitlements` table remains empty
5. ❌ `FeatureGateService` cache is not invalidated
6. ❌ Runtime checks fail: `is_entitled = false` for all features

**Why This Violates Steering:**

- **PI-2 Deployment Safety:** New tenant cannot use product until manual intervention
- **Control Plane Projection Contract:** Subscription → Entitlements mapping is broken
- **FF-02 Upstream Gate Check:** G1 (Platform Truth) requires tenant context to be resolved at entry; new tenant has no entitlements
- **FF-03 Bypass Search Check:** Subscription creation is a canonical entry point; it must trigger rebuild

**Impact:**

- New tenants created via `SubscriptionService::createSubscription()` have zero entitlements
- All feature checks return `is_entitled = false`
- All feature-gated endpoints return 403 Forbidden
- Workaround: Manual rebuild via `AdminTenantConfigurationController` or seeder
- **Severity:** CRITICAL — blocks new tenant onboarding

**Evidence Confidence:** VALIDATED

**Code Evidence:**

```php
// SubscriptionService::createSubscription() — NO rebuild
public function createSubscription(
    string $tenantId,
    int $planVersionId,
    string $billingInterval,
    ?Carbon $trialEndsAt = null,
): Subscription {
    // ... validation ...
    
    return DB::transaction(function () use (...) {
        $subscription = Subscription::create([
            'tenant_id'            => $tenantId,
            'plan_version_id'      => $planVersionId,
            // ...
        ]);

        if ($status === 'active') {
            $this->billingService->generateInvoice($subscription, $billingInterval);
        }

        $this->auditLogger->log(...);

        return $subscription;
        // ❌ NO $this->entitlements->rebuild($tenantId, ...)
    });
}
```

**Contrast with PlanChangeService (CORRECT):**

```php
// PlanChangeService::applyChange() — CORRECT: rebuild IS called
public function applyChange(TenantPlanChange $planChange, ?int $adminId = null): TenantPlanChange {
    return DB::transaction(function () use ($planChange, $adminId) {
        // ... subscription migration ...
        
        // ✅ Step 3: Rebuild entitlements
        $this->entitlements->rebuild(
            $planChange->tenant_id,
            $adminId,
            'plan_change_applied',
        );
        
        // ...
    });
}
```

**Contrast with TenantConfigurationService (CORRECT):**

```php
// TenantConfigurationService::addSelection() — CORRECT: rebuild IS called
public function addSelection(...): TenantSelectedItem {
    // ... selection created ...
    
    // ✅ Rebuild entitlements to reflect the change immediately
    $this->entitlements->rebuild($tenantId, $adminId, "selection_added:{$item->key}");
    
    return $selection->load('catalogItem.type');
}
```

---

## High Issues

### HIGH-001 — Seeder Bypasses Rebuild

**File:** `backend/database/seeders/Subscription360Seeder.php`  
**Lines:** 109-130

**Issue:** Demo seeder creates subscriptions directly via `Subscription::create()` without triggering rebuild.

**Impact:** Demo tenants have empty entitlements until manual rebuild.

**Severity:** HIGH (affects demo/test environments; production uses `SubscriptionService`)

**Evidence Confidence:** VALIDATED

---

## Verified Safe Areas

### ✅ Plan Change Rebuild Trigger

**File:** `backend/app/SuperAdmin/Application/PlanChangeService.php`  
**Lines:** 192-195

**Finding:** Plan changes correctly trigger rebuild.

```php
$this->entitlements->rebuild(
    $planChange->tenant_id,
    $adminId,
    'plan_change_applied',
);
```

**Status:** ✅ CORRECT

---

### ✅ Configuration Selection Rebuild Trigger

**File:** `backend/app/SuperAdmin/Application/TenantConfigurationService.php`  
**Lines:** 72, 96, 116

**Finding:** All configuration changes (add selection, remove selection, reset to defaults) correctly trigger rebuild.

**Status:** ✅ CORRECT

---

### ✅ Cache Invalidation Atomicity

**File:** `backend/app/SuperAdmin/Application/EntitlementService.php`  
**Lines:** 127-165

**Finding:** Cache invalidation happens AFTER entitlements are written (inside transaction):

```php
DB::transaction(function () use ($tenantId, $resolved) {
    TenantEntitlement::forTenant($tenantId)->delete();
    // ... insert new rows ...
});

// ✅ Cache invalidated AFTER transaction commits
Cache::forget("feature_gate:{$tenantId}");
```

**Status:** ✅ CORRECT (no race condition)

---

### ✅ Cache Key Includes Tenant Context

**File:** `backend/app/SuperAdmin/Application/FeatureGateService.php`  
**Lines:** 116-118

**Finding:** Cache key includes tenant ID, preventing cross-tenant cache pollution.

```php
private function cacheKey(string $tenantId): string
{
    return "feature_gate:{$tenantId}";
}
```

**Status:** ✅ CORRECT

---

### ✅ Cache TTL and Invalidation

**File:** `backend/app/SuperAdmin/Application/FeatureGateService.php`  
**Lines:** 14-15, 30-36

**Finding:** Cache TTL is 300 seconds (5 minutes). Invalidation is explicit (not relying on TTL).

```php
private const TTL = 300;

public function all(string $tenantId, bool $fresh = false): array
{
    if ($fresh) {
        $this->invalidate($tenantId);
    }

    return Cache::remember(
        $this->cacheKey($tenantId),
        self::TTL,
        fn () => $this->resolveFromDb($tenantId),
    );
}
```

**Status:** ✅ CORRECT

---

### ✅ Middleware Enforcement Consistency

**File:** `backend/app/Http/Middleware/EnsureEntitlementAccess.php`  
**Lines:** 1-65

**Finding:** Middleware correctly reads from canonical `tenant_entitlements` via `FeatureGateService::check()`.

```php
$result = $this->featureGate->check($tenantId, $featureKey);

if ($result['is_entitled']) {
    return $next($request);
}

return response()->json([
    'message' => "Feature '{$featureKey}' is not enabled for this account.",
], 403);
```

**Status:** ✅ CORRECT

---

### ✅ Module-Specific Enforcement

**File:** `backend/app/Http/Middleware/EnsureInventoryAccess.php`  
**Lines:** 1-95

**Finding:** Module-specific middleware correctly uses `FeatureGateService` for entitlement checks.

```php
$check = $this->featureGate->check((string) $tenantId, 'inventory');
if (!$check['is_entitled']) {
    return response()->json([
        'message' => 'The inventory module is not enabled for this account.',
    ], 403);
}
```

**Status:** ✅ CORRECT

---

### ✅ Tenant Context Resolution

**File:** `backend/app/SuperAdmin/Application/FeatureGateService.php`  
**Lines:** 121-135

**Finding:** Tenant context is resolved once at entry and propagated unchanged via `search_path`.

```php
private function ensureCentralSchema(): ?string
{
    if (!function_exists('tenant') || !tenant()) {
        return null;
    }

    $row = DB::selectOne('SHOW search_path');
    $previous = $row->search_path ?? null;

    DB::statement("SET search_path TO public");
    return $previous;
}
```

**Status:** ✅ CORRECT

---

### ✅ Rebuild Resolution Algorithm

**File:** `backend/app/SuperAdmin/Application/EntitlementService.php`  
**Lines:** 185-250

**Finding:** Rebuild correctly resolves entitlements in priority order:
1. Tier included items
2. Add-on purchased
3. Override includes
4. Override excludes (highest priority)

**Status:** ✅ CORRECT

---

### ✅ Test Coverage

**File:** `backend/tests/Feature/ControlPlaneProjectionTest.php`

**Finding:** Tests verify:
- ✅ `EnsureEntitlementAccess` blocks when `is_entitled = false`
- ✅ `EnsureEntitlementAccess` allows when `is_entitled = true`
- ✅ `tenant_features` cannot override `tenant_entitlements`
- ✅ Rebuild invalidates cache and updates runtime checks
- ✅ `Feature::isEnabledForTenant()` is retired (throws)

**Status:** ✅ CORRECT (but does not test subscription creation)

---

## No-Issue Zones

**Areas checked with no findings:**

- ✅ Legacy `tenant_features` table is not used in production code
- ✅ `FeatureFlagController` is not referenced in production controllers
- ✅ `Feature::isEnabledForTenant()` is retired and throws `LogicException`
- ✅ Cache invalidation uses explicit `Cache::forget()` (not relying on TTL)
- ✅ Tenant context is resolved once at entry and propagated unchanged
- ✅ All module-specific middleware uses canonical `FeatureGateService`
- ✅ No direct `tenant_entitlements` queries bypass `FeatureGateService`
- ✅ No async jobs or webhooks bypass entitlement checks (none found)

---

## Coverage Report

**Files Inspected:**
- `backend/app/SuperAdmin/Application/FeatureGateService.php` ✅
- `backend/app/SuperAdmin/Application/EntitlementService.php` ✅
- `backend/app/SuperAdmin/Application/SubscriptionService.php` ✅
- `backend/app/SuperAdmin/Application/TenantConfigurationService.php` ✅
- `backend/app/SuperAdmin/Application/PlanChangeService.php` ✅
- `backend/app/Http/Middleware/EnsureEntitlementAccess.php` ✅
- `backend/app/Http/Middleware/EnsureInventoryAccess.php` ✅
- `backend/app/SuperAdmin/Domain/Subscription.php` ✅
- `backend/app/SuperAdmin/Domain/TenantEntitlement.php` ✅
- `backend/database/seeders/Subscription360Seeder.php` ✅
- `backend/tests/Feature/ControlPlaneProjectionTest.php` ✅

**Entry Points Covered:**
- ✅ HTTP middleware (EnsureEntitlementAccess, EnsureInventoryAccess)
- ✅ Service layer (FeatureGateService, EntitlementService)
- ✅ Configuration changes (TenantConfigurationService)
- ✅ Plan changes (PlanChangeService)
- ✅ Subscription creation (SubscriptionService)
- ✅ Seeder (Subscription360Seeder)

**Control Plane Paths Examined:**
- ✅ Subscription → Plan Version → Plan Family → Plan Item Defaults
- ✅ Tenant Selected Items → Entitlement Resolution
- ✅ Entitlement Rebuild → Cache Invalidation
- ✅ Runtime Enforcement → Feature Gate Service

**Audit Integrity Check:**

- ✅ No assumptions made without code evidence
- ✅ All findings traceable to code
- ✅ Uncertain areas marked properly
- ✅ Full projection traces provided for all issues

---

## Verdict

**WS-02 CONTROL PLANE: HIGH RISK**

**Reason:** Subscription creation does not trigger entitlement rebuild, leaving new tenants with empty entitlements until manual intervention.

**Blocking:** WS-02 cannot be marked CLOSED until CRITICAL-001 is resolved.

**Downstream Impact:**
- G2 (Runtime Access Truth) cannot be satisfied while new tenants have no entitlements
- G3 (Domain Ownership Truth) is blocked on G2
- All downstream gates (G4, G5, G6) are blocked

---

## Surviving Blockers

1. **CRITICAL-001:** Subscription creation missing rebuild trigger
   - **Blocker:** New tenants have empty entitlements
   - **Impact:** Cannot access any features until manual rebuild
   - **Fix Required:** Add `$this->entitlements->rebuild($tenantId, $adminId, 'subscription_created')` to `SubscriptionService::createSubscription()`

2. **HIGH-001:** Seeder bypasses rebuild
   - **Blocker:** Demo tenants have empty entitlements
   - **Impact:** Demo/test environments cannot use features until manual rebuild
   - **Fix Required:** Add rebuild call after `Subscription::create()` in seeder

---

## Recommendations

### Immediate (Blocking)

1. **Add rebuild trigger to SubscriptionService::createSubscription()**
   ```php
   $this->entitlements->rebuild($tenantId, $adminId, 'subscription_created');
   ```

2. **Add rebuild trigger to Subscription360Seeder**
   ```php
   app(EntitlementService::class)->rebuild($tenantId, null, 'seeder_subscription_created');
   ```

3. **Add test case to ControlPlaneProjectionTest**
   - Test: `test_subscription_creation_triggers_rebuild()`
   - Verify: New subscription → entitlements populated → feature checks pass

### Follow-up (Non-blocking)

1. **Add observer to Subscription model** (optional, for safety)
   - Trigger rebuild on `created` event
   - Prevents future bypasses

2. **Add integration test** (optional)
   - Test full flow: Create subscription → Check feature → Verify access

---

## Self-Patch Rule

If this document conflicts with code evidence, latest Tier 1 reports, or platform integrity requirements:
1. Mark the conflict
2. Patch the document
3. Record in CHANGELOG.md
4. Continue with patched rule

---

**Audit Authority:** Tier 1 Hardening + Platform Integrity  
**Last Updated:** 2026-04-24  
**Status:** COMPLETE — Ready for remediation
