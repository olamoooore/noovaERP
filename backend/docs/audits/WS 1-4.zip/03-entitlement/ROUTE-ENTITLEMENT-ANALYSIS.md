# Route Entitlement Middleware Analysis

**Scope:** WS-03 (Entitlement) | Gate: G2  
**Analysis Date:** 2026-04-24  
**Authority:** Tier 1 Hardening Review

---

## Executive Summary

### Key Findings

| Category | Count | Status |
|---|---|---|
| **Total Routes Analyzed** | 14 modules + 3 core files | ✅ |
| **Routes with Entitlement Enforcement** | 6 modules | ✅ PROTECTED |
| **Routes with auth:sanctum ONLY** | 6 modules | ⚠️ BYPASS RISK |
| **Routes with Custom Middleware** | 2 modules | ⚠️ NEEDS REVIEW |
| **Admin Routes (EnsureAdminRole)** | All protected | ✅ PROTECTED |
| **Public Routes (No Auth)** | Tenant.php only | ✅ SCOPED |

### Critical Finding

**6 modules bypass entitlement checks** by using only `auth:sanctum` without `entitlement:{key}` middleware:
- WhatsApp
- PaymentGateway
- OCRBookkeeping
- HRM
- FieldService
- Communication

---

## Detailed Route Analysis

### ✅ PROTECTED ROUTES (Entitlement Enforced)

#### 1. **POS Module** (`backend/modules/POS/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', 'entitlement:pos', 'ensure.tenant.search_path'])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- `GET /pos/health`
- `GET /sales/orders`
- `GET /pos/terminals` (CRUD)
- `GET /pos/sessions` (CRUD)
- `POST /pos/sessions/{sessionId}/cash-movement`
- All POS-specific operations

**Evidence:**
- Entitlement middleware: `entitlement:pos` ✅
- Tenant scope: `ensure.tenant.search_path` ✅
- Authentication: `auth:sanctum` ✅

---

#### 2. **WebsiteBuilder Module** (`backend/modules/WebsiteBuilder/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', 'entitlement:website-builder'])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- `GET /website-builder/health`
- `POST /website-builder/editor/save`
- `GET /website-builder/editor/page/{page}`
- `POST /website-builder/websites` (CRUD)
- `GET /website-builder/pages` (CRUD)
- `GET /website-builder/templates` (CRUD)
- `POST /website-builder/assets` (CRUD)

**Evidence:**
- Entitlement middleware: `entitlement:website-builder` ✅
- Authentication: `auth:sanctum` ✅

---

#### 3. **Loyalty Module** (`backend/modules/Loyalty/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', 'entitlement:loyalty'])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- `GET /loyalty/health`
- `GET /loyalty/dashboard`
- `POST /loyalty/points/redeem`
- `GET /loyalty/history`
- All loyalty operations

**Evidence:**
- Entitlement middleware: `entitlement:loyalty` ✅
- Authentication: `auth:sanctum` ✅

---

#### 4. **IoT Module** (`backend/modules/IoT/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', 'entitlement:iot'])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- `GET /iot/health`
- `GET /iot/devices` (CRUD)
- `POST /iot/devices/{device}/command`
- All IoT device operations

**Evidence:**
- Entitlement middleware: `entitlement:iot` ✅
- Authentication: `auth:sanctum` ✅

---

#### 5. **AI Module** (`backend/modules/AI/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', 'entitlement:ai'])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- `GET /ai/health`
- `POST /ai/analyze`
- `GET /ai/models`
- All AI service operations

**Evidence:**
- Entitlement middleware: `entitlement:ai` ✅
- Authentication: `auth:sanctum` ✅

---

#### 6. **EventManagement Module** (`backend/modules/EventManagement/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', 'request.validation', 'entitlement:event_management', 'rate_limit:admin_api'])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- `GET /event-management/events` (CRUD)
- `POST /event-management/bookings`
- `GET /event-management/tickets`
- `GET /customer/dashboard`
- `GET /bookings/{bookingId}/tickets/download`

**Evidence:**
- Entitlement middleware: `entitlement:event_management` ✅
- Authentication: `auth:sanctum` ✅
- Rate limiting: `rate_limit:admin_api` ✅

---

### ⚠️ BYPASS RISK — auth:sanctum ONLY (No Entitlement Check)

#### 1. **WhatsApp Module** (`backend/modules/WhatsApp/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum'])
```

**Status:** ⚠️ **BYPASS RISK**

**Routes Unprotected:**
- `GET /whatsapp/api-keys`
- `POST /whatsapp/api-keys`
- `PUT /whatsapp/api-keys/{id}`
- `DELETE /whatsapp/api-keys/{id}`
- `POST /whatsapp/api-keys/{id}/revoke`
- `POST /whatsapp/api-keys/{id}/activate`
- `POST /whatsapp/api-keys/{id}/test`

**Risk Assessment:**
- ❌ No entitlement middleware
- ❌ Any authenticated user can manage WhatsApp API keys
- ❌ No feature gate check
- ⚠️ **CRITICAL:** API key management should be restricted to entitled tenants

**Recommendation:**
```php
Route::middleware(['auth:sanctum', 'entitlement:whatsapp'])
```

---

#### 2. **PaymentGateway Module** (`backend/modules/PaymentGateway/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware('auth:sanctum')
```

**Status:** ⚠️ **BYPASS RISK**

**Routes Unprotected:**
- `GET /payment-gateway/gateways`
- `POST /payment-gateway/gateways`
- `PUT /payment-gateway/gateways/{id}`
- `DELETE /payment-gateway/gateways/{id}`
- `POST /payment-gateway/gateways/{id}/test`
- All payment gateway configuration

**Risk Assessment:**
- ❌ No entitlement middleware
- ❌ Any authenticated user can configure payment gateways
- ❌ No feature gate check
- ⚠️ **CRITICAL:** Payment gateway setup should be restricted to entitled tenants

**Recommendation:**
```php
Route::middleware(['auth:sanctum', 'entitlement:payment_gateway'])
```

---

#### 3. **OCRBookkeeping Module** (`backend/modules/OCRBookkeeping/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum'])
```

**Status:** ⚠️ **BYPASS RISK**

**Routes Unprotected:**
- `POST /ocr/documents/upload`
- `GET /ocr/documents`
- `GET /ocr/documents/{id}`
- `POST /ocr/documents/{id}/process`
- All OCR document processing

**Risk Assessment:**
- ❌ No entitlement middleware
- ❌ Any authenticated user can upload and process OCR documents
- ❌ No feature gate check
- ⚠️ **CRITICAL:** OCR processing should be restricted to entitled tenants

**Recommendation:**
```php
Route::middleware(['auth:sanctum', 'entitlement:ocr_bookkeeping'])
```

---

#### 4. **HRM Module** (`backend/modules/HRM/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum'])
```

**Status:** ⚠️ **BYPASS RISK**

**Routes Unprotected:**
- `GET /hrm/employees` (CRUD)
- `POST /hrm/employees`
- `GET /hrm/departments` (CRUD)
- `GET /hrm/payroll`
- All HR operations

**Risk Assessment:**
- ❌ No entitlement middleware
- ❌ Any authenticated user can access HR data
- ❌ No feature gate check
- ⚠️ **CRITICAL:** HR module should be restricted to entitled tenants

**Recommendation:**
```php
Route::middleware(['auth:sanctum', 'entitlement:hrm'])
```

---

#### 5. **FieldService Module** (`backend/modules/FieldService/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware('auth:sanctum')
```

**Status:** ⚠️ **BYPASS RISK**

**Routes Unprotected:**
- `GET /field-service/work-orders` (CRUD)
- `POST /field-service/work-orders`
- `GET /field-service/technicians`
- `POST /field-service/assignments`
- All field service operations

**Risk Assessment:**
- ❌ No entitlement middleware
- ❌ Any authenticated user can manage work orders
- ❌ No feature gate check
- ⚠️ **CRITICAL:** Field service should be restricted to entitled tenants

**Recommendation:**
```php
Route::middleware(['auth:sanctum', 'entitlement:field_service'])
```

---

#### 6. **Communication Module** (`backend/modules/Communication/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['api', 'auth:sanctum'])
```

**Status:** ⚠️ **BYPASS RISK**

**Routes Unprotected:**
- `GET /api/communication/messages` (CRUD)
- `POST /api/communication/messages`
- `GET /api/communication/threads`
- All communication operations

**Risk Assessment:**
- ❌ No entitlement middleware
- ❌ Any authenticated user can send/receive messages
- ❌ No feature gate check
- ⚠️ **CRITICAL:** Communication module should be restricted to entitled tenants

**Recommendation:**
```php
Route::middleware(['api', 'auth:sanctum', 'entitlement:communication'])
```

---

### ⚠️ CUSTOM MIDDLEWARE (Needs Review)

#### 1. **Inventory Module** (`backend/modules/Inventory/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', 'inventory.access'])
```

**Status:** ⚠️ **CUSTOM MIDDLEWARE**

**Routes Protected:**
- `GET /brands` (CRUD)
- `GET /categories` (CRUD)
- `GET /products` (CRUD)
- `GET /stock-levels`
- All inventory operations

**Risk Assessment:**
- ⚠️ Uses custom `inventory.access` middleware instead of standard `entitlement:inventory`
- ❓ Need to verify `inventory.access` middleware implementation
- ❓ Need to confirm it reads from `tenant_entitlements` (canonical)

**Recommendation:**
- Verify `inventory.access` middleware reads from canonical entitlements
- Consider standardizing to `entitlement:inventory` for consistency

---

#### 2. **Sales Module** (`backend/modules/Sales/routes/api.php`)

**Middleware Stack:**
```php
Route::middleware([
    'api',
    'auth:sanctum',
    \App\Http\Middleware\SetTenantFromUserPreference::class,
    \App\Http\Middleware\EnsureTenantSearchPath::class,
    \App\Http\Middleware\SyncTenantUserFromCentralAuth::class,
])
```

**Status:** ⚠️ **NO ENTITLEMENT MIDDLEWARE**

**Routes Unprotected:**
- `POST /sales/orders/{id}/confirm`
- `POST /sales/orders/{id}/allocate`
- `POST /sales/orders/{id}/fulfil`
- `POST /sales/orders/{id}/cancel`
- `POST /sales/orders/{id}/invoice`
- All sales order operations

**Risk Assessment:**
- ❌ No entitlement middleware
- ❌ No `entitlement:sales` check
- ❌ Any authenticated user can create/modify sales orders
- ⚠️ **CRITICAL:** Sales module should be restricted to entitled tenants

**Recommendation:**
```php
Route::middleware([
    'api',
    'auth:sanctum',
    'entitlement:sales',
    \App\Http\Middleware\SetTenantFromUserPreference::class,
    \App\Http\Middleware\EnsureTenantSearchPath::class,
    \App\Http\Middleware\SyncTenantUserFromCentralAuth::class,
])
```

---

### ✅ ADMIN ROUTES (Control Plane)

#### Admin Routes (`backend/routes/admin.php`)

**Middleware Stack:**
```php
Route::middleware(['auth:sanctum', EnsureAdminRole::class])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- All `/api/v1/admin/*` routes
- Plan management
- Module catalog
- Tenant management
- Subscription management
- Billing
- Audit logs
- User management
- Collections
- Analytics
- Catalog management
- Pricing engine
- API keys
- Plan changes
- Packaging

**Evidence:**
- Admin role middleware: `EnsureAdminRole::class` ✅
- Authentication: `auth:sanctum` ✅
- Role validation: Checks for 5 admin roles ✅
- Account status check: Verifies `is_active` ✅

**Admin Roles Allowed:**
- `platform_super_admin`
- `platform_ops`
- `sales_ops`
- `billing_ops`
- `support_readonly`

---

### ✅ PUBLIC ROUTES (Tenant-Scoped)

#### Tenant Routes (`backend/routes/tenant.php`)

**Public API Routes (No Auth Required):**
```php
Route::middleware([
    'api',
    \App\Http\Middleware\EnsurePublicSchemaForAuth::class,
    \App\Http\Middleware\InitializeTenantForPublicAccess::class,
    \Illuminate\Routing\Middleware\SubstituteBindings::class,
])
```

**Status:** ✅ **SCOPED**

**Public Routes:**
- `GET /api/v1/website-public/sites/{websiteSlug}`
- `GET /api/v1/website-public/products`
- `GET /api/v1/website-public/events`
- `POST /api/v1/web-shop/checkout/guest`
- `POST /api/v1/web-shop/auth/register`
- `POST /api/v1/web-shop/auth/login`

**Evidence:**
- Tenant resolved from domain/host header ✅
- No authentication required (intentional) ✅
- Tenant context enforced ✅

**Authenticated Routes (Tenant-Scoped):**
```php
Route::middleware([
    'api',
    'auth:sanctum',
    \App\Http\Middleware\SetTenantFromUserPreference::class,
    \App\Http\Middleware\EnsureTenantSearchPath::class,
    \App\Http\Middleware\SyncTenantUserFromCentralAuth::class,
    PreventAccessFromCentralDomains::class,
])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- Document corrections (invoices, bills, journals, payments)
- All module-specific routes (loaded dynamically)

**Evidence:**
- Authentication: `auth:sanctum` ✅
- Tenant scope: `SetTenantFromUserPreference` ✅
- Search path: `EnsureTenantSearchPath` ✅
- Central domain prevention: `PreventAccessFromCentralDomains` ✅

---

### ✅ FEATURE GATE API (Runtime Entitlement Check)

#### Feature Gate Routes (`backend/routes/feature-gate.php`)

**Middleware Stack:**
```php
Route::middleware([
    \App\Http\Middleware\EnsurePublicSchemaForAuth::class,
    'auth.tenant_key',
    \Illuminate\Routing\Middleware\SubstituteBindings::class,
    'throttle:120,1',
])
```

**Status:** ✅ **PROTECTED**

**Routes Protected:**
- `GET /api/v1/feature-gate/` (all features)
- `POST /api/v1/feature-gate/check-many` (batch check)
- `GET /api/v1/feature-gate/{key}` (single feature)

**Evidence:**
- Tenant API key auth: `auth.tenant_key` ✅
- Rate limiting: `throttle:120,1` ✅
- Public schema: `EnsurePublicSchemaForAuth` ✅

---

## Middleware Implementation Analysis

### EnsureEntitlementAccess Middleware

**Location:** `backend/app/Http/Middleware/EnsureEntitlementAccess.php`

**Resolution Order:**
1. Super-admin bypass (if `is_super_admin = true`)
2. Core features pass unconditionally (if `is_core = true`)
3. Canonical entitlement check via `FeatureGateService::check()`
4. Returns 403 if not entitled
5. Returns 403 if no tenant context

**Code Evidence:**
```php
public function handle(Request $request, Closure $next, string $featureKey): Response
{
    // 1. Super-admin bypass
    $user = $request->user();
    if ($user && ($user->is_super_admin ?? false)) {
        return $next($request);
    }

    // 2. Core features always pass
    $feature = \App\Models\Feature::query()->where('key', $featureKey)->first();
    if ($feature && $feature->is_core) {
        return $next($request);
    }

    // 3. Canonical entitlement check
    $tenantId = $this->currentTenantId();
    if ($tenantId !== null) {
        $result = $this->featureGate->check($tenantId, $featureKey);
        if ($result['is_entitled']) {
            return $next($request);
        }
        return response()->json([
            'message' => "Feature '{$featureKey}' is not enabled for this account.",
        ], 403);
    }

    // 4. No tenant context — fail closed
    return response()->json([
        'message' => 'No tenant context available to verify feature access.',
    ], 403);
}
```

**Status:** ✅ **CORRECT IMPLEMENTATION**

---

### EnsureAdminRole Middleware

**Location:** `backend/app/SuperAdmin/Http/Middleware/EnsureAdminRole.php`

**Validation:**
1. Checks user role is in allowed list
2. Verifies account is active (`is_active = true`)
3. Returns 403 if role not allowed or account inactive

**Allowed Roles:**
- `platform_super_admin`
- `platform_ops`
- `sales_ops`
- `billing_ops`
- `support_readonly`

**Code Evidence:**
```php
public function handle(Request $request, Closure $next): Response
{
    $user = $request->user();

    if (! $user || ! in_array($user->role, self::ADMIN_ROLES, true)) {
        return response()->json([
            'message' => 'Forbidden. Platform admin access required.',
        ], 403);
    }

    // Check if the admin account is deactivated
    if (! $user->is_active) {
        return response()->json([
            'message' => 'Your admin account has been deactivated.',
        ], 403);
    }

    return $next($request);
}
```

**Status:** ✅ **CORRECT IMPLEMENTATION**

---

## Summary Table

| Module | Middleware | Status | Risk Level |
|---|---|---|---|
| **POS** | `auth:sanctum` + `entitlement:pos` | ✅ Protected | Low |
| **WebsiteBuilder** | `auth:sanctum` + `entitlement:website-builder` | ✅ Protected | Low |
| **Loyalty** | `auth:sanctum` + `entitlement:loyalty` | ✅ Protected | Low |
| **IoT** | `auth:sanctum` + `entitlement:iot` | ✅ Protected | Low |
| **AI** | `auth:sanctum` + `entitlement:ai` | ✅ Protected | Low |
| **EventManagement** | `auth:sanctum` + `entitlement:event_management` | ✅ Protected | Low |
| **WhatsApp** | `auth:sanctum` ONLY | ⚠️ Bypass | **CRITICAL** |
| **PaymentGateway** | `auth:sanctum` ONLY | ⚠️ Bypass | **CRITICAL** |
| **OCRBookkeeping** | `auth:sanctum` ONLY | ⚠️ Bypass | **CRITICAL** |
| **HRM** | `auth:sanctum` ONLY | ⚠️ Bypass | **CRITICAL** |
| **FieldService** | `auth:sanctum` ONLY | ⚠️ Bypass | **CRITICAL** |
| **Communication** | `auth:sanctum` ONLY | ⚠️ Bypass | **CRITICAL** |
| **Inventory** | `auth:sanctum` + `inventory.access` | ⚠️ Custom | Medium |
| **Sales** | `auth:sanctum` ONLY | ⚠️ Bypass | **CRITICAL** |
| **Admin** | `auth:sanctum` + `EnsureAdminRole` | ✅ Protected | Low |
| **Tenant (Public)** | Tenant-scoped | ✅ Protected | Low |
| **Feature Gate** | `auth.tenant_key` | ✅ Protected | Low |

---

## Verdict

### WS-03 Entitlement Status: **PARTIALLY CONVERGED**

**Evidence:**
- ✅ 6 modules have entitlement middleware enforced
- ✅ Admin routes protected with role-based access
- ✅ Public routes properly scoped to tenant
- ✅ Feature Gate API protected with tenant key auth
- ❌ 6 modules bypass entitlement checks (auth:sanctum only)
- ❌ 1 module uses custom middleware (needs verification)
- ❌ 1 module missing entitlement check entirely

### Surviving Bypass Paths

**Critical Bypass Routes (No Entitlement Check):**
1. WhatsApp API key management
2. PaymentGateway configuration
3. OCRBookkeeping document processing
4. HRM employee/payroll data
5. FieldService work order management
6. Communication messaging
7. Sales order operations

**Custom Middleware Routes (Needs Verification):**
1. Inventory module (`inventory.access` middleware)

### Upstream Gate Status

**G1 (Platform Truth):** ✅ CLOSED (WS-01, WS-02)  
**G2 (Runtime Access Truth):** ⚠️ **BLOCKED** — WS-03 not fully closed

### Recommendations

**Immediate Actions (Tier 1):**
1. Add `entitlement:{module}` middleware to all 6 bypass modules
2. Verify `inventory.access` middleware reads from canonical entitlements
3. Add `entitlement:sales` to Sales module routes
4. Run full codebase search for any other routes missing entitlement checks

**Verification Required:**
- Confirm all module feature keys exist in `features` table
- Verify `FeatureGateService::check()` is the canonical entitlement reader
- Test that 403 is returned when tenant not entitled
- Confirm no alternate authorization paths exist

---

## Fast-Fail Checks (WS-03)

**FF-03 — Bypass Search Check:** ⚠️ FAILED
- Bypass paths found in 6 modules using `auth:sanctum` only
- No entitlement middleware applied

**FF-08 — Mutation Owner Check:** ⚠️ NEEDS VERIFICATION
- Inventory module uses custom `inventory.access` middleware
- Need to verify it reads from canonical entitlements

**FF-22 — Security Enforcement (PI-4):** ⚠️ FAILED
- RBAC not enforced on all entry points
- 6 modules allow any authenticated user to access features

---

## Self-Patch Rule

If this document conflicts with code evidence, latest Tier 1 reports, or platform integrity requirements:
1. Mark the conflict
2. Patch the document
3. Record in CHANGELOG.md
4. Continue with patched rule
