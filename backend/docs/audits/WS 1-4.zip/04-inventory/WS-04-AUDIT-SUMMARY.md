# WS-04 Inventory — Audit Summary

**Workstream:** WS-04 Inventory (Stock Truth + Movement Integrity)  
**Gate:** G3 — Domain Ownership Truth  
**Audit Date:** 2026-04-25  
**Status:** 🔴 STILL BLOCKED

---

## Quick Verdict

**🔴 HIGH RISK — 3 CRITICAL BYPASS PATHS DETECTED**

WS-04 is **STILL BLOCKED** due to:
1. Loyalty module bypasses InventoryService (direct stock mutation)
2. Sales module does NOT deduct stock on fulfillment
3. Dual stock sources exist (products.stock_quantity writable)

---

## Issue Summary

| ID | Severity | Title | Status |
|---|---|---|---|
| CRITICAL-001 | CRITICAL | Loyalty module direct stock mutation | OPEN |
| CRITICAL-002 | CRITICAL | Sales module does NOT deduct stock | OPEN |
| CRITICAL-003 | CRITICAL | Dual stock sources (writable Product field) | OPEN |
| HIGH-001 | HIGH | Product::adjustStock() deprecated but callable | OPEN |

---

## Critical Issues

### CRITICAL-001 — Loyalty Module Direct Stock Mutation

**File:** `backend/modules/Loyalty/src/Services/RedemptionService.php:169,230`

**Issue:**
```php
// LINE 169 — BYPASS
$reward->decrement('stock_quantity');

// LINE 230 — BYPASS
$redemption->reward->increment('stock_quantity');
```

**Impact:**
- Loyalty reward stock is NOT tracked in `stock_levels`
- Loyalty reward stock changes are NOT recorded in `stock_movements`
- No warehouse tracking for loyalty rewards
- No idempotency guards
- Reconciliation impossible

**Fix:** Remove `loyalty_rewards.stock_quantity`, use `stock_levels` instead.

---

### CRITICAL-002 — Sales Module Does NOT Deduct Stock

**File:** `backend/modules/Sales/src/Services/SalesOrderService.php:117-132`

**Issue:**
```php
public function fulfilOrder(SalesOrder $order): SalesOrder
{
    // ...
    foreach ($order->lines as $line) {
        $line->update(['quantity_fulfilled' => $line->quantity]);
    }
    // ❌ NO INVENTORY SERVICE CALL
}
```

**Impact:**
- Sales orders marked "fulfilled" do NOT reduce stock
- Inventory reports show incorrect stock levels
- Overselling is possible
- Reconciliation between sales and inventory is broken

**Fix:** Add `InventoryService::adjustStock()` call in `fulfilOrder()`.

---

### CRITICAL-003 — Dual Stock Sources

**File:** `backend/app/Models/Product.php:48,214`

**Issue:**
```php
// LINE 48 — WRITABLE
protected $fillable = [
    'stock_quantity',  // ❌ WRITABLE FIELD
    // ...
];

// LINE 214 — SYNC (correct, but field is still writable)
Product::where('id', $productId)->update(['stock_quantity' => $totalStock]);
```

**Impact:**
- Direct updates to `products.stock_quantity` bypass canonical flow
- Stock can drift between `products.stock_quantity` and `stock_levels`
- Movement ledger can be incomplete

**Fix:** Remove `stock_quantity` from `$fillable` array, make read-only.

---

## Verified Correct (No Issues)

✅ **POS Module** — Calls `InventoryService` correctly  
✅ **Procurement Module** — Calls `InventoryService` correctly  
✅ **FieldService Module** — Calls `InventoryService` correctly  
✅ **InventoryService Idempotency** — Uses `lockForUpdate()` correctly  
✅ **Barcode Handling** — Deterministic, no mutation path  

---

## Convergence Status

```
Canonical Owner:     ✅ EXISTS (InventoryService)
Competing Owners:    🔴 DETECTED (Loyalty, Product model)
Bypass Paths:        🔴 DETECTED (2 direct mutations, 1 missing integration)
Idempotency:         ✅ VERIFIED (lockForUpdate + balance_after)
Movement Ledger:     ✅ VERIFIED (StockMovement table)
Cross-Module:        🔴 INCONSISTENT (Sales missing, Loyalty bypassing)
```

**Closure Criteria:** 6/10 satisfied

---

## Recommended Fix Order

### Phase 1 — Blocker Fixes (CRITICAL)

1. **Fix Sales Integration (CRITICAL-002)**
   - Add `InventoryService` call to `SalesOrderService::fulfilOrder()`
   - Deduct stock for each order line
   - Add idempotency guard

2. **Fix Loyalty Integration (CRITICAL-001)**
   - Remove `loyalty_rewards.stock_quantity` field
   - Use `stock_levels` instead (single source of truth)

3. **Fix Product Writable Field (CRITICAL-003)**
   - Remove `stock_quantity` from `Product::$fillable`
   - Make `stock_quantity` read-only (computed from `stock_levels`)

### Phase 2 — Hardening (HIGH)

4. **Fix Product::adjustStock() Deprecation (HIGH-001)**
   - Make `Product::adjustStock()` private or remove
   - Force all callers to use `InventoryService` directly

### Phase 3 — Verification

5. **Add Regression Tests**
   - Test: Sales fulfillment deducts stock
   - Test: Loyalty redemption routes through `InventoryService`
   - Test: Direct `Product::update(['stock_quantity' => X])` fails
   - Test: Idempotency (duplicate fulfillment does not double-deduct)

6. **Re-run WS-04 Audit**
   - Verify all bypass paths removed
   - Verify all modules route through `InventoryService`

---

## Gate Impact

**G3 (Domain Ownership Truth) NOT SATISFIED**

WS-04 blocks:
- WS-06 (Unified Channel) — cannot close while inventory mutations inconsistent
- WS-08 (Accounting) — cannot close while stock truth unreliable
- WS-09 (Reconciliation) — cannot close while inventory non-deterministic

---

## Evidence Confidence

**HIGH** — All findings validated with direct code evidence.

**Files Read:**
- `InventoryService.php` (full file)
- `SalesOrderService.php` (full file)
- `RedemptionService.php` (full file)
- `Product.php` (full file)
- `StockLevel.php` (full file)
- `StockMovement.php` (full file)
- `PosPaymentCompletionService.php` (partial)
- `GoodsReceiptService.php` (partial)
- `StockDeductionService.php` (full file)

**Search Queries:**
- Direct stock mutations: `->update(['stock_quantity'`, `->increment('stock_quantity'`, `->decrement('stock_quantity'`
- StockLevel mutations: `StockLevel::create(`, `StockLevel::update(`
- Async jobs: `stock|inventory|StockMovement|StockLevel` in `backend/app/Jobs/`
- Barcode handling: `findSellableByBarcodeOrSku`

---

## Next Steps

1. Review findings with development team
2. Prioritize CRITICAL-001, CRITICAL-002, CRITICAL-003
3. Implement Phase 1 fixes
4. Re-run WS-04 audit
5. Verify G3 gate satisfaction

---

**Authority:** Tier 1 Hardening + WS-04 Steering Brief  
**Full Report:** `WS-04-HOSTILE-AUDIT-REPORT.md`
