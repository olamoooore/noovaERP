# WS-04 Inventory Audit

**Workstream:** WS-04 Inventory (Stock Truth + Movement Integrity)  
**Gate:** G3 — Domain Ownership Truth  
**Status:** 🔴 STILL BLOCKED  
**Audit Date:** 2026-04-25

---

## Quick Links

- **[Full Hostile Audit Report](WS-04-HOSTILE-AUDIT-REPORT.md)** — Complete findings with evidence
- **[Audit Summary](WS-04-AUDIT-SUMMARY.md)** — Executive summary and fix order

---

## Verdict

**🔴 HIGH RISK — 3 CRITICAL BYPASS PATHS DETECTED**

WS-04 is **STILL BLOCKED** due to:
1. Loyalty module bypasses InventoryService (direct stock mutation)
2. Sales module does NOT deduct stock on fulfillment
3. Dual stock sources exist (products.stock_quantity writable)

---

## Critical Issues

| ID | Severity | Title | File |
|---|---|---|---|
| CRITICAL-001 | CRITICAL | Loyalty module direct stock mutation | `RedemptionService.php:169,230` |
| CRITICAL-002 | CRITICAL | Sales module does NOT deduct stock | `SalesOrderService.php:117-132` |
| CRITICAL-003 | CRITICAL | Dual stock sources (writable Product field) | `Product.php:48,214` |
| HIGH-001 | HIGH | Product::adjustStock() deprecated but callable | `Product.php:653-698` |

---

## What Was Audited

### Scope

✅ Core Inventory module (`InventoryService`, `StockLevel`, `StockMovement`)  
✅ Product model stock fields  
✅ Sales module integration  
✅ Procurement module integration (GoodsReceiptService)  
✅ POS module integration (PosPaymentCompletionService)  
✅ FieldService module integration (StockDeductionService)  
✅ Loyalty module integration (RedemptionService)  
✅ Barcode handling (Product::findSellableByBarcodeOrSku)  
✅ Async job stock mutations (searched, none found)  
✅ Idempotency guards  
✅ Movement ledger integrity  

### Out of Scope

❌ Ecommerce module (WebOrder) — not inspected in this audit  
❌ Stock reservation logic (StockReservationService) — separate concern  
❌ Batch/serial tracking — not in WS-04 scope  
❌ Multi-warehouse transfer logic — verified InventoryService usage only  

---

## Convergence Status

```
Canonical Owner:     ✅ EXISTS (InventoryService)
Competing Owners:    🔴 DETECTED (Loyalty, Product model)
Bypass Paths:        🔴 DETECTED (2 direct mutations, 1 missing integration)
Idempotency:         ✅ VERIFIED (lockForUpdate + balance_after)
Movement Ledger:     ✅ VERIFIED (StockMovement table)
Cross-Module:        🔴 INCONSISTENT (Sales missing, Loyalty bypassing)
POS Integration:     ✅ VERIFIED (calls InventoryService)
Procurement:         ✅ VERIFIED (calls InventoryService)
FieldService:        ✅ VERIFIED (calls InventoryService)
Barcode Handling:    ✅ VERIFIED (deterministic, no mutation path)
```

**Closure Criteria:** 6/10 satisfied

---

## Verified Correct (No Issues)

✅ **POS Module** — `PosPaymentCompletionService` calls `InventoryService` correctly  
✅ **Procurement Module** — `GoodsReceiptService` calls `InventoryService` correctly  
✅ **FieldService Module** — `StockDeductionService` calls `InventoryService` correctly  
✅ **InventoryService Idempotency** — Uses `lockForUpdate()` + `balance_after` tracking  
✅ **Barcode Handling** — Deterministic, read-only, no mutation path  

---

## Recommended Fix Order

### Phase 1 — Blocker Fixes (CRITICAL)

1. **Fix Sales Integration (CRITICAL-002)**
   - Add `InventoryService` call to `SalesOrderService::fulfilOrder()`
   - Deduct stock for each order line on fulfillment
   - Add idempotency guard (check existing `StockMovement` records)

2. **Fix Loyalty Integration (CRITICAL-001)**
   - Remove `loyalty_rewards.stock_quantity` field
   - Use `stock_levels` instead (single source of truth)
   - Route all loyalty reward stock changes through `InventoryService`

3. **Fix Product Writable Field (CRITICAL-003)**
   - Remove `stock_quantity` from `Product::$fillable` array
   - Make `stock_quantity` read-only (computed from `stock_levels`)
   - Add database constraint to prevent direct updates

### Phase 2 — Hardening (HIGH)

4. **Fix Product::adjustStock() Deprecation (HIGH-001)**
   - Make `Product::adjustStock()` private or remove entirely
   - Force all callers to use `InventoryService::adjustStock()` directly
   - Add static analysis rule to prevent direct calls

### Phase 3 — Verification

5. **Add Regression Tests**
   - Test: Sales fulfillment deducts stock
   - Test: Loyalty redemption routes through `InventoryService`
   - Test: Direct `Product::update(['stock_quantity' => X])` fails
   - Test: Idempotency (duplicate fulfillment does not double-deduct)

6. **Re-run WS-04 Audit**
   - Verify all bypass paths removed
   - Verify all modules route through `InventoryService`
   - Verify `products.stock_quantity` is read-only

---

## Gate Impact

**G3 (Domain Ownership Truth) NOT SATISFIED**

WS-04 blocks:
- **WS-06 (Unified Channel)** — cannot close while inventory mutations inconsistent
- **WS-08 (Accounting)** — cannot close while stock truth unreliable
- **WS-09 (Reconciliation)** — cannot close while inventory non-deterministic

---

## Evidence Confidence

**HIGH** — All findings validated with direct code evidence.

**Methodology:**
- Full file reads for all core services
- Grep searches for direct stock mutations
- Mutation path traces from trigger to table write
- No assumptions or inferences without code evidence

**Files Read:** 10 core files + 6 integration files  
**Search Queries:** 4 comprehensive searches  
**Mutation Traces:** 6 complete traces  

---

## Authority

- **Steering:** `.kiro/steering/06-briefs.md` (WS-04)
- **Fast-Fail Checks:** `.kiro/steering/08-checks.md` (FF-08)
- **Evidence Standard:** `.kiro/steering/03-evidence.md`
- **Audit Date:** 2026-04-25
- **Auditor:** Kiro AI (Tier 1 Hardening)

---

## Next Steps

1. Review findings with development team
2. Prioritize CRITICAL-001, CRITICAL-002, CRITICAL-003
3. Implement Phase 1 fixes
4. Add regression tests (Phase 3)
5. Re-run WS-04 audit
6. Verify G3 gate satisfaction

---

**For detailed findings, see:** [WS-04-HOSTILE-AUDIT-REPORT.md](WS-04-HOSTILE-AUDIT-REPORT.md)
