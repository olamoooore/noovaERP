# Baseline SHA256 References

| Artifact | SHA256 |
|---|---|
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip` | `f2f8c244e2713f47e7ea3879eaf3d2b1c1b495a139f048d00bb64d7733cb132d` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part01.zip` | `7dd4210657f4c36937255793991a2872791e04e4acb9a367adbb4027eefed40b` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part02.zip` | `26e0a216ea75c3116ff8c15ee1957a61ad7006a5b7c6daa0158f8b92eca2cf36` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part03.zip` | `68447e1fce5dfcb418dc4fe0e867a1e9102b5992e4856ed3afb812954abd8b89` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_1_split_manifest.md` | `18a301fe568b71ab1f97228af2dd32eb752daaa70f6f0147bb31d6fe60847d29` |
| `ace_nova_pos_safe_lane_repository_initialization_pack_v1.zip` | `2ed47819d8d42a28513735a7145a472c0e16b0370192214e572bdc0f58fcad7c` |

## Active-source rule

The engineering source is `/active_source/`, derived from the accepted v4.5.1 active-only pack.

This bootstrap package is not production-ready and not unrestricted engineer-handover-ready.
