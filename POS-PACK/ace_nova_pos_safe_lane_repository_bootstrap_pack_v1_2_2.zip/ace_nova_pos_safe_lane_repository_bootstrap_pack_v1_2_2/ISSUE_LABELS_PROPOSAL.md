# Issue Labels Proposal

| Label | Purpose |
|---|---|
| `safe-lane` | Allowed safe-lane work only |
| `production-lock` | Work touches or references a locked production domain |
| `blocked-domain` | Domain is blocked until decision closure |
| `validation` | Validator, CI, or validation evidence work |
| `fixture` | Fixture changes |
| `simulator` | Local simulator harness work |
| `event-schema` | Event schema or fixture governance |
| `openapi` | OpenAPI safe-lane contracts |
| `security-scan` | Forbidden-pattern and security scanner work |
| `architecture-guardrail` | Architecture rule enforcement |
| `do-not-build` | Explicitly blocked implementation |
| `needs-decision` | Requires decision owner or approval owner |
