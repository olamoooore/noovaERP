# Repository Acceptance Gate

> **Pack:** ACE Nova POS Safe-Lane Repository Bootstrap Pack v1.2.2  
> **Purpose:** Minimum acceptance gate before repository is considered onboarded  
> **Production posture:** Production behavior remains blocked.

The repository is not accepted until all items below are complete.

## Required gate checks

- [ ] Active source hash verified.
- [ ] `make validate` passes.
- [ ] `make prove-failures` passes.
- [ ] `bootstrap_repository.sh` passes.
- [ ] Owner assignment completed.
- [ ] Branch protection configured.
- [ ] PR template installed.
- [ ] Production-lock labels configured.
- [ ] Baseline tag `safe-lane-v4.5.1-baseline` applied.
- [ ] SAFE-* backlog imported.
- [ ] ONBOARD-* issues imported.

## Rejection conditions

Reject repository onboarding if:

- frozen archives are imported;
- nested ZIPs are imported;
- `__pycache__/` or `*.pyc` files exist;
- validation evidence is missing;
- production locks are weakened;
- active source differs from accepted v4.5.1 active-only baseline without approved defect evidence.

## Status after passing gate

- Repository bootstrap: READY
- Repository acceptance gate: READY
- Active source baseline: v4.5.1 active-only pack
- Safe-lane engineering only: READY WITH SCOPE RESTRICTIONS
- Unrestricted engineer implementation: NOT READY
- Production build: NOT READY


## Bootstrap invocation

```bash
bash bootstrap_repository.sh
```

If direct execution is required by local policy, run:

```bash
chmod +x bootstrap_repository.sh
```

Then still use the documented command:

```bash
bash bootstrap_repository.sh
```
