> **Pack:** ACE Nova POS Safe-Lane Repository Bootstrap Pack v1.2.2

# HANDOVER_STATUS.md


## Bootstrap invocation

```bash
bash bootstrap_repository.sh
```

If direct execution is required by local policy, run:

```bash
chmod +x bootstrap_repository.sh
```

Then still use the documented command:

```bash
bash bootstrap_repository.sh
```
