#!/usr/bin/env bash
set -euo pipefail

echo "ACE Nova POS Safe-Lane Repository Bootstrap Pack v1"
echo "Checking active source..."

if [ ! -d "active_source" ]; then
  echo "ERROR: active_source/ missing"
  exit 1
fi

if [ ! -f "active_source/Makefile" ]; then
  echo "ERROR: active_source/Makefile missing"
  exit 1
fi

if [ ! -d "active_source/scripts" ] || [ ! -d "active_source/src" ] || [ ! -d "active_source/contracts" ] || [ ! -d "active_source/tests" ]; then
  echo "ERROR: active_source required folders missing"
  exit 1
fi

echo "Checking forbidden packaged artifacts..."
if find . -path "*/00_FROZEN_*" -print -quit | grep -q .; then
  echo "ERROR: frozen archive folder found"
  exit 1
fi

if find . -name "*.zip" -print -quit | grep -q .; then
  echo "ERROR: nested ZIP found inside bootstrap package"
  exit 1
fi

if find . -name "__pycache__" -type d -print -quit | grep -q .; then
  echo "ERROR: __pycache__ found"
  exit 1
fi

if find . -name "*.pyc" -print -quit | grep -q .; then
  echo "ERROR: *.pyc found"
  exit 1
fi

echo "Running active source validation..."
( cd active_source && make validate )

echo "Running active source failure-proof validation..."
( cd active_source && make prove-failures )

echo "Baseline SHA256 references:"
echo "active-only ZIP: f2f8c244e2713f47e7ea3879eaf3d2b1c1b495a139f048d00bb64d7733cb132d"
echo "part01 ZIP: 7dd4210657f4c36937255793991a2872791e04e4acb9a367adbb4027eefed40b"
echo "part02 ZIP: 26e0a216ea75c3116ff8c15ee1957a61ad7006a5b7c6daa0158f8b92eca2cf36"
echo "part03 ZIP: 68447e1fce5dfcb418dc4fe0e867a1e9102b5992e4856ed3afb812954abd8b89"
echo "split manifest: 18a301fe568b71ab1f97228af2dd32eb752daaa70f6f0147bb31d6fe60847d29"

echo ""
echo "PRODUCTION LOCK WARNING:"
echo "The following domains remain blocked:"
echo "- live payment provider behavior"
echo "- settlement reconciliation"
echo "- fiscal/e-invoice behavior"
echo "- refund settlement"
echo "- offline finalized refund"
echo "- production replay"
echo "- customer cache/privacy"
echo "- intercompany inventory"
echo "- finance-authoritative reporting"
echo "- live external adapters"
echo "- production monitoring/SOP closure"

echo ""
echo "Bootstrap validation complete."
echo "Repository bootstrap: READY"
echo "Unrestricted engineer implementation: NOT READY"
echo "Production build: NOT READY"
