# Repo Import Checklist

- [ ] Copy `/active_source` contents into repository root.
- [ ] Copy `/onboarding_governance` contents into `/docs/onboarding/`.
- [ ] Run `bash bootstrap_repository.sh`.
- [ ] Create git initial commit only after validation passes.
- [ ] Apply baseline tag: `safe-lane-v4.5.1-baseline`.
- [ ] Import ONBOARD-* issues.
- [ ] Import SAFE-* backlog.
- [ ] Configure branch protection.
- [ ] Configure PR template/checklist.
- [ ] Configure production-lock labels.
- [ ] Confirm no frozen archives were imported.
- [ ] Confirm no nested ZIPs were imported.
- [ ] Confirm no `__pycache__` or `*.pyc` files exist.

## Optional direct execution

If direct execution is required locally:

```bash
chmod +x bootstrap_repository.sh
./bootstrap_repository.sh
```

The canonical documented command remains:

```bash
bash bootstrap_repository.sh
```
