# Branch Protection Proposal

## Main branch rules

- Require `make validate` as a status check.
- Require PR review before merge.
- Require production-lock review for `blocked-domain`, `production-lock`, `do-not-build`, or `needs-decision` labels.
- Block direct push to `main`.
- Require status checks before merge.
- Signed commits: recommended.
- CODEOWNERS: recommended.

## Required checks

- `make validate`
- `make prove-failures` when validators, schemas, fixtures, OpenAPI, workflow tests, scanner rules, or failure-proof examples changed.

## Merge rule

No merge if the PR weakens production locks or removes TODO-BLOCKERs without approved exception evidence.
