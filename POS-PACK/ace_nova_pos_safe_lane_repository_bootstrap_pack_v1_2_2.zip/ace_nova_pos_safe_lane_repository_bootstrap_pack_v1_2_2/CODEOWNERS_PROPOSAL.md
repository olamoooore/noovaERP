# CODEOWNERS Proposal

```text
# Validation and automation
/scripts/                         @qa-automation @security-review

# API and schema contracts
/contracts/                       @architecture-review @event-contract-owner

# Tests and fixtures
/tests/                           @qa-automation @engineering-lead

# Local-only simulator harness
/src/simulators/                  @engineering-lead @architecture-review

# Control documentation
/docs/controls/                   @product-architecture @release-controller

# Security evidence and scanning
/SECURITY/                        @security-review

# Database drafts
/database/                        @database-owner @architecture-review

# Root governance files
/PR_REVIEW_CHECKLIST.md           @engineering-lead @release-controller
/SAFE_LANE_SCOPE_CONTRACT.md      @product-architecture @engineering-lead
/PRODUCTION_LOCKS_REMAINING.md    @product-architecture @security-review
```

## Note

These are proposed team handles. Replace them with actual repository teams during onboarding.
