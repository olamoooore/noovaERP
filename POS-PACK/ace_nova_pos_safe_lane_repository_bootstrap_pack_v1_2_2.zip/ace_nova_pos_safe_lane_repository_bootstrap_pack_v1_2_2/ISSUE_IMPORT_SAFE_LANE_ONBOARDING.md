# Issue Import: Safe-Lane Onboarding

> **Pack:** ACE Nova POS Safe-Lane Repository Initialization Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Purpose:** Repository onboarding governance and initialization instructions  
> **Active source:** v4.5.1 active-only pack  
> **Production posture:** Production behavior remains blocked.

## ONBOARD-001: Create repository from active-only pack

- **Owner role:** Repository Owner
- **Labels:** `safe-lane,onboarding,P0`
- **Priority:** High
- **Acceptance criteria:** Repository contains only active-only safe-lane files; no frozen archives or nested ZIPs.
- **Validation evidence:** Initial commit evidence; file tree review; active-only hash recorded.
- **Blocked production warning:** Do not import production artifacts or historical ZIPs.

## ONBOARD-002: Set up validation CI

- **Owner role:** DevOps Lead
- **Labels:** `safe-lane,ci,validation,P0`
- **Priority:** High
- **Acceptance criteria:** CI runs `make validate` on every PR.
- **Validation evidence:** CI log showing pass.
- **Blocked production warning:** CI must not deploy or call live services.

## ONBOARD-003: Add optional failure-proof CI job

- **Owner role:** QA Automation Lead
- **Labels:** `safe-lane,ci,validation,P1`
- **Priority:** Medium
- **Acceptance criteria:** Controlled job runs `make prove-failures` for validator/control changes.
- **Validation evidence:** CI log showing intentional bad examples fail.
- **Blocked production warning:** Failure-proof job is control validation only.

## ONBOARD-004: Enforce PR checklist

- **Owner role:** Engineering Lead
- **Labels:** `safe-lane,process,pr,P0`
- **Priority:** High
- **Acceptance criteria:** PR checklist and evidence template are required.
- **Validation evidence:** Branch protection or PR template evidence.
- **Blocked production warning:** Do not approve PRs that weaken locks.

## ONBOARD-005: Assign safe-lane backlog owners

- **Owner role:** Engineering Manager
- **Labels:** `safe-lane,backlog,P0`
- **Priority:** High
- **Acceptance criteria:** SAFE-* backlog has accountable owners.
- **Validation evidence:** Owner map or issue assignment evidence.
- **Blocked production warning:** Do not create production-domain implementation tickets.

## ONBOARD-006: Assign simulator gap ownership

- **Owner role:** Architecture Owner
- **Labels:** `safe-lane,simulator,P1`
- **Priority:** Medium
- **Acceptance criteria:** Each simulator gap has owner and validation expectation.
- **Validation evidence:** Updated gap tracker.
- **Blocked production warning:** Simulator gaps do not unlock production.

## ONBOARD-007: Enforce production locks

- **Owner role:** Product Architect
- **Labels:** `safe-lane,governance,P0`
- **Priority:** High
- **Acceptance criteria:** Production-lock labels/rules exist.
- **Validation evidence:** Issue labels and PR rule evidence.
- **Blocked production warning:** Production domains remain blocked.

## ONBOARD-008: Verify release manifest process

- **Owner role:** Release Controller
- **Labels:** `safe-lane,release,P1`
- **Priority:** Medium
- **Acceptance criteria:** Manifest generation and hash verification documented.
- **Validation evidence:** Manifest command output.
- **Blocked production warning:** Manifest evidence is not production certification.

## ONBOARD-009: Maintain security scan rules

- **Owner role:** Security Reviewer
- **Labels:** `safe-lane,security,P0`
- **Priority:** High
- **Acceptance criteria:** Forbidden-pattern scanner remains active.
- **Validation evidence:** `make validate` and `make prove-failures` evidence.
- **Blocked production warning:** Passing scan does not unlock live integrations.

## ONBOARD-010: Govern event fixtures

- **Owner role:** Event Contract Owner
- **Labels:** `safe-lane,event-contracts,P1`
- **Priority:** Medium
- **Acceptance criteria:** Event fixture governance is assigned and enforced.
- **Validation evidence:** Fixture review and validation output.
- **Blocked production warning:** Production event certification remains blocked.

## ONBOARD-011: Own workflow negative tests

- **Owner role:** QA Lead
- **Labels:** `safe-lane,qa,workflow,P0`
- **Priority:** High
- **Acceptance criteria:** Workflow negative tests have owner and review process.
- **Validation evidence:** Workflow test evidence from `make validate`.
- **Blocked production warning:** Do not replace negative-first controls with happy-path demos.
