# Bootstrap Quickstart

> **Pack:** ACE Nova POS Safe-Lane Repository Bootstrap Pack v1.2.2  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Purpose:** Documentation-polish patch for repository bootstrap execution  
> **Production posture:** Production behavior remains blocked.

## 1. Unzip the bootstrap pack

```bash
unzip ace_nova_pos_safe_lane_repository_bootstrap_pack_v1_2_2.zip
cd ace_nova_pos_safe_lane_repository_bootstrap_pack_v1_2_2
```

## 2. Inspect `/active_source`

```bash
ls active_source
```

## 3. Run bootstrap validation

The documented command is:

```bash
bash bootstrap_repository.sh
```

## 4. Optional direct execution

If your local policy requires direct execution, first run:

```bash
chmod +x bootstrap_repository.sh
./bootstrap_repository.sh
```

Do not assume direct execution works unless executable mode is present.

## 5. Create the engineering repository

Copy the contents of `/active_source` into the repository root.

## 6. Copy governance docs

Copy `/onboarding_governance` into:

```text
/docs/onboarding/
```

## 7. Configure repository controls

- Install branch protection.
- Import ONBOARD-* issues.
- Import SAFE-* backlog.
- Configure PR checklist.
- Configure production-lock labels.

## 8. Apply baseline tag

After validation passes and the first commit is created:

```bash
git tag safe-lane-v4.5.1-baseline
```

## 9. Validate before first commit

Inside the repository root:

```bash
make validate
make prove-failures
```

## Production-lock warning

Do not unlock:

- live payment provider behavior
- settlement reconciliation
- fiscal/e-invoice behavior
- refund settlement
- offline finalized refund
- production replay
- customer cache/privacy
- intercompany inventory
- finance-authoritative reporting
- live external adapters
- production monitoring/SOP closure
