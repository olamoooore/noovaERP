# ACE Nova POS Safe-Lane Repository Bootstrap Pack v1.2.2

> **Pack:** ACE Nova POS Safe-Lane Repository Bootstrap Pack v1.2.2  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Purpose:** Repository bootstrap documentation-polish patch  
> **Active source folder:** `/active_source/`  
> **Governance folder:** `/onboarding_governance/`  
> **Production posture:** Production behavior remains blocked.

## Status

| Area | Status |
|---|---|
| Repository bootstrap | READY |
| Repository acceptance gate | READY |
| Active source baseline | v4.5.1 active-only pack |
| Safe-lane engineering only | READY WITH SCOPE RESTRICTIONS |
| Unrestricted engineer implementation | NOT READY |
| Production build | NOT READY |

## Bootstrap command

Use:

```bash
bash bootstrap_repository.sh
```

If direct execution is required locally:

```bash
chmod +x bootstrap_repository.sh
./bootstrap_repository.sh
```

Do not assume direct execution works unless executable mode is present.

## Patch scope

v1.2.2 fixes stale version text and quickstart paths only.

It does not change `/active_source` behavior, validators, simulator behavior, event schemas, workflow tests, production locks, or accepted baseline hashes.

## Production locks

- live payment provider behavior
- settlement reconciliation
- fiscal/e-invoice behavior
- refund settlement
- offline finalized refund
- production replay
- customer cache/privacy
- intercompany inventory
- finance-authoritative reporting
- live external adapters
- production monitoring/SOP closure
