Initialize ACE Nova POS safe-lane repository baseline

Baseline artifact:
- ACE Nova POS Safe-Lane Execution Pack v4.5.1 active-only pack

Active-only ZIP SHA256:
- f2f8c244e2713f47e7ea3879eaf3d2b1c1b495a139f048d00bb64d7733cb132d

Validation evidence:
- make validate: PASS
- make prove-failures: PASS
- bootstrap_repository.sh: PASS

Scope:
- Safe-lane engineering only
- Local simulator harness
- Validators
- Fixtures
- Negative workflow tests
- Governance docs

Production-lock warning:
- Not production-ready
- Not unrestricted engineer-handover-ready
- No live payment provider behavior
- No settlement reconciliation
- No fiscal/e-invoice behavior
- No refund settlement
- No offline finalized refund
- No production replay
- No customer cache/privacy implementation
- No intercompany inventory
- No finance-authoritative reporting
- No live external adapters
- No production monitoring/SOP closure
