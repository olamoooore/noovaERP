# Repository Initialization Instructions

> **Pack:** ACE Nova POS Safe-Lane Repository Initialization Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Purpose:** Repository onboarding governance and initialization instructions  
> **Active source:** v4.5.1 active-only pack  
> **Production posture:** Production behavior remains blocked.


## Source artifact

Use the v4.5.1 active-only ZIP as the repository source:

```text
ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip
```

SHA256:

```text
f2f8c244e2713f47e7ea3879eaf3d2b1c1b495a139f048d00bb64d7733cb132d
```

## Do not use frozen archives

Do not use:

- frozen full ZIPs;
- historical archives;
- nested ZIPs;
- onboarding wrapper ZIP as source.

## Initialize repository

```bash
mkdir ace-nova-pos-safe-lane
cd ace-nova-pos-safe-lane
unzip ../ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip
```

If the ZIP extracts into a folder, move the contents of the extracted folder into the repository root.

## Add onboarding docs

Copy onboarding docs into:

```text
docs/onboarding/
```

Recommended source:

```text
governance_onboarding_docs/
```

## Validate before first commit

```bash
make validate
make prove-failures
```

Do not commit until both commands pass.

## Initial commit

Commit only the active-only repository source plus onboarding docs under `docs/onboarding/`.

Do not commit frozen ZIPs or nested ZIPs.

## Tag initial baseline

Suggested tag:

```text
safe-lane-v4.5.1-baseline
```

## Record hashes

Record:

```text
active-only ZIP SHA256: f2f8c244e2713f47e7ea3879eaf3d2b1c1b495a139f048d00bb64d7733cb132d
split manifest SHA256: 18a301fe568b71ab1f97228af2dd32eb752daaa70f6f0147bb31d6fe60847d29
```

## Production lock rule

If a blocked production domain is needed, stop and follow the production-lock exception process.
