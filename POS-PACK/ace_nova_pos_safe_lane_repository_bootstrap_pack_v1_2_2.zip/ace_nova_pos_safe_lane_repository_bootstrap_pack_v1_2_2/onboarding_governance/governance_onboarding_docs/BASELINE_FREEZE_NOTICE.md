# Baseline Freeze Notice

> **Pack:** ACE Nova POS Safe-Lane Engineering Onboarding Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Baseline status:** Controlled safe-lane engineer handover baseline  
> **Engineering source:** Active-only pack only  
> **Production posture:** Production behavior remains blocked.


## Frozen accepted baseline

The accepted baseline is:

```text
ACE Nova POS Safe-Lane Execution Pack v4.5.1
Controlled safe-lane engineer handover baseline
Active-only engineering source
```

## Status retained

| Area | Status |
|---|---|
| Controlled safe-lane engineer handover | READY WITH SCOPE RESTRICTIONS |
| Unrestricted engineer implementation | NOT READY |
| Production build | NOT READY |

## Active-only source rule

Engineering repository onboarding must use the active-only pack only:

```text
ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip
```

Frozen full packs and historical ZIPs are evidence only.

## Change control

Do not change the accepted baseline unless there is a real defect.

Metadata correction is allowed only when it does not modify active repository behavior.
