# Safe-Lane Sprint 1 Plan

> **Pack:** ACE Nova POS Safe-Lane Engineering Onboarding Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Baseline status:** Controlled safe-lane engineer handover baseline  
> **Engineering source:** Active-only pack only  
> **Production posture:** Production behavior remains blocked.


## Sprint goal

Establish the controlled safe-lane repository, CI validation, PR governance, owner assignment, and first safe-lane execution controls without touching production domains.

## Selected tickets

| Ticket | Owner | Sprint objective |
|---|---|---|
| ONBOARD-001 | Repository Owner | Create repository from active-only pack only |
| ONBOARD-002 | DevOps Lead | Set up `make validate` CI |
| ONBOARD-003 | QA Automation Lead | Add controlled `make prove-failures` job |
| ONBOARD-004 | Engineering Lead | Enforce PR checklist and evidence template |
| ONBOARD-005 | Engineering Manager | Assign SAFE-* backlog owners |
| ONBOARD-006 | Architecture Owner | Assign simulator gap ownership |
| ONBOARD-007 | Product Architect | Enforce production-lock labels/rules |
| ONBOARD-008 | Release Controller | Verify release manifest process |

## Expected validation evidence

Every completed ticket must include:

- command output from `make validate`;
- command output from `make prove-failures` when control logic changed;
- PR checklist evidence;
- confirmation that production locks were not weakened.

## Blocked production domains

- live payment provider behavior
- settlement reconciliation
- fiscal/e-invoice behavior
- refund settlement
- offline finalized refund
- production replay
- customer cache/privacy
- intercompany inventory
- finance-authoritative reporting
- live external adapters
- production monitoring/SOP closure

## Demo rules

Demos may show only:

- local validation commands;
- failure-proof controls;
- safe-lane workflow tests;
- repository onboarding controls;
- issue/PR governance.

Demos must not show live integrations, production payment/fiscal/settlement/replay behavior, or production reporting.

## PR review requirements

- Use `PR_EVIDENCE_TEMPLATE.md`.
- Pass `make validate`.
- Run `make prove-failures` for validation/control/schema/scanner changes.
- Confirm blocked domains remain untouched.
