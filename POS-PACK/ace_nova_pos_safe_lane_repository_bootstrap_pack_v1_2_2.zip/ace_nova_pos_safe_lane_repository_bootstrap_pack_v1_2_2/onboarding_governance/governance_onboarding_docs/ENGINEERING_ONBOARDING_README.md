# Engineering Onboarding README

> **Pack:** ACE Nova POS Safe-Lane Engineering Onboarding Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Baseline status:** Controlled safe-lane engineer handover baseline  
> **Engineering source:** Active-only pack only  
> **Production posture:** Production behavior remains blocked.


## What to use

Use only:

```text
ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip
```

## What not to import

Do not import:

- frozen ZIPs;
- full historical packs;
- nested ZIPs;
- generated cache artifacts;
- production adapters;
- live service clients.

## First command after extract

```bash
make validate
```

## Before control changes

Run:

```bash
make prove-failures
```

Use this before merging changes to validators, scanners, schemas, OpenAPI contracts, workflow tests, or failure-proof examples.

## PR evidence

Attach validation evidence to every PR.

Required evidence:

- `make validate` output;
- `make prove-failures` output when applicable;
- changed file list;
- production-lock impact statement;
- reviewer checklist.

## Hard prohibitions

Do not wire live services.

Do not implement production domains.

Do not rename simulator APIs into production APIs.

Do not remove TODO-BLOCKERs without approved exception evidence.

## Ticket rule

Use safe-lane tickets only. Production-domain tickets remain blocked until formal decision closure.
