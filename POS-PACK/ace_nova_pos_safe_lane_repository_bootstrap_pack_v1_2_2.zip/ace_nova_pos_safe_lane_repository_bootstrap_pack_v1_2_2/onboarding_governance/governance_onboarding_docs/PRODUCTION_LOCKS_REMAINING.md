# Production Locks Remaining

> **Pack:** ACE Nova POS Safe-Lane Engineering Onboarding Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Baseline status:** Controlled safe-lane engineer handover baseline  
> **Engineering source:** Active-only pack only  
> **Production posture:** Production behavior remains blocked.


The following production domains remain blocked:

- live payment provider behavior
- settlement reconciliation
- fiscal/e-invoice behavior
- refund settlement
- offline finalized refund
- production replay
- customer cache/privacy
- intercompany inventory
- finance-authoritative reporting
- live external adapters
- production monitoring/SOP closure

No exception is allowed by engineer discretion. Use the production-lock exception process from the active-only pack.
