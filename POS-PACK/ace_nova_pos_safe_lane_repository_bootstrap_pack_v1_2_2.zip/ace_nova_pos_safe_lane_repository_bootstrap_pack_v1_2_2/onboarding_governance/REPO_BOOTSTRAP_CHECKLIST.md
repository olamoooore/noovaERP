# Repository Bootstrap Checklist

> **Pack:** ACE Nova POS Safe-Lane Repository Initialization Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Purpose:** Repository onboarding governance and initialization instructions  
> **Active source:** v4.5.1 active-only pack  
> **Production posture:** Production behavior remains blocked.


- [ ] Active-only ZIP hash verified.
- [ ] Split parts reconstructed if needed.
- [ ] No frozen archives imported.
- [ ] No nested ZIPs imported.
- [ ] No `__pycache__/` or `*.pyc`.
- [ ] `make validate` passed.
- [ ] `make prove-failures` passed.
- [ ] Branch protection configured.
- [ ] PR checklist enabled.
- [ ] Production-lock labels configured.
- [ ] SAFE-* backlog imported.
- [ ] ONBOARD-* issue set imported.
- [ ] Baseline tag proposed or created.
- [ ] Active-only ZIP SHA256 recorded.
- [ ] Split manifest hash recorded.
