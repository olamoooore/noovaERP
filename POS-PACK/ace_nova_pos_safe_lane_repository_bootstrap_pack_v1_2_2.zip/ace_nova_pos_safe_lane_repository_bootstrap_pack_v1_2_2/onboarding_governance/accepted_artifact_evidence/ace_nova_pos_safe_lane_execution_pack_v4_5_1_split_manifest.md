# ACE Nova POS Safe-Lane Execution Pack v4.5.1 Split Manifest Correction

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Version:** v4.5.1 manifest-correction patch  
> **Prepared:** 2026-05-16  
> **Scope:** Split metadata correction only  
> **Production posture:** Production behavior remains blocked.

## Purpose

This manifest corrects the split-package SHA256 metadata for the accepted v4.5 active-only safe-lane handover baseline.

No validators, simulator behavior, event schemas, workflow tests, production locks, or active repository source files were changed.

## Corrected artifact hashes

| Artifact | SHA256 |
|---|---|
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip` | `f2f8c244e2713f47e7ea3879eaf3d2b1c1b495a139f048d00bb64d7733cb132d` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part01.zip` | `7dd4210657f4c36937255793991a2872791e04e4acb9a367adbb4027eefed40b` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part02.zip` | `26e0a216ea75c3116ff8c15ee1957a61ad7006a5b7c6daa0158f8b92eca2cf36` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part03.zip` | `68447e1fce5dfcb418dc4fe0e867a1e9102b5992e4856ed3afb812954abd8b89` |

## Part coverage

| Part | Size bytes | File count | SHA256 | Top-level coverage |
|---|---:|---:|---|---|
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part01.zip` | 51,567 | 42 | `7dd4210657f4c36937255793991a2872791e04e4acb9a367adbb4027eefed40b` | .github, ACTIVE_ONLY_REVIEW_EVIDENCE.md, BASELINE_ACCEPTANCE_NOTE.md, CI_OPERATIONAL_NOTE.md, CONTRIBUTING_SAFE_LANE.md, CONTROLLED_ENGINEER_HANDOVER_NOTE.md, DEPENDENCY_MANIFEST.md, ENGINEERING_REPOSITORY_ONBOARDING_CHECKLIST.md, FROZEN_ARCHIVE_ACCESS_POLICY.md, Makefile, PRODUCTION_LOCK_EXCEPTION_PROCESS.md, PR_EVIDENCE_TEMPLATE.md, PR_REVIEW_CHECKLIST.md, README.md, RELEASE_MANIFEST.txt, RELEASE_MANIFEST_RULES.md, RELEASE_MANIFEST_SHA256.txt, SAFE_LANE_BACKLOG_STATUS.md, SAFE_LANE_ENGINEERING_BACKLOG.md, SAFE_LANE_RISK_REGISTER.md, SAFE_LANE_SCOPE_CONTRACT.md, SECURITY, SIMULATOR_GAP_REGISTER.md, STATE_COVERAGE_REPORT.md, VALIDATION_QUALITY_REPORT.md, docs |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part02.zip` | 78,362 | 101 | `26e0a216ea75c3116ff8c15ee1957a61ad7006a5b7c6daa0158f8b92eca2cf36` | scripts, src, tests |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part03.zip` | 90,739 | 126 | `68447e1fce5dfcb418dc4fe0e867a1e9102b5992e4856ed3afb812954abd8b89` | contracts, database |

## Reconstruction verification

The existing split parts were extracted into one folder and compared against the active-only ZIP by relative file path and SHA256.

```text
Reconstructed parts match active-only ZIP content: PASS
```

## Validation verification

Active-only clean extract:

```text
make validate: PASS
make prove-failures: PASS
```

Reconstructed from split parts:

```text
make validate: PASS
make prove-failures: PASS
```

## Exclusion verification

Confirmed:

- no nested ZIP files in the active-only pack;
- no frozen archives in the active-only pack;
- no `__pycache__/` directories;
- no `*.pyc` files.

## Reconstruction instructions

```bash
mkdir reconstructed_v4_5_active_only
unzip ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part01.zip -d reconstructed_v4_5_active_only
unzip ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part02.zip -d reconstructed_v4_5_active_only
unzip ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part03.zip -d reconstructed_v4_5_active_only
cd reconstructed_v4_5_active_only/ace_nova_pos_safe_lane_execution_pack_v4_5_active_only
make validate
make prove-failures
```

## Production-lock status

Unchanged. The following domains remain blocked:

- live payment provider behavior;
- settlement reconciliation;
- fiscal/e-invoice behavior;
- refund settlement;
- offline finalized refund;
- production replay;
- customer cache/privacy;
- intercompany inventory;
- finance-authoritative reporting;
- live external adapters;
- production monitoring/SOP closure.

## Final required status

| Area | Status |
|---|---|
| Controlled safe-lane engineer handover | READY WITH SCOPE RESTRICTIONS |
| Unrestricted engineer implementation | NOT READY |
| Production build | NOT READY |
