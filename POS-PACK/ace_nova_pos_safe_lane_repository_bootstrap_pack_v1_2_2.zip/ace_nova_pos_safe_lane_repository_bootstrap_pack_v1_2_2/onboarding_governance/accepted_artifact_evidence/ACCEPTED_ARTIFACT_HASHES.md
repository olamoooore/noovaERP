# Accepted Artifact Hashes

> **Pack:** ACE Nova POS Safe-Lane Repository Initialization Pack v1  
> **Baseline:** ACE Nova POS Safe-Lane Execution Pack v4.5.1  
> **Purpose:** Repository onboarding governance and initialization instructions  
> **Active source:** v4.5.1 active-only pack  
> **Production posture:** Production behavior remains blocked.


| Artifact | SHA256 |
|---|---|
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip` | `f2f8c244e2713f47e7ea3879eaf3d2b1c1b495a139f048d00bb64d7733cb132d` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part01.zip` | `7dd4210657f4c36937255793991a2872791e04e4acb9a367adbb4027eefed40b` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part02.zip` | `26e0a216ea75c3116ff8c15ee1957a61ad7006a5b7c6daa0158f8b92eca2cf36` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.part03.zip` | `68447e1fce5dfcb418dc4fe0e867a1e9102b5992e4856ed3afb812954abd8b89` |
| `ace_nova_pos_safe_lane_execution_pack_v4_5_1_split_manifest.md` | `18a301fe568b71ab1f97228af2dd32eb752daaa70f6f0147bb31d6fe60847d29` |
| `ace_nova_pos_safe_lane_engineering_onboarding_pack_v1.zip` | `dcb190dc38cf6ed4f6da5b2ba07e175ce70614e5cf836a2f00ee1144edf45773` |

## Active-source rule

The active engineering source remains:

```text
ace_nova_pos_safe_lane_execution_pack_v4_5_active_only.zip
```

This repository initialization pack is not the active source.
