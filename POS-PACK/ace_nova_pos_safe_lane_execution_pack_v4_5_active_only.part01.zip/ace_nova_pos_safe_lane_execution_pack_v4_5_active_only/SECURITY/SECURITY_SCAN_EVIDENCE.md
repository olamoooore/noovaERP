# Security Scan Evidence

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and controlled engineering-use governance  
> **Production posture:** Production behavior remains blocked.


## Scan commands

```bash
make validate
make prove-failures
python3 -S scripts/generate_release_manifest.py
```

## Active scan posture

Standalone validator scripts are canonical. The active validation path blocks common secrets, non-placeholder URLs, network-client patterns, generated cache artifacts, active binary artifacts, forbidden live-provider references, production implementation terms, and unsafe event extension examples.

## Frozen ZIP exclusion

All `00_FROZEN_*/` folders are excluded from release manifest generation and treated as evidence only.

## Failure-proof automation

`make prove-failures` validates bad examples for duplicate operation ID, missing fixture, non-placeholder URL, cache artifact, forbidden live provider term, invalid event fixtures, unsafe event extensions, and workflow mismatch.

## Findings

No active-source findings after validation.

## Remaining blocked domains

Live payment provider behavior, settlement reconciliation, fiscal/e-invoice behavior, refund settlement, offline finalized refund, production replay, customer cache/privacy, intercompany inventory, finance-authoritative reporting, live external adapters, and production monitoring/SOP closure remain blocked.
