# Simulator Gap Register

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Active-only safe-lane repository onboarding, validation harness, and controlled engineering governance  
> **Production posture:** Production behavior remains blocked.


| Gap ID | Gap | Owner | Priority | Validation required | Production-lock status |
|---|---|---|---|---|---|
| GAP-001 | Full cart lifecycle gap | Backend Lead | Medium | Add cart lifecycle negative workflows | Production cart behavior blocked outside safe-lane |
| GAP-002 | Full payment ledger gap | Finance/Payment Owner | High | Add synthetic ledger invariants and split-tender tests | Live payment and settlement blocked |
| GAP-003 | Full refund lifecycle gap | Finance Owner | High | Add refund lifecycle negative workflows | Refund settlement blocked |
| GAP-004 | Full inventory retry queue gap | Inventory Owner | High | Add queue ordering and retry exhaustion tests | Direct inventory mutation blocked |
| GAP-005 | Replay/device trust lifecycle gap | Security Owner | High | Add revoked/expired/signature/order tests | Production replay blocked |
| GAP-006 | Approval escalation gap | Approval Owner | Medium | Add escalation/expiry/revocation tests | Full production approval lifecycle blocked |
| GAP-007 | Settlement/fiscal blocked-mode gap | Finance and Tax/Fiscal Owners | High | Add blocked-mode workflows only | Settlement and fiscal/e-invoice blocked |
| GAP-008 | Local DB recovery gap | Backend Owner | Medium | Add recovery/degraded-mode tests | Production local DB recovery blocked |
