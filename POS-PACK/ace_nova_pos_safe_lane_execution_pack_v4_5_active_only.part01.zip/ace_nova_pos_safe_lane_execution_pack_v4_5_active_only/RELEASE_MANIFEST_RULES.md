# Release Manifest Rules

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and handover controls  
> **Production posture:** Production behavior remains blocked.


## Exact command

```bash
python3 -S scripts/generate_release_manifest.py
```

## Active file inclusion rules

The release manifest includes active safe-lane files:

- contracts;
- fixtures;
- simulator source;
- validation scripts;
- workflow tests;
- negative tests;
- SQL drafts;
- port/interface specs;
- control documents;
- readiness documents;
- Makefile and CI scaffold.

## Exclusion rules

The release manifest excludes:

- any folder matching `00_FROZEN_*/`;
- `RELEASE_MANIFEST.txt`;
- `RELEASE_MANIFEST_SHA256.txt`;
- `__pycache__/`;
- `*.pyc`.

## Frozen ZIP evidence handling

Frozen ZIP files are retained only as historical evidence. They are not active implementation source and must not appear in `RELEASE_MANIFEST.txt`.

## Manifest verification command

```bash
python3 -S scripts/generate_release_manifest.py
sha256sum RELEASE_MANIFEST.txt
cat RELEASE_MANIFEST_SHA256.txt
```

The `sha256sum` output for `RELEASE_MANIFEST.txt` must match `RELEASE_MANIFEST_SHA256.txt`.

## Final ZIP hash warning

The final ZIP SHA256 is external evidence only. It is calculated after packaging and must not be embedded inside the ZIP as self-referential proof.
