# Contributing to the Safe-Lane Pack

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and controlled engineering-use governance  
> **Production posture:** Production behavior remains blocked.


## Add workflow tests

1. Add a JSON case under `tests/workflows/cases/`.
2. Include `test_id`, `domain`, `starting_state`, `step_sequence`, `expected_state`, `expected_error_code`, `expected_audit_event`, `expected_outbox_event`, `expected_reporting_label`, `forbidden_transition`, and `recovery_owner`.
3. Add a matching fixture under `contracts/fixtures/workflows/`.
4. Run `make validate`.

## Add event fixtures

1. Add valid fixtures under `contracts/fixtures/events/valid/`.
2. Add invalid fixtures under `contracts/fixtures/events/invalid/`.
3. Reference the correct `schema_file`.
4. Run `make validate`.

## Update schemas

1. Update the relevant schema under `contracts/events/`.
2. Keep payload strict unless an explicit `extensions` object is used.
3. Follow `docs/controls/EVENT_EXTENSION_GOVERNANCE.md`.
4. Run `make validate` and `make prove-failures` if validator behavior changed.

## Update simulator engines

1. Modify only local-only simulator behavior under `src/simulators/`.
2. Do not add live service calls.
3. Do not add production provider names.
4. Add or update workflow tests.
5. Run `make validate`.

## Run validators

```bash
make validate
make prove-failures
```

## Avoid production leakage

Do not add:

- live payment clients;
- settlement logic;
- fiscal/e-invoice logic;
- customer cache persistence;
- direct inventory mutation;
- production replay/device trust;
- live external adapters.

## Update release manifest

`make validate` runs manifest generation. For direct verification:

```bash
python3 -S scripts/generate_release_manifest.py
sha256sum RELEASE_MANIFEST.txt
cat RELEASE_MANIFEST_SHA256.txt
```

## Document limitations

Any new simulator behavior must update limitation, coverage, or risk documentation when it expands or clarifies scope.
