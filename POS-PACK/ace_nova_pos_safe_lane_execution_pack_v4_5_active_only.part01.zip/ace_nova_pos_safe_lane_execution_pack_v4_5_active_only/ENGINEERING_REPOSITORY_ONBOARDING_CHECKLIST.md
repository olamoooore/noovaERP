# Engineering Repository Onboarding Checklist

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Active-only safe-lane repository onboarding, validation harness, and controlled engineering governance  
> **Production posture:** Production behavior remains blocked.


- [ ] Create the repo from the active-only pack only.
- [ ] Do not import frozen ZIPs.
- [ ] Do not import nested ZIPs.
- [ ] Run `make validate`.
- [ ] Run `make prove-failures`.
- [ ] Review production locks.
- [ ] Review `SAFE_LANE_SCOPE_CONTRACT.md`.
- [ ] Review `PR_REVIEW_CHECKLIST.md`.
- [ ] Assign safe-lane owners.
- [ ] Block production-domain tickets.
- [ ] Require validation evidence on every PR.
