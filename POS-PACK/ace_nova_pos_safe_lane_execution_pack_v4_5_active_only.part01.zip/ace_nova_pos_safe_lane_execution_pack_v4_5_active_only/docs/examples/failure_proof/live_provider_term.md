This active-file proof mentions stripe as a forbidden live provider term.
