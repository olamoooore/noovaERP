import requests

def unsafe_network_call():
    return "docs-only failure proof"
