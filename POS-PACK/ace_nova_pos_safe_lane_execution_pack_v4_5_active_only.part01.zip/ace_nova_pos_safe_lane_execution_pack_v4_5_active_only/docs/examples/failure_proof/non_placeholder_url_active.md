This active-file proof contains a bad URL:
https://bad-active-url.example
