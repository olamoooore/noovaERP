# Production Contract Migration Plan

> **Pack:** ACE Nova POS Safe-Lane Execution Pack  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and handover controls  
> **Production posture:** Production behavior remains blocked.


## Purpose

This plan defines what must happen before safe-lane contracts can be replaced by production contracts.

## Required before production contracts

### 1. Domain-separated OpenAPI contracts

Create separate OpenAPI contracts for cart, payment, receipt, refund, inventory, replay, approval, reporting, admin, and integration domains.

Safe-lane simulator endpoints must not be renamed into production endpoints.

### 2. Standards-grade OpenAPI validation

Production OpenAPI certification requires a real OpenAPI validator and CI enforcement for:

- schema correctness;
- request/response validation;
- examples;
- auth and error contracts;
- versioning;
- backward compatibility.

### 3. Production event schema registry

Events must be registered in a production schema registry or equivalent governed repository.

### 4. Consumer contract tests

Every event and API consumer must have contract tests for valid, invalid, duplicate, replayed, out-of-order, and rejected messages.

### 5. Database migration framework

SQL drafts must be converted into reviewed migrations with rollback rules, tenant isolation tests, and migration evidence.

### 6. Security review

Security review must cover secrets, credential flow, device trust, replay signing, access control, audit immutability, privacy, and data retention.

### 7. Decision closure evidence

All affected open decisions must be closed with approval owner, evidence, test impact, and implementation impact.

### 8. Do-not-build gate closure

No production implementation may begin for blocked domains until the corresponding do-not-build gates are closed.

## Explicitly blocked promotion

Safe-lane contracts must not be promoted to production for:

- live payment providers;
- settlement;
- fiscal/e-invoice;
- refund settlement;
- offline finalized refund;
- production replay;
- customer cache/privacy;
- intercompany inventory;
- finance-authoritative reporting;
- live external adapters;
- production monitoring/SOP closure.
