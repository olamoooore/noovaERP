# Event Extension Governance

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and engineering execution controls  
> **Production posture:** Production behavior remains blocked.


## Purpose

`payload.extensions` exists only for controlled, non-production-safe metadata that is not yet promoted into the event's canonical payload schema.

## Allowed use

Extensions may be used only when all of the following are true:

1. The field is non-sensitive.
2. The field is not required for financial, fiscal, settlement, refund, inventory ownership, audit authority, privacy, or reporting-authoritative behavior.
3. The producer and consumer both tolerate absence of the extension.
4. The extension is covered by a safe-lane test or explicitly documented as non-executable metadata.

## Namespacing rules

Extension keys must use reverse-domain or domain-prefix naming:

```json
{
  "extensions": {
    "safe_lane.payment.debug_reason": "timeout_simulation",
    "experimental.qa.fixture_id": "fixture_001"
  }
}
```

## Invalid unnamespaced extension

```json
{
  "extensions": {
    "debug_reason": "invalid_because_unnamespaced"
  }
}
```

## Invalid PII-bearing extension

```json
{
  "extensions": {
    "safe_lane.customer.email": "customer@example.invalid",
    "safe_lane.customer.phone": "+60000000000"
  }
}
```

Even placeholder-looking values are prohibited in active production-intent extensions when they represent PII fields.

## Invalid payment-sensitive extension

```json
{
  "extensions": {
    "safe_lane.payment.card_pan": "4111111111111111",
    "safe_lane.payment.auth_code": "AUTH123"
  }
}
```

Payment-sensitive values must never be carried in extensions.

## Producer responsibility

The producer must document extension name, owner, purpose, data classification, retention expectation, consumer impact, and removal/promotion plan.

## Consumer behavior

Consumers must ignore unknown extensions and must not require extension fields to process canonical safe-lane events.

## Schema versioning expectations

If an extension becomes required for business behavior, it must be promoted into the canonical payload schema with a new schema version and fixtures.

## Audit/logging rules

Extensions may be logged only if they are non-sensitive and explicitly classified as safe for audit logs.

## TODO-BLOCKER before production certification

Production event certification requires a production event schema registry, consumer contract tests, data classification review, audit review, security review, and closed do-not-build gates.
