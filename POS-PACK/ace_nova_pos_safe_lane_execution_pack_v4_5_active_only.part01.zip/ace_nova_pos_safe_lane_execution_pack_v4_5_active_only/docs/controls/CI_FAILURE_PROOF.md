# CI Failure Proof

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and handover controls  
> **Production posture:** Production behavior remains blocked.


## Executable proof command

```bash
make prove-failures
```

## Proof coverage

`make prove-failures` confirms that intentionally bad examples fail when copied into active paths.

Covered failure cases:

- invalid event fixture;
- duplicate `operationId`;
- missing OpenAPI fixture;
- non-placeholder URL in active non-OpenAPI file;
- cache artifact;
- forbidden live provider term;
- event fixture with extra field;
- event fixture missing required payload field;
- workflow expected state mismatch.

## Rule

Examples under `docs/examples/failure_proof/` are not active source. They are copied into temporary active paths only by `scripts/prove_validation_failures.py`, then removed.

## v4.3 additional failure cases

- invalid PII-bearing extension;
- invalid payment-sensitive extension.
