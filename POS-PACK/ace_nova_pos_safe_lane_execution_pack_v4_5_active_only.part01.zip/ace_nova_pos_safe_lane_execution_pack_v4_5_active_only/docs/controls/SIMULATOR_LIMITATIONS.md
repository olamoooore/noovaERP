# Simulator Limitations

> **Pack:** ACE Nova POS Safe-Lane Execution Pack  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and handover controls  
> **Production posture:** Production behavior remains blocked.


## What the simulator does

The local safe-lane simulator harness models selected negative workflows using deterministic, local-only rules.

It can:

- track state across workflow steps;
- reject known invalid transitions;
- track idempotency keys and payload hashes inside a test case;
- emit deterministic audit event names;
- emit deterministic outbox event names;
- emit reporting labels;
- preserve synthetic split-tender success state in negative tests;
- block receipt mutation after finalization;
- block offline finalized refund scenarios;
- reject invalid replay and cross-tenant replay scenarios.

## What the simulator does not model

The simulator does not model:

- real provider behavior;
- real settlement;
- fiscal/e-invoice production behavior;
- real inventory mutation;
- customer cache persistence;
- production replay;
- full approval lifecycle;
- full device trust lifecycle;
- real tax jurisdiction rules;
- real legal entity accounting;
- real payment authorization or capture;
- real refund settlement;
- production monitoring/SOP closure.

## Engineering warning

Passing simulator tests proves only that the safe-lane harness rejects defined negative scenarios. It does not prove the POS module is production-ready or unrestricted implementation-ready.
