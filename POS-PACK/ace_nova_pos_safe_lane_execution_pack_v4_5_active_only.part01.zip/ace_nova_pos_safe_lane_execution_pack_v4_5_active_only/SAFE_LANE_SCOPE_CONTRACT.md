# Safe-Lane Scope Contract

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and controlled engineering-use governance  
> **Production posture:** Production behavior remains blocked.


## Allowed engineering activities

- Add or maintain local-only simulator workflow tests.
- Add or maintain event fixtures.
- Add or maintain safe-lane event schemas.
- Add or maintain custom validators.
- Add or maintain simulator state engines.
- Add or maintain safe-lane ports and interface documentation.
- Add or maintain release-manifest and CI guardrails.
- Add or maintain limitation, risk, and state coverage documentation.

## Prohibited engineering activities

- Implement live payment provider behavior.
- Implement settlement reconciliation.
- Implement fiscal/e-invoice production behavior.
- Implement refund settlement.
- Implement offline finalized refund.
- Implement production replay.
- Persist real customer cache/privacy data.
- Mutate real inventory.
- Implement intercompany inventory.
- Implement finance-authoritative reporting.
- Implement live external adapters.
- Implement production monitoring/SOP closure.
- Rename simulator endpoints into production endpoints.

## Required validation before commit

```bash
make validate
```

Run this before every commit touching active files.

## Required validation evidence for PR review

Attach:

- `make validate` output;
- `make prove-failures` output when validators, event schemas, OpenAPI contracts, workflow tests, failure-proof examples, or scanner rules changed;
- manifest active-file count;
- summary of affected files;
- confirmation that no production lock was weakened.

## Production lock list

Production locks remain active for live payment, settlement, fiscal/e-invoice, refund settlement, offline finalized refund, production replay, customer cache/privacy, intercompany inventory, finance-authoritative reporting, live external adapters, and production monitoring/SOP closure.

## Escalation path for blocked domains

If a blocked domain is required:

1. Stop implementation.
2. Open a decision-closure request.
3. Identify affected do-not-build gate.
4. Obtain approval-owner evidence.
5. Add tests and contract evidence.
6. Update readiness status only after evidence exists.
