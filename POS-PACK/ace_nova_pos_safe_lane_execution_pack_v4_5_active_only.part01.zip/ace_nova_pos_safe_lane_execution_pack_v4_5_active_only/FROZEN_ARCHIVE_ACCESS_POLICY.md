# Frozen Archive Access Policy

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and controlled engineering-use governance  
> **Production posture:** Production behavior remains blocked.


## Policy

Frozen archives are evidence only.

Engineers must not copy implementation material from frozen ZIPs into active source.

## Manifest exclusion

All `00_FROZEN_*/` folders are excluded from the release manifest.

## Extraction rule

Any extraction of frozen archives must be documented with:

- reason;
- reviewer;
- date;
- files inspected;
- active files regenerated;
- validation evidence.

## Regeneration rule

Active files must be regenerated or edited through safe-lane controls. Frozen archive files must not be treated as current source of truth.

## Violation

Using frozen archive content as implementation source without documentation and validation is a handover violation.
