# Dependency Manifest

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and handover controls  
> **Production posture:** Production behavior remains blocked.


## Required for `make validate`

- Python 3.x.
- `jsonschema`.
- `referencing`.

## Validator dependencies

`validate_event_fixtures.py` imports and uses `jsonschema` and `referencing` directly.

## Validator classification

- OpenAPI validation: custom safe-lane structural checks, not standards-grade OpenAPI certification.
- Event fixture validation: JSON Schema validation using `jsonschema` and `referencing`, not production registry certification.
- Security/architecture validation: custom safe-lane guardrails.
- Workflow validation: local deterministic simulator harness.

## No-live-service requirement

Validation and simulators must not call live services.

## No-network requirement

Network-client and URL patterns are blocked in active source.

## TODO-BLOCKER

Before production contract certification, add standards-grade OpenAPI validation and a production event schema registry.

## `python3 -S` note

`validate_event_fixtures.py` restores the installed site-packages path explicitly so `jsonschema` and `referencing` remain available while avoiding user/site startup hooks.

## `python3 -S` dependency loading

`validate_event_fixtures.py` derives the virtualenv site-packages path from `sys.executable` so `jsonschema` and `referencing` are available while user/site startup hooks remain disabled.
