# State Coverage Report

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and controlled engineering-use governance  
> **Production posture:** Production behavior remains blocked.


## Negative event states covered

- APPROVAL_EXPIRED
- APPROVAL_REVOKED
- CROSS_TENANT_REPLAY_REJECTED
- CURRENCY_FX_CONFLICT
- CUSTOMER_CACHE_PRIVACY_BLOCKED
- EVENT_COMPENSATION_REQUIRED
- EVENT_PARTIALLY_APPLIED
- EVENT_REJECTED_INVALID_SIGNATURE
- EVENT_REPLAY_BLOCKED_EXPIRED_ENTITLEMENT
- FISCAL_PROFILE_MISSING
- IDEMPOTENCY_PAYLOAD_CONFLICT
- INVENTORY_RETRY_EXHAUSTED
- LEGAL_ENTITY_CONTEXT_CONFLICT
- OFFLINE_FISCAL_NOT_ALLOWED
- OFFLINE_REFUND_SERVER_VERIFICATION_REQUIRED
- PAYMENT_DUPLICATE_CALLBACK_IGNORED
- PAYMENT_MANUAL_RECONCILIATION_MISMATCH
- PAYMENT_REJECTED_GOODS_RELEASED
- PAYMENT_REJECTED_INVENTORY_POSTED
- PAYMENT_REJECTED_INVENTORY_REVIEW_REQUIRED
- RECEIPT_NUMBERING_SEQUENCE_MISSING
- REFUND_ORIGINAL_TENDER_LINK_REQUIRED
- REFUND_OVER_AMOUNT_REJECTED
- REFUND_SETTLEMENT_ACCOUNT_CONFLICT
- REPLAY_OUT_OF_ORDER_SEQUENCE
- REPORT_CROSS_TENANT_DENIED
- SETTLEMENT_ACCOUNT_LEGAL_ENTITY_CONFLICT

## Workflow states covered

- APPROVAL_EXPIRED
- APPROVAL_REVOKED
- CROSS_TENANT_REPLAY_REJECTED
- CURRENCY_FX_CONFLICT
- CUSTOMER_CACHE_PRIVACY_BLOCKED
- EVENT_COMPENSATION_REQUIRED
- EVENT_REJECTED_INVALID_SIGNATURE
- FISCAL_PROFILE_MISSING
- IDEMPOTENCY_PAYLOAD_CONFLICT
- INVENTORY_RETRY_EXHAUSTED
- OFFLINE_FISCAL_NOT_ALLOWED
- OFFLINE_REFUND_SERVER_VERIFICATION_REQUIRED
- PAYMENT_DUPLICATE_CALLBACK_IGNORED
- PAYMENT_INITIATED
- PAYMENT_MANUAL_RECONCILIATION_MISMATCH
- PAYMENT_PARTIALLY_CONFIRMED_TENDER_PRESERVED
- PAYMENT_PENDING_CONFIRMATION
- PAYMENT_REJECTED_GOODS_RELEASED
- PAYMENT_REJECTED_INVENTORY_REVIEW_REQUIRED
- PAYMENT_SPLIT_TENDER_PENDING_CONFIRMATION
- RECEIPT_FINALIZED
- RECEIPT_NUMBERING_SEQUENCE_MISSING
- REFUND_APPROVAL_REQUIRED
- REFUND_ORIGINAL_TENDER_LINK_REQUIRED
- REFUND_OVER_AMOUNT_REJECTED
- REFUND_SETTLEMENT_ACCOUNT_CONFLICT
- REPLAY_OUT_OF_ORDER_SEQUENCE
- REPORT_CROSS_TENANT_DENIED
- REPORT_PENDING_LOCAL_DATA

## States intentionally not covered

- live provider authorization/capture/void state
- settlement reconciliation state
- production fiscal/e-invoice delivery state
- offline finalized refund state
- production replay device-trust lifecycle
- customer cache persistence lifecycle
- intercompany inventory ownership transfer
- finance-authoritative report close state
- production monitoring/SOP closure state

## Production states blocked

- live payment provider behavior;
- settlement reconciliation;
- fiscal/e-invoice behavior;
- refund settlement;
- offline finalized refund;
- production replay;
- customer cache/privacy;
- intercompany inventory;
- finance-authoritative reporting;
- live external adapters;
- production monitoring/SOP closure.

## Next coverage priorities

1. More approval expiry/revocation combinations.
2. More split-tender pending/partial confirmation combinations.
3. More replay sequencing and payload-conflict combinations.
4. More report confidence-label scenarios.
5. More fiscal jurisdiction-policy block cases.

## Simulator gap register

See `SIMULATOR_GAP_REGISTER.md`.
