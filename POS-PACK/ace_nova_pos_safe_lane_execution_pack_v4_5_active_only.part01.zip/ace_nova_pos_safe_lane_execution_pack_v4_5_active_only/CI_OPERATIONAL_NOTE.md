# CI Operational Note

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and engineering execution controls  
> **Production posture:** Production behavior remains blocked.


## Required CI commands

```bash
python3 -m pip install jsonschema referencing
make validate
```

## Recommended separate evidence command

```bash
make prove-failures
```

Run `make prove-failures` on pull requests that modify validators, event schemas, OpenAPI contracts, workflow tests, scanner rules, or failure-proof examples.

## Expected pass/fail behavior

- `make validate` must pass for active safe-lane source.
- `make prove-failures` must pass by proving intentionally bad examples fail when copied into active paths.

## No-network expectation

CI must not call live services. Network-client usage in active source should fail guardrail validation.

## Dependency expectations

`jsonschema` and `referencing` are required for event fixture validation.

## Missing dependency handling

If `jsonschema` or `referencing` is missing, install them before validation:

```bash
python3 -m pip install jsonschema referencing
```

A missing dependency is a CI environment failure, not a reason to bypass validation.

## Frozen ZIP handling

Frozen ZIPs under `00_FROZEN_*/` are evidence only and excluded from release manifests. They must not be used as implementation source.

## Production lock reminder

CI success does not unlock live payment, settlement, fiscal/e-invoice, refund settlement, production replay, customer cache/privacy, intercompany inventory, finance-authoritative reporting, external adapters, or production monitoring/SOP closure.
