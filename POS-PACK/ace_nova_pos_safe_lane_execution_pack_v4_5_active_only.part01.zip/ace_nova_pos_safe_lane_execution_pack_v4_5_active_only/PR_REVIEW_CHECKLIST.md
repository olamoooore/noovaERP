# PR Review Checklist

> **Pack:** ACE Nova POS Safe-Lane Execution Pack v4.5  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness, validation harness, and controlled engineering-use governance  
> **Production posture:** Production behavior remains blocked.


## Required validation

- [ ] `make validate` passes.
- [ ] `make prove-failures` passes when validators, schemas, fixtures, OpenAPI, workflows, scanners, or failure-proof examples changed.
- [ ] Release manifest generated and active-file count reviewed.

## Scope controls

- [ ] No frozen ZIP implementation use.
- [ ] No live provider/client/network code.
- [ ] No production API endpoint naming.
- [ ] No direct inventory mutation.
- [ ] No customer cache persistence.
- [ ] No settlement logic.
- [ ] No fiscal/e-invoice logic.
- [ ] No production replay/device trust implementation.
- [ ] No weakening of TODO-BLOCKERs.
- [ ] No weakening of production locks.
- [ ] Evidence attached to PR.

## Safe-lane evidence

- [ ] New workflow tests include expected state, error, audit, outbox, reporting label, forbidden transition, recovery owner, and snapshots.
- [ ] New event fixtures include valid and invalid examples where applicable.
- [ ] New schema extensions follow `EVENT_EXTENSION_GOVERNANCE.md`.
- [ ] New simulator behavior remains local-only.

## Handover-control document checks

- [ ] `CONTROLLED_ENGINEER_HANDOVER_NOTE.md` remains accurate.
- [ ] `SAFE_LANE_SCOPE_CONTRACT.md` remains accurate.
- [ ] `FROZEN_ARCHIVE_ACCESS_POLICY.md` remains accurate.
- [ ] `STATE_COVERAGE_REPORT.md` updated if workflow states changed.
- [ ] `SAFE_LANE_RISK_REGISTER.md` updated if risks changed.

## v4.5 evidence

- [ ] PR uses `PR_EVIDENCE_TEMPLATE.md`.
- [ ] Exceptions follow `PRODUCTION_LOCK_EXCEPTION_PROCESS.md`.
