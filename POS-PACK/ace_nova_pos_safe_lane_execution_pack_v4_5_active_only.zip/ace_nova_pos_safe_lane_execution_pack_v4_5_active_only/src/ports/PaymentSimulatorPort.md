# PaymentSimulatorPort

> **Pack:** ACE Nova POS Safe-Lane Execution Pack  
> **Version:** v4.5 controlled engineering onboarding patch  
> **Prepared:** 2026-05-16  
> **Scope:** Local-only safe-lane simulator harness and validation harness  
> **Production posture:** Production behavior remains blocked.


## Purpose

Define the local-only safe-lane simulator interface for `PaymentSimulatorPort`.

## Methods

create_payment, timeout, blind_retry_charge, add_tender_success, payment_callback, payment_callback_duplicate, manual_evidence_mismatch, currency_fx_conflict

## Request shape

`enterprise_context`, `idempotency_key`, `payload_hash`, starting state, attempted action, and fixture references.

## Response shape

`success`, `current_state`, `error_code`, `audit_event_id`, `outbox_event_ids`, `reporting_label`, `recovery_owner`, `forbidden_transition`.

## Allowed simulator behavior

Stateful local validation, idempotency conflict simulation, deterministic negative-state output, audit/outbox recording, and reporting labels.

## Forbidden production behavior

No live payment provider behavior, settlement reconciliation, fiscal/e-invoice behavior, refund settlement, offline finalized refund, production replay, customer cache/privacy, intercompany inventory, finance-authoritative reporting, live external adapters, or production monitoring/SOP closure.

## TODO-BLOCKER decisions

All production decisions remain blocked pending formal decision evidence.
