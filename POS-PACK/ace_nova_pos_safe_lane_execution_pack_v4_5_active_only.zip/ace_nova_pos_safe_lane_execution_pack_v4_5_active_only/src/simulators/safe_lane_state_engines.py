from __future__ import annotations
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

ROOT = Path(__file__).resolve().parents[2]

def load_json(path: str) -> Dict[str, Any]:
    return json.loads((ROOT / path).read_text())

class IdempotencyLedger:
    def __init__(self):
        self._seen: Dict[str, Dict[str, Any]] = {}

    def check(self, key: str, payload_hash: str, current_result: Optional[Dict[str, Any]] = None) -> Optional[str]:
        if key in self._seen:
            if self._seen[key]["payload_hash"] != payload_hash:
                return "IDEMPOTENCY_PAYLOAD_CONFLICT"
            return "IDEMPOTENCY_REPLAY_SAME_PAYLOAD"
        self._seen[key] = {"payload_hash": payload_hash, "result": current_result or {}}
        return None

    def as_dict(self) -> Dict[str, str]:
        return {key: value["payload_hash"] for key, value in sorted(self._seen.items())}

class AuditOutboxRecorder:
    def __init__(self):
        self.audit_events: List[str] = []
        self.outbox_events: List[str] = []
        self.reporting_labels: List[str] = []
        self.blocked_transitions: List[str] = []

    def record(self, code: str, reporting_label: str, forbidden_transition: Optional[str] = None):
        self.audit_events.append(f"{code}_AUDIT")
        self.outbox_events.append(code)
        self.reporting_labels.append(reporting_label)
        if forbidden_transition:
            self.blocked_transitions.append(forbidden_transition)

@dataclass
class SimulatorContext:
    workflow_id: str
    state: str
    ledger: IdempotencyLedger = field(default_factory=IdempotencyLedger)
    recorder: AuditOutboxRecorder = field(default_factory=AuditOutboxRecorder)
    tenders: List[str] = field(default_factory=list)
    callbacks: set = field(default_factory=set)
    inventory_retries: int = 0
    last_sequence: int = 1
    snapshots: List[Dict[str, Any]] = field(default_factory=list)

    def snapshot(self, recovery_owner: Optional[str] = None):
        self.snapshots.append({
            "workflow_id": self.workflow_id,
            "current_state": self.state,
            "idempotency_ledger_state": self.ledger.as_dict(),
            "audit_events": list(self.recorder.audit_events),
            "outbox_events": list(self.recorder.outbox_events),
            "reporting_labels": list(self.recorder.reporting_labels),
            "blocked_transitions": list(self.recorder.blocked_transitions),
            "recovery_owner": recovery_owner,
        })

class BaseEngine:
    def apply_idempotency(self, ctx: SimulatorContext, step: Dict[str, Any], current_result: Optional[Dict[str, Any]] = None):
        return ctx.ledger.check(step.get("idempotency_key", "missing"), step.get("payload_hash", "missing"), current_result)

class CartStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "backend_owner"
        ctx.state = "CART_ACTIVE"
        return None, ctx.state, "backend_owner"

class PaymentStateEngine(BaseEngine):
    def apply(self, ctx, step):
        action = step["action"]
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            owner = "finance_owner" if action == "payment_callback_duplicate_different_payload" else "backend_owner"
            return idem, idem, owner
        if action == "create_payment":
            ctx.state = "PAYMENT_INITIATED"
            return None, ctx.state, "finance_owner"
        if action == "timeout":
            ctx.state = "PAYMENT_PENDING_CONFIRMATION"
            return "PAYMENT_PENDING_CONFIRMATION", ctx.state, "finance_owner"
        if action == "status_check" and ctx.state == "PAYMENT_PENDING_CONFIRMATION":
            return "PAYMENT_PENDING_CONFIRMATION", "PAYMENT_PENDING_CONFIRMATION", "finance_owner"
        if action == "blind_retry_charge" and ctx.state == "PAYMENT_PENDING_CONFIRMATION":
            return "PAYMENT_PENDING_CONFIRMATION", ctx.state, "finance_owner"
        if action == "add_tender_success":
            ctx.tenders.append(step.get("tender_id", "tender"))
            ctx.state = "PAYMENT_PARTIALLY_CONFIRMED_TENDER_PRESERVED"
            return None, ctx.state, "finance_owner"
        if action == "simulate_next_tender_failure":
            return "PAYMENT_NEXT_TENDER_FAILED", "PAYMENT_PARTIALLY_CONFIRMED_TENDER_PRESERVED", "finance_owner"
        if action == "payment_callback":
            ctx.callbacks.add(step.get("idempotency_key"))
            ctx.state = "PAYMENT_CONFIRMED"
            return None, ctx.state, "finance_owner"
        if action == "payment_callback_duplicate" and step.get("idempotency_key") in ctx.callbacks:
            return "PAYMENT_DUPLICATE_CALLBACK_IGNORED", "PAYMENT_DUPLICATE_CALLBACK_IGNORED", "finance_owner"
        if action == "payment_callback_duplicate_different_payload":
            return "IDEMPOTENCY_PAYLOAD_CONFLICT", "IDEMPOTENCY_PAYLOAD_CONFLICT", "finance_owner"
        if action == "add_tender_pending_confirmation":
            ctx.state = "PAYMENT_SPLIT_TENDER_PENDING_CONFIRMATION"
            return "PAYMENT_PENDING_CONFIRMATION", ctx.state, "finance_owner"
        if action == "manual_evidence_mismatch":
            return "PAYMENT_MANUAL_RECONCILIATION_MISMATCH", "PAYMENT_MANUAL_RECONCILIATION_MISMATCH", "finance_owner"
        if action == "goods_released":
            ctx.state = "GOODS_RELEASED"
            return None, ctx.state, "finance_owner"
        if action == "finance_reject" and ctx.state == "GOODS_RELEASED":
            return "PAYMENT_REJECTED_GOODS_RELEASED", "PAYMENT_REJECTED_GOODS_RELEASED", "finance_owner"
        if action == "currency_fx_conflict":
            return "CURRENCY_FX_CONFLICT", "CURRENCY_FX_CONFLICT", "finance_owner"
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

class ReceiptStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "backend_owner"
        action = step["action"]
        if action == "finalize_receipt":
            ctx.state = "RECEIPT_FINALIZED"
            return None, ctx.state, "backend_owner"
        if action == "mutate_receipt_line" and ctx.state == "RECEIPT_FINALIZED":
            return "RECEIPT_MUTATION_REJECTED", "RECEIPT_FINALIZED", "backend_owner"
        if action == "fiscal_profile_missing":
            return "FISCAL_PROFILE_MISSING", "FISCAL_PROFILE_MISSING", "tax_fiscal_owner"
        if action == "receipt_numbering_missing":
            return "RECEIPT_NUMBERING_SEQUENCE_MISSING", "RECEIPT_NUMBERING_SEQUENCE_MISSING", "backend_owner"
        if action == "receipt_finalized_pending_inventory":
            ctx.state = "RECEIPT_FINALIZED_PENDING_INVENTORY"
            return None, ctx.state, "backend_owner"
        if action == "inventory_rejected_after_receipt_finalized" and ctx.state == "RECEIPT_FINALIZED_PENDING_INVENTORY":
            return "PAYMENT_REJECTED_INVENTORY_REVIEW_REQUIRED", "PAYMENT_REJECTED_INVENTORY_REVIEW_REQUIRED", "inventory_owner"
        if action == "fiscal_policy_block":
            return "OFFLINE_FISCAL_NOT_ALLOWED", "OFFLINE_FISCAL_NOT_ALLOWED", "tax_fiscal_owner"
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

class RefundStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "finance_owner"
        mapping = {
            "refund_over_amount": ("REFUND_OVER_AMOUNT_REJECTED", "finance_owner"),
            "refund_missing_original_tender": ("REFUND_ORIGINAL_TENDER_LINK_REQUIRED", "finance_owner"),
            "refund_settlement_account_conflict": ("REFUND_SETTLEMENT_ACCOUNT_CONFLICT", "finance_owner"),
            "offline_refund_server_verification_failed": ("OFFLINE_REFUND_SERVER_VERIFICATION_REQUIRED", "finance_owner"),
            "finalize_without_approval": ("APPROVAL_REQUIRED", "finance_owner"),
            "approval_expired_before_finalization": ("APPROVAL_EXPIRED", "approval_owner"),
        }
        action = step["action"]
        if action in mapping:
            code, owner = mapping[action]
            state = "REFUND_APPROVAL_REQUIRED" if code == "APPROVAL_REQUIRED" else code
            return code, state, owner
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

class InventoryPostingStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "backend_owner"
        action = step["action"]
        if action == "inventory_retry":
            ctx.inventory_retries += 1
            if ctx.inventory_retries >= 3:
                return "INVENTORY_RETRY_EXHAUSTED", "INVENTORY_RETRY_EXHAUSTED", "inventory_owner"
            ctx.state = "INVENTORY_POSTING_FAILED_RETRYABLE"
            return None, ctx.state, "inventory_owner"
        if action == "inventory_posted":
            ctx.state = "INVENTORY_POSTED"
            return None, ctx.state, "inventory_owner"
        if action == "payment_rejected_after_inventory" and ctx.state == "INVENTORY_POSTED":
            return "PAYMENT_REJECTED_INVENTORY_REVIEW_REQUIRED", "PAYMENT_REJECTED_INVENTORY_REVIEW_REQUIRED", "inventory_owner"
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

class ReplayStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "security_owner"
        action = step["action"]
        if action == "replay_sequence":
            if int(step.get("local_sequence", 0)) != ctx.last_sequence:
                return "REPLAY_OUT_OF_ORDER_SEQUENCE", "REPLAY_OUT_OF_ORDER_SEQUENCE", "security_owner"
            ctx.last_sequence += 1
            return None, "EVENT_READY_FOR_SYNC", "security_owner"
        if action == "event_partially_applied":
            ctx.state = "EVENT_PARTIALLY_APPLIED"
            return "EVENT_PARTIALLY_APPLIED", ctx.state, "backend_owner"
        if action == "request_compensation":
            return "EVENT_COMPENSATION_REQUIRED", "EVENT_COMPENSATION_REQUIRED", "backend_owner"
        if action == "invalid_signature":
            return "EVENT_REJECTED_INVALID_SIGNATURE", "EVENT_REJECTED_INVALID_SIGNATURE", "security_owner"
        if action == "expired_entitlement":
            return "EVENT_REPLAY_BLOCKED_EXPIRED_ENTITLEMENT", "EVENT_REPLAY_BLOCKED_EXPIRED_ENTITLEMENT", "security_owner"
        if action == "cross_tenant_replay":
            return "CROSS_TENANT_REPLAY_REJECTED", "CROSS_TENANT_REPLAY_REJECTED", "security_owner"
        if action == "replay_submit":
            ctx.state = "EVENT_READY_FOR_SYNC"
            return None, ctx.state, "security_owner"
        if action == "replay_duplicate_sequence_different_payload":
            return "IDEMPOTENCY_PAYLOAD_CONFLICT", "IDEMPOTENCY_PAYLOAD_CONFLICT", "security_owner"
        if action == "retry_after_partially_applied" and ctx.state == "EVENT_PARTIALLY_APPLIED":
            return "EVENT_COMPENSATION_REQUIRED", "EVENT_COMPENSATION_REQUIRED", "backend_owner"
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

class ApprovalStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "backend_owner"
        action = step["action"]
        if action == "approval_expired":
            ctx.state = "APPROVAL_EXPIRED"
            return "APPROVAL_EXPIRED", ctx.state, "approval_owner"
        if action == "approval_action_after_expired" and ctx.state == "APPROVAL_EXPIRED":
            return "APPROVAL_EXPIRED", "APPROVAL_EXPIRED", "approval_owner"
        if action == "approval_revoked":
            ctx.state = "APPROVAL_REVOKED"
            return "APPROVAL_REVOKED", ctx.state, "approval_owner"
        if action == "approval_revoked_before_execution":
            ctx.state = "APPROVAL_REVOKED"
            return "APPROVAL_REVOKED", ctx.state, "approval_owner"
        if action == "approval_action_after_revoked" and ctx.state == "APPROVAL_REVOKED":
            return "APPROVAL_REVOKED", "APPROVAL_REVOKED", "approval_owner"
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

class ReportingConfidenceStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "backend_owner"
        if step["action"] == "cross_tenant_report":
            return "REPORT_CROSS_TENANT_DENIED", "REPORT_CROSS_TENANT_DENIED", "reporting_owner"
        if step["action"] == "report_pending_local_data":
            return "REPORT_PENDING_LOCAL_DATA", "REPORT_PENDING_LOCAL_DATA", "reporting_owner"
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

class CustomerPrivacyStateEngine(BaseEngine):
    def apply(self, ctx, step):
        idem = self.apply_idempotency(ctx, step)
        if idem == "IDEMPOTENCY_PAYLOAD_CONFLICT":
            return idem, idem, "privacy_owner"
        if step["action"] == "customer_cache_privacy_block":
            return "CUSTOMER_CACHE_PRIVACY_BLOCKED", "CUSTOMER_CACHE_PRIVACY_BLOCKED", "privacy_owner"
        if step["action"] == "customer_cache_access_denied_by_role":
            return "CUSTOMER_CACHE_PRIVACY_BLOCKED", "CUSTOMER_CACHE_PRIVACY_BLOCKED", "privacy_owner"
        return "UNSUPPORTED_SAFE_LANE_ACTION", "SAFE_LANE_REJECTED", "backend_owner"

ENGINES = {
    "payment": PaymentStateEngine(),
    "receipt": ReceiptStateEngine(),
    "refund": RefundStateEngine(),
    "inventory": InventoryPostingStateEngine(),
    "replay": ReplayStateEngine(),
    "approval": ApprovalStateEngine(),
    "reporting": ReportingConfidenceStateEngine(),
    "customer": CustomerPrivacyStateEngine(),
    "cart": CartStateEngine(),
}

def emit(code, state, owner, forbidden, ctx: Optional[SimulatorContext] = None):
    snapshots = ctx.snapshots if ctx else []
    return {
        "success": False,
        "current_state": state,
        "error_code": code,
        "audit_event_id": f"{code}_AUDIT",
        "outbox_event_ids": [code],
        "reporting_label": state,
        "recovery_owner": owner,
        "forbidden_transition": forbidden,
        "state_snapshots": snapshots,
    }

def handle_event_fixture(fixture_path: str):
    event = load_json(fixture_path)
    event_type = event.get("event_type", "EVENT_REJECTED_INVALID_ENVELOPE")
    payload = event.get("payload", {})
    if payload.get("error_code") != event_type:
        return emit("EVENT_REJECTED_INVALID_ENVELOPE", "EVENT_REJECTED_INVALID_ENVELOPE", "backend_owner", "invalid_event -> accepted")
    return emit(event_type, event_type, payload.get("recovery_owner", "domain_owner"), f"{event_type} -> SUCCESS")

def handle_workflow_case(case_path: str):
    case = load_json(case_path)
    ctx = SimulatorContext(workflow_id=case["test_id"], state=case["starting_state"])
    engine = ENGINES[case["domain"]]
    final_code = None
    final_state = ctx.state
    final_owner = case["recovery_owner"]
    for step in case["step_sequence"]:
        code, state, owner = engine.apply(ctx, step)
        final_owner = owner
        if code:
            final_code = code
            final_state = state
            ctx.state = state
            ctx.recorder.record(code, state, case["forbidden_transition"])
        else:
            ctx.state = state
            final_state = state
        ctx.snapshot(recovery_owner=final_owner)
    return emit(final_code or final_state, final_state, final_owner, case["forbidden_transition"], ctx)

def handle_fixture(fixture_path: str):
    fixture = load_json(fixture_path)
    expected = fixture.get("expected_response", {})
    code = expected.get("error_code") or expected.get("current_state", "SAFE_LANE_OK")
    return {
        "success": bool(expected.get("success", False)),
        "current_state": expected.get("current_state", code),
        "error_code": expected.get("error_code"),
        "audit_event_id": expected.get("audit_event_id", f"{code}_AUDIT"),
        "outbox_event_ids": expected.get("outbox_event_ids", [code]),
        "reporting_label": expected.get("current_state", code),
        "recovery_owner": "domain_owner",
        "state_snapshots": [],
    }
