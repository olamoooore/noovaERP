from .safe_lane_handlers import handle_fixture, handle_workflow_case

# Local-only safe-lane simulator. No external calls.
def handle_fixture_request(fixture_path: str):
    return handle_fixture(fixture_path)

def handle_workflow(case_path: str):
    return handle_workflow_case(case_path)
