#!/usr/bin/env python3
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = [
    ["python3", "-S", "scripts/validate_openapi.py"],
    ["python3", "-S", "scripts/validate_event_schemas.py"],
    ["python3", "-S", "scripts/validate_event_fixtures.py"],
    ["python3", "-S", "scripts/check_forbidden_production_terms.py"],
    ["python3", "-S", "scripts/check_fixture_coverage.py"],
    ["python3", "-S", "scripts/check_architecture_rules.py"],
    ["python3", "-S", "scripts/run_negative_tests.py"],
    ["python3", "-S", "scripts/run_workflow_tests.py"],
    ["python3", "-S", "scripts/generate_release_manifest.py"],
]

def main():
    for command in COMMANDS:
        proc = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
        if proc.stdout:
            print(proc.stdout, end="")
        if proc.returncode != 0:
            if proc.stderr:
                print(proc.stderr, file=sys.stderr, end="")
            return proc.returncode
    print("All safe-lane validations passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
