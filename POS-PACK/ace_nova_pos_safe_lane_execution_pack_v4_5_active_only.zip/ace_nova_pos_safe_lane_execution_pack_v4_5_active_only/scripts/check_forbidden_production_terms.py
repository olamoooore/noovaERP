#!/usr/bin/env python3
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS = []

ALLOW_PREFIXES = [
    "docs/",
    "README.md",
    "REPOSITORY_LAYOUT.md",
    "SECURITY/SECURITY_SCAN_EVIDENCE.md",
    "scripts/check_forbidden_production_terms.py",
    "scripts/check_architecture_rules.py",
    "scripts/prove_validation_failures.py",
    "scripts/validate_openapi.py",
    "scripts/validate_event_schemas.py",
    "scripts/validate_event_fixtures.py",
    "scripts/check_fixture_coverage.py",
    "scripts/run_negative_tests.py",
    "scripts/run_workflow_tests.py",
    "scripts/generate_release_manifest.py",
    "scripts/run_all_validations.py",
]
TEXT_EXTENSIONS = {".py", ".js", ".ts", ".json", ".md", ".sql", ".yaml", ".yml", ".txt"}
PATTERNS = {
    "private_key": r"-----BEGIN [A-Z ]*PRIVATE KEY-----",
    "oauth_secret": r"(?i)(oauth|client).*secret",
    "github_token": r"gh[pousr]_[A-Za-z0-9_]{20,}",
    "slack_token": r"xox[baprs]-[A-Za-z0-9-]{10,}",
    "cloud_token": r"(?i)(aws_secret_access_key|azure_client_secret|google_application_credentials)",
    "non_placeholder_url": r"https?://(?!example\.invalid)(?!json-schema\.org)[^\s\"')]+",
    "network_library": r"\b(import\s+requests|import\s+httpx|axios\.|fetch\(|socket\.|urllib)\b",
    "subprocess_network": r"\b(curl|wget|ncat|telnet)\b",
    "hidden_env": r"(^|/)\.env(\.|$)",
    "live_provider": r"\b(stripe|adyen|worldpay|paypal|braintree|razorpay|ipay88|senangpay)\b",
    "settlement_fiscal": r"\b(settlement_client|settlement_api|settle_funds|fiscal_client|einvoice_client|myinvois|lhdn)\b",
    "inventory_mutation": r"\b(update_stock_quantity|decrement_inventory|direct_stock_mutation)\b",
    "customer_cache_impl": r"\b(customer_cache_store|persist_customer_profile)\b",
    "live_adapter": r"\b(live_adapter|external_adapter_impl|ProductionAdapter)\b",
}

def allowed(rel):
    return rel in ["RELEASE_MANIFEST.txt", "RELEASE_MANIFEST_SHA256.txt"] or any(rel.startswith(prefix) or rel == prefix for prefix in ALLOW_PREFIXES)

def main():
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT).as_posix()
        if "__pycache__" in rel or rel.endswith(".pyc"):
            ERRORS.append(f"{rel}: cache artifact forbidden")
        if not path.is_file():
            continue
        if path.name == "Makefile":
            text = path.read_text(errors="ignore")
        elif path.suffix.lower() not in TEXT_EXTENSIONS:
            if not rel.startswith("00_FROZEN_"):
                ERRORS.append(f"{rel}: active binary/generated artifact forbidden")
            continue
        else:
            text = path.read_text(errors="ignore")
        if allowed(rel):
            continue
        for name, pattern in PATTERNS.items():
            if re.search(pattern, text, re.I):
                ERRORS.append(f"{rel}: forbidden/security pattern {name}")
    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print("Forbidden production/security scan passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
