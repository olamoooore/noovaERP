#!/usr/bin/env python3
import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXAMPLES = ROOT / "docs/examples/failure_proof"

CASES = [
    {
        "name": "invalid_event_fixture",
        "source": EXAMPLES / "invalid_event_fixture.json",
        "target": ROOT / "contracts/fixtures/events/valid/_proof_invalid_event_fixture.json",
        "command": ["make", "validate-event-fixtures"],
    },
    {
        "name": "duplicate_operation_id",
        "source": EXAMPLES / "duplicate_operation_id.openapi.json",
        "target": ROOT / "contracts/openapi/_proof_duplicate_operation_id.openapi.json",
        "command": ["make", "validate-openapi"],
    },
    {
        "name": "missing_openapi_fixture",
        "source": EXAMPLES / "missing_fixture.openapi.json",
        "target": ROOT / "contracts/openapi/_proof_missing_fixture.openapi.json",
        "command": ["make", "validate-openapi"],
    },
    {
        "name": "non_placeholder_url_active_file",
        "source": EXAMPLES / "non_placeholder_url_active.md",
        "target": ROOT / "src/simulators/_proof_non_placeholder_url.md",
        "command": ["make", "check-forbidden-production"],
    },
    {
        "name": "cache_artifact",
        "source": EXAMPLES / "invalid_event_fixture.json",
        "target": ROOT / "src/simulators/__pycache__/_proof_cache.pyc",
        "command": ["make", "check-forbidden-production"],
    },
    {
        "name": "forbidden_live_provider_term",
        "source": EXAMPLES / "live_provider_term.md",
        "target": ROOT / "src/simulators/_proof_live_provider.md",
        "command": ["make", "check-forbidden-production"],
    },
    {
        "name": "event_fixture_extra_field",
        "source": EXAMPLES / "event_fixture_extra_field.json",
        "target": ROOT / "contracts/fixtures/events/valid/_proof_event_extra_field.json",
        "command": ["make", "validate-event-fixtures"],
    },
    {
        "name": "event_fixture_missing_required_payload_field",
        "source": EXAMPLES / "event_fixture_missing_required.json",
        "target": ROOT / "contracts/fixtures/events/valid/_proof_event_missing_required.json",
        "command": ["make", "validate-event-fixtures"],
    },
    {
        "name": "workflow_expected_state_mismatch",
        "source": EXAMPLES / "workflow_expected_state_mismatch.json",
        "target": ROOT / "tests/workflows/cases/_proof_workflow_expected_state_mismatch.json",
        "command": ["make", "run-workflow-tests"],
    },

    {
        "name": "event_fixture_invalid_extension_pii",
        "source": EXAMPLES / "event_fixture_invalid_extension_pii.json",
        "target": ROOT / "contracts/fixtures/events/valid/_proof_event_invalid_extension_pii.json",
        "command": ["make", "validate-event-fixtures"],
    },
    {
        "name": "event_fixture_invalid_extension_payment_sensitive",
        "source": EXAMPLES / "event_fixture_invalid_extension_payment_sensitive.json",
        "target": ROOT / "contracts/fixtures/events/valid/_proof_event_invalid_extension_payment_sensitive.json",
        "command": ["make", "validate-event-fixtures"],
    },
]

def cleanup(target: Path):
    if target.exists():
        target.unlink()
    for pycache in ROOT.rglob("__pycache__"):
        shutil.rmtree(pycache, ignore_errors=True)
    for pyc in ROOT.rglob("*.pyc"):
        pyc.unlink()

def run_case(case):
    target = case["target"]
    target.parent.mkdir(parents=True, exist_ok=True)
    try:
        shutil.copy2(case["source"], target)
        proc = subprocess.run(case["command"], cwd=ROOT, text=True, capture_output=True, timeout=120)
        if proc.returncode == 0:
            print(f"FAIL: bad example unexpectedly passed: {case['name']}")
            if proc.stdout:
                print(proc.stdout)
            return False
        print(f"PASS: bad example failed validation as expected: {case['name']}")
        return True
    finally:
        cleanup(target)

def main():
    ok = True
    for case in CASES:
        if not run_case(case):
            ok = False
    if not ok:
        return 1
    print("All intentional failure proofs failed validation as expected.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
