#!/usr/bin/env python3
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.simulators.safe_lane_handlers import handle_workflow_case

ERRORS = []

SNAPSHOT_REQUIRED_FIELDS = [
    "workflow_id",
    "current_state",
    "idempotency_ledger_state",
    "audit_events",
    "outbox_events",
    "reporting_labels",
    "blocked_transitions",
    "recovery_owner",
]

def main():
    for case_path in sorted((ROOT / "tests/workflows/cases").glob("*.json")):
        case = json.loads(case_path.read_text())
        result = handle_workflow_case(str(case_path.relative_to(ROOT)))
        checks = {
            "expected_state": result["current_state"],
            "expected_error_code": result["error_code"],
            "expected_audit_event": result["audit_event_id"],
            "expected_outbox_event": result["outbox_event_ids"][0],
            "expected_reporting_label": result["reporting_label"],
            "recovery_owner": result["recovery_owner"],
            "forbidden_transition": result["forbidden_transition"],
        }
        for key, actual in checks.items():
            if case[key] != actual:
                ERRORS.append(f"{case_path}: {key} expected {case[key]} got {actual}")

        snapshots = result.get("state_snapshots", [])
        if len(snapshots) != len(case.get("step_sequence", [])):
            ERRORS.append(f"{case_path}: expected {len(case.get('step_sequence', []))} snapshots got {len(snapshots)}")
        for index, snapshot in enumerate(snapshots):
            for field in SNAPSHOT_REQUIRED_FIELDS:
                if field not in snapshot:
                    ERRORS.append(f"{case_path}: snapshot {index} missing {field}")
            if snapshot.get("workflow_id") != case["test_id"]:
                ERRORS.append(f"{case_path}: snapshot {index} workflow_id mismatch")
            if not isinstance(snapshot.get("idempotency_ledger_state", {}), dict):
                ERRORS.append(f"{case_path}: snapshot {index} idempotency_ledger_state must be object")
            for list_field in ["audit_events", "outbox_events", "reporting_labels", "blocked_transitions"]:
                if not isinstance(snapshot.get(list_field, []), list):
                    ERRORS.append(f"{case_path}: snapshot {index} {list_field} must be array")

    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print("Workflow negative tests passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
