#!/usr/bin/env python3
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.simulators.safe_lane_handlers import handle_event_fixture

ERRORS = []

def main():
    for case_path in sorted((ROOT / "tests/negative/cases").glob("*.json")):
        case = json.loads(case_path.read_text())
        result = handle_event_fixture(case["input_fixture"])
        checks = {
            "expected_state": result["current_state"],
            "expected_error_code": result["error_code"],
            "expected_audit_event": result["audit_event_id"],
            "expected_outbox_event": result["outbox_event_ids"][0],
            "expected_reporting_label": result["reporting_label"],
            "recovery_owner": result["recovery_owner"],
            "forbidden_transition": result["forbidden_transition"],
        }
        for key, actual in checks.items():
            if case[key] != actual:
                ERRORS.append(f"{case_path}: {key} expected {case[key]} got {actual}")
    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print("Negative event tests passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
