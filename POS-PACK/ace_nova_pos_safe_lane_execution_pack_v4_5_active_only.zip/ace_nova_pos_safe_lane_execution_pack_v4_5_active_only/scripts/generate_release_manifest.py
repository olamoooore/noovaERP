#!/usr/bin/env python3
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXCLUDE_NAMES = {"RELEASE_MANIFEST.txt", "RELEASE_MANIFEST_SHA256.txt"}

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def excluded(rel):
    return (
        rel in EXCLUDE_NAMES
        or "__pycache__" in rel
        or rel.endswith(".pyc")
        or rel.startswith("00_FROZEN_")
    )

def main():
    rows = []
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT).as_posix()
        if excluded(rel):
            continue
        rows.append(f"{sha256_file(path)}  {rel}")
    manifest = "\n".join(rows) + "\n"
    (ROOT / "RELEASE_MANIFEST.txt").write_text(manifest)
    (ROOT / "RELEASE_MANIFEST_SHA256.txt").write_text(hashlib.sha256(manifest.encode()).hexdigest() + "  RELEASE_MANIFEST.txt\n")
    print(f"Release manifest generated for {len(rows)} active files")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
