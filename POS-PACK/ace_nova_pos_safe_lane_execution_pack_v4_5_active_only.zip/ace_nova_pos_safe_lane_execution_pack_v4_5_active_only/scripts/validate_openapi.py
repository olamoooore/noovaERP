#!/usr/bin/env python3
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS = []

def err(message):
    ERRORS.append(message)

def load_json(path):
    return json.loads(Path(path).read_text())

def resolve_ref(doc, ref):
    if not ref.startswith("#/"):
        err(f"external OpenAPI ref not allowed: {ref}")
        return {}
    cur = doc
    for part in ref[2:].split("/"):
        if not isinstance(cur, dict) or part not in cur:
            err(f"unresolved local ref: {ref}")
            return {}
        cur = cur[part]
    return cur

def validate_schema(schema, obj, doc, path="$"):
    if not isinstance(schema, dict):
        return []
    if "$ref" in schema:
        schema = resolve_ref(doc, schema["$ref"])
    errs = []
    if "const" in schema and obj != schema["const"]:
        errs.append(f"{path}: expected const {schema['const']}")
    if "enum" in schema and obj not in schema["enum"]:
        errs.append(f"{path}: expected enum {schema['enum']}")
    typ = schema.get("type")
    if typ == "object":
        if not isinstance(obj, dict):
            return [f"{path}: expected object"]
        for required in schema.get("required", []):
            if required not in obj:
                errs.append(f"{path}: missing {required}")
        for key, value in obj.items():
            if key in schema.get("properties", {}):
                errs.extend(validate_schema(schema["properties"][key], value, doc, path + "." + key))
            elif schema.get("additionalProperties") is False:
                errs.append(f"{path}: extra property {key}")
    elif typ == "array" and not isinstance(obj, list):
        errs.append(f"{path}: expected array")
    elif typ == "string" and not isinstance(obj, str):
        errs.append(f"{path}: expected string")
    elif typ == "boolean" and not isinstance(obj, bool):
        errs.append(f"{path}: expected boolean")
    return errs

def main():
    operation_ids = {}
    for spec_path in sorted((ROOT / "contracts/openapi").glob("*.json")):
        doc = load_json(spec_path)
        if doc.get("openapi") != "3.1.0":
            err(f"{spec_path}: OpenAPI must be 3.1.0")
        if not doc.get("servers"):
            err(f"{spec_path}: missing servers")
        for server in doc.get("servers", []):
            if server.get("url") != "https://example.invalid":
                err(f"{spec_path}: server must be https://example.invalid")
        for path, methods in doc.get("paths", {}).items():
            if not any(token in path.lower() for token in ["simulator", "stub", "mock", "safe-lane", "safe_lane"]):
                err(f"{spec_path}: unscoped simulator path {path}")
            for method, op in methods.items():
                oid = op.get("operationId")
                if not oid:
                    err(f"{spec_path}:{path}:{method}: missing operationId")
                elif oid in operation_ids:
                    err(f"duplicate operationId {oid} in {spec_path} and {operation_ids[oid]}")
                else:
                    operation_ids[oid] = str(spec_path)
                for ext in ["x-authorization", "x-idempotency", "x-state-transition-notes", "x-audit-events", "x-outbox-events", "x-error-code-examples", "x-contract-test-fixtures"]:
                    if ext not in op:
                        err(f"{spec_path}:{path}:{method}: missing {ext}")
                for fixture in op.get("x-contract-test-fixtures", []):
                    if not (ROOT / fixture).exists():
                        err(f"{spec_path}:{path}:{method}: missing fixture {fixture}")
                rb = op.get("requestBody", {}).get("content", {}).get("application/json", {})
                if not rb.get("examples"):
                    err(f"{spec_path}:{path}:{method}: missing request examples")
                for name, example in rb.get("examples", {}).items():
                    if "value" in example and rb.get("schema"):
                        for schema_error in validate_schema(rb["schema"], example["value"], doc, "$request"):
                            err(f"{spec_path}:{path}:{method}:request:{name}: {schema_error}")
                for code in ["200", "202", "400", "401", "403", "404", "409", "422", "500"]:
                    if code not in op.get("responses", {}):
                        err(f"{spec_path}:{path}:{method}: missing response {code}")
                        continue
                    app = op["responses"][code].get("content", {}).get("application/json", {})
                    if not app.get("examples"):
                        err(f"{spec_path}:{path}:{method}:{code}: missing examples")
                    for name, example in app.get("examples", {}).items():
                        if "value" in example and app.get("schema"):
                            for schema_error in validate_schema(app["schema"], example["value"], doc, "$response"):
                                err(f"{spec_path}:{path}:{method}:{code}:{name}: {schema_error}")
    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print("OpenAPI validation passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
