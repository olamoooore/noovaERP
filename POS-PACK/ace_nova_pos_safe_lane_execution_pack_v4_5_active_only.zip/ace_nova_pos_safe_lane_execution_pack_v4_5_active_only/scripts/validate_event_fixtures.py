
#!/usr/bin/env python3
import json
import sys
import sysconfig
from pathlib import Path

def add_site_packages_for_python_dash_s():
    candidates = []
    for key in ["purelib", "platlib"]:
        value = sysconfig.get_paths().get(key)
        if value:
            candidates.append(Path(value))
    exe = Path(sys.executable).resolve()
    # Handles /opt/pyvenv/bin/python3 -> /opt/pyvenv/lib/pythonX.Y/site-packages
    if exe.parent.name == "bin":
        venv = exe.parent.parent
        lib = venv / "lib"
        if lib.exists():
            for child in lib.glob("python*"):
                candidates.append(child / "site-packages")
                candidates.append(child / "dist-packages")
    for candidate in candidates:
        if candidate.exists():
            value = str(candidate)
            if value not in sys.path:
                sys.path.append(value)

add_site_packages_for_python_dash_s()

try:
    import jsonschema
    from referencing import Registry, Resource
except Exception as exc:
    print(f"jsonschema and referencing are required: {exc}")
    sys.exit(1)

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "contracts/events"
ERRORS = []
FIXTURE_METADATA = {"schema_file", "expected_validation_result"}
UNSAFE_EXTENSION_KEY_PATTERNS = [
    "customer.email",
    "customer.phone",
    "customer.name",
    "payment.card",
    "payment.card_pan",
    "payment.auth_code",
    "payment.token",
]


def err(message):
    ERRORS.append(message)

def load_json(path):
    return json.loads(Path(path).read_text())

def event_only(fixture):
    return {key: value for key, value in fixture.items() if key not in FIXTURE_METADATA}

def build_registry():
    resources = []
    for schema_path in BASE.glob("*.schema.json"):
        schema = load_json(schema_path)
        resources.append((schema.get("$id", schema_path.name), Resource.from_contents(schema)))
    return Registry().with_resources(resources)

def validate_fixture(path, should_pass, registry):
    fixture = load_json(path)
    schema_file = fixture.get("schema_file")
    if not schema_file:
        err(f"{path}: missing schema_file")
        return
    schema_path = ROOT / schema_file
    if not schema_path.exists():
        err(f"{path}: schema_file does not exist: {schema_file}")
        return
    schema = load_json(schema_path)
    try:
        event = event_only(fixture)
        jsonschema.Draft202012Validator(schema, registry=registry).validate(event)
        extensions = event.get("payload", {}).get("extensions", {})
        unsafe_extension = False
        if isinstance(extensions, dict):
            for key in extensions:
                if "." not in key:
                    unsafe_extension = True
                if any(pattern in key for pattern in UNSAFE_EXTENSION_KEY_PATTERNS):
                    unsafe_extension = True
        passed = not unsafe_extension
    except Exception:
        passed = False
    if passed != should_pass:
        err(f"{path}: expected {'valid' if should_pass else 'invalid'} but got {'valid' if passed else 'invalid'}")

def main():
    registry = build_registry()
    for fixture_path in sorted((ROOT / "contracts/fixtures/events/valid").glob("*.json")):
        validate_fixture(fixture_path, True, registry)
    for fixture_path in sorted((ROOT / "contracts/fixtures/events/invalid").glob("*.json")):
        validate_fixture(fixture_path, False, registry)
    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print("Event fixture validation passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
