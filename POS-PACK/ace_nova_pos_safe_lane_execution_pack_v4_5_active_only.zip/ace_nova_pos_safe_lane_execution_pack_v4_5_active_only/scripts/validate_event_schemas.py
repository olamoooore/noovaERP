#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "contracts/events"
ERRORS = []

def err(message):
    ERRORS.append(message)

def main():
    manifest_path = BASE / "resolver-manifest.json"
    if not manifest_path.exists():
        err("missing resolver-manifest.json")
    else:
        manifest = json.loads(manifest_path.read_text())
        if manifest.get("strategy") != "local_file_refs":
            err("resolver manifest must use local_file_refs")
        if not (BASE / manifest.get("envelope", "")).exists():
            err("envelope schema listed in manifest is missing")
        for name in manifest.get("event_schemas", []):
            path = BASE / name
            if not path.exists():
                err(f"missing event schema {name}")
                continue
            text = path.read_text()
            doc = json.loads(text)
            if doc.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
                err(f"{name}: wrong JSON Schema draft")
            if "additionalProperties" not in text:
                err(f"{name}: missing additionalProperties policy")
            for ref in re.findall(r'"\$ref"\s*:\s*"([^"]+)"', text):
                if not ref.startswith("#/") and not (BASE / ref).exists():
                    err(f"{name}: unresolved local ref {ref}")
    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print("Event schema validation passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
