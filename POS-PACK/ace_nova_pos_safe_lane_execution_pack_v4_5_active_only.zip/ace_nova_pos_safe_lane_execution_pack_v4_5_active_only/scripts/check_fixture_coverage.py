#!/usr/bin/env python3
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS = []

def main():
    refs = []
    for spec_path in (ROOT / "contracts/openapi").glob("*.json"):
        doc = json.loads(spec_path.read_text())
        for methods in doc.get("paths", {}).values():
            for op in methods.values():
                refs.extend(op.get("x-contract-test-fixtures", []))
    for ref in refs:
        if not (ROOT / ref).exists():
            ERRORS.append(f"missing fixture {ref}")
    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print(f"Fixture coverage passed: {len(refs)} references")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
