#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS = []

def main():
    for path in ROOT.rglob("*"):
        rel = path.relative_to(ROOT).as_posix()
        if "__pycache__" in rel or rel.endswith(".pyc"):
            ERRORS.append(f"{rel}: cache artifact forbidden")
        if not path.is_file() or path.suffix.lower() not in [".py", ".js", ".ts", ".json", ".md", ".sql", ".yaml", ".yml", ".txt"]:
            continue
        if (
            rel.startswith("docs/")
            or rel.startswith("SECURITY/")
            or rel in ["README.md", "REPOSITORY_LAYOUT.md"]
            or rel.startswith("scripts/")
        ):
            continue
        text = path.read_text(errors="ignore")
        if re.search(r"https?://(?!example\.invalid)(?!json-schema\.org)", text):
            ERRORS.append(f"{rel}: non-placeholder URL")
        if re.search(r"\b(import\s+requests|import\s+httpx|axios\.|fetch\(|socket\.|urllib|curl|wget)\b", text, re.I):
            ERRORS.append(f"{rel}: network usage")
        if rel.startswith("src/") and not (rel.startswith("src/ports/") or rel.startswith("src/simulators/") or rel.startswith("src/stubs/")):
            ERRORS.append(f"{rel}: source outside safe lanes")
    for spec_path in (ROOT / "contracts/openapi").glob("*.json"):
        doc = json.loads(spec_path.read_text())
        for server in doc.get("servers", []):
            if server.get("url") != "https://example.invalid":
                ERRORS.append(f"{spec_path}: non-placeholder server")
        for path in doc.get("paths", {}):
            if not any(token in path.lower() for token in ["simulator", "stub", "mock", "safe-lane", "safe_lane"]):
                ERRORS.append(f"{spec_path}: production-looking path {path}")
    sql = (ROOT / "database/drafts/pos_schema_draft.sql").read_text(errors="ignore")
    for term in ["payment", "settlement", "fiscal", "refund", "adapter", "customer", "inventory", "replay", "reporting"]:
        if term in sql.lower() and "TODO-BLOCKER" not in sql:
            ERRORS.append(f"database draft missing TODO-BLOCKER for {term}")
    if ERRORS:
        print("\n".join(ERRORS))
        return 1
    print("Architecture guardrail validation passed")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
