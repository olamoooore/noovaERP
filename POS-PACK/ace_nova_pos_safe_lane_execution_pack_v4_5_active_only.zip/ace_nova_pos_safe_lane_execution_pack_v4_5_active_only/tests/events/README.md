Run `make validate-events` and `make validate-event-fixtures`.
