Run `make validate-openapi` and `make check-fixture-coverage`.
