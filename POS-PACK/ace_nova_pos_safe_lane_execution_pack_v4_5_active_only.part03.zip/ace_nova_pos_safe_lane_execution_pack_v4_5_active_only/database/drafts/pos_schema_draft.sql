-- ACE Nova POS Safe-Lane Execution Database Draft v4.
-- Not production migration. TODO-BLOCKER markers preserve blocked production domains.
CREATE TABLE tenant (tenant_id TEXT PRIMARY KEY, status TEXT NOT NULL);
CREATE TABLE payment_attempt (payment_attempt_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: live payment provider and settlement reconciliation blocked
CREATE TABLE receipt (receipt_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: fiscal/e-invoice and receipt numbering blocked
CREATE TABLE refund (refund_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: refund settlement and offline finalized refund blocked
CREATE TABLE inventory_posting_intent (intent_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: inventory authority and intercompany inventory blocked
CREATE TABLE replay_event (replay_event_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: production replay blocked
CREATE TABLE customer_privacy_gate (gate_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: customer cache/privacy blocked
CREATE TABLE reporting_projection (projection_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, confidence_label TEXT NOT NULL); -- TODO-BLOCKER: finance-authoritative reporting blocked
CREATE TABLE adapter_config (adapter_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: live external adapters blocked
CREATE TABLE monitoring_sop_gate (gate_id TEXT PRIMARY KEY, tenant_id TEXT NOT NULL, status TEXT NOT NULL); -- TODO-BLOCKER: production monitoring/SOP closure blocked
