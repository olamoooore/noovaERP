# ADR 000 v3 — AI Coding Agent Instruction

## Purpose
This file controls AI coding tools used by junior engineers. AI must not invent architecture.

## Non-Negotiable AI Coding Rules
```text
1. Do not create new shared services inside a domain module.
2. Do not invent table names when ADR names exist.
3. Do not bypass service contracts.
4. Do not remove tenant_id filters.
5. Do not remove entity_id filters where required.
6. Do not simplify permission logic.
7. Do not replace backend permission with frontend hiding.
8. Do not directly query another module’s tables.
9. Do not create fake tests that only assert status 200.
10. Do not claim completion without evidence.
```

## Required AI Prompt Prefix for Engineering Tasks
```text
Follow ADR 000 Shared Platform Services Architecture.
Use existing shared services and contracts.
Do not create module-local duplicates of shared services.
Enforce tenant isolation, entity visibility, backend permission, audit, standard errors, and negative tests.
Return implementation plan before code.
List files to be changed.
List tests to be added.
List evidence required.
Do not claim done without tests and evidence.
```

## AI Must Ask Before Doing These
```text
Creating a new table that sounds like a shared service
Adding direct query to another module table
Changing permission evaluation
Changing tenant/entity scope logic
Bypassing audit
Changing runtime mode behaviour
Changing entitlement logic
Changing AI access policy
```

## AI Output Must Include
```text
Scope implemented
Files changed
Shared services consumed
Permissions checked
Tenant/entity filters applied
Audit events added
Positive tests
Negative tests
Known limitations
```

## Rejected AI Output
```text
“Implemented everything.”
“Added basic CRUD.”
“Should work.”
“No tests needed.”
“Used frontend restriction only.”
“Created temporary direct query.”
```
