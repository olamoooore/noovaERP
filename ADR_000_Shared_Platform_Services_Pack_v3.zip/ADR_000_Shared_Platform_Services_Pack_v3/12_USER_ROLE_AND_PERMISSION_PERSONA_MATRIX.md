# ADR 000 v3 — User Role and Permission Persona Matrix

## Status
Ready for Engineering Source of Truth.

## Purpose
This file prevents junior engineers and interns from creating one generic “admin user” model. Every shared service and module must be designed against real ERP personas, not abstract CRUD users.

## Non-Negotiable Rule
```text
A user role is not just a label.
A user role defines what the user can see, what the user can do, what the user cannot do, what approval is required, and what audit evidence must be recorded.
```

## Persona Matrix

| Persona | Purpose | Allowed Actions | Blocked Actions | Required Controls |
|---|---|---|---|---|
| Platform Owner | Operates AceNova platform globally | Manage platform configuration, architecture exceptions, shared services, global incidents | Tenant business transaction posting unless support access approved | Platform audit, architecture approval, support access audit |
| Platform Architect | Owns architecture compliance | Approve module contracts, runtime modes, shared-service boundaries, exceptions | Directly change tenant business records without approval | Architecture review evidence |
| DevOps / Release Manager | Controls releases and infrastructure | Deploy, rollback, monitor, manage environments | Business data modification | Deployment audit, release evidence |
| Support Agent | Helps tenant users | View support-authorized diagnostic data | Access restricted tenant data without support access approval | Support access approval, audit, expiry |
| Tenant Owner | Owns tenant subscription/workspace | Manage tenant profile, billing, high-level admins, offboarding | Platform-level settings, other tenants | Tenant audit, entitlement controls |
| Tenant Admin | Administers tenant setup | Invite users, enable modules, assign roles, configure tenant settings | Bypass subscription, bypass privacy, access HR restricted data unless granted | Permission audit, setup-change audit |
| Entity Admin | Administers assigned entity/company/branch/outlet | Configure assigned entity, users, records within entity | Other entities unless assigned | Entity scope enforcement |
| Finance Manager | Manages finance controls | Approve accounting setup, payments, credit holds, finance exports | HR restricted data, platform admin settings | Approval audit, finance permission |
| Accountant | Performs accounting operations | View/post allowed accounting records, reports, tax data | Platform config, HR restricted, unauthorized entities | Period/permission/audit controls |
| Auditor | Reviews records and evidence | Read-only audit, reports, evidence packs within assigned scope | Create/update/delete business records | Read-only permission, audit-view audit |
| Sales User | Manages leads/customers/quotes | CRM records, sales follow-ups, allowed customer contacts | Vendor payment data, HR restricted data | CRM permission, contact visibility |
| Purchase User | Manages vendors/purchasing | Vendor contacts, purchase records, supplier forms | Customer credit decisions, HR restricted data | Purchase permission, contact visibility |
| HR Manager | Manages staff profiles | HR staff profile, restricted HR data, staff export | Non-HR financial override unless assigned | HR restricted permission, sensitive audit |
| Property Manager | Manages property contacts and operations | Tenant/owner/resident/contractor profiles within assigned properties | HR/payroll/platform admin | Property scope permission |
| Project Manager | Manages project contacts and assignments | Project stakeholders, contractors, project-related contacts | HR restricted, unrelated financial admin | Project scope permission |
| Portal User | External customer/vendor/member/tenant user | Self-service records explicitly shared with them | Search all contacts, view other users, internal notes | Portal access scope, record ownership |
| Integration Service Account | Machine account for connectors | API actions within granted connector scope | UI login, broad data export, unrestricted query | API scope, idempotency, external refs, audit |
| AI Service Account | Executes approved AI tasks | Access policy-filtered context only | Raw table access, restricted data outside policy, direct write without approval | AI policy, reasoning record, approval audit |

## Engineering Interpretation
```text
Never build a feature only for “admin”.
Always identify the persona, permission, entity scope, privacy scope, approval need, and audit event.
```

## Minimum Role Test Examples
| Test | Expected Result |
|---|---|
| Sales User calls HR restricted profile API | PERMISSION_DENIED |
| Portal User searches all contacts | PERMISSION_DENIED |
| Tenant Admin enables non-entitled module | FEATURE_NOT_ENTITLED |
| Auditor tries to update invoice | PERMISSION_DENIED |
| Support Agent accesses tenant without approval | SUPPORT_ACCESS_DENIED |
| AI Service Account requests raw database data | AI_RAW_ACCESS_DENIED |
