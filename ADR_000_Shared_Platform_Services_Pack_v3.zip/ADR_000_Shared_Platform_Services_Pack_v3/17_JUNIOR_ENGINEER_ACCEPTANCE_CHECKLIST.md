# ADR 000 v3 — Junior Engineer Acceptance Checklist

## Purpose
This checklist is mandatory for junior engineers and interns before claiming any task is complete.

## Before You Claim Done
Answer every question. Any “No” means not ready.

| No. | Question | Yes/No |
|---:|---|---|
| 1 | Did you identify the user role/persona using this function? |  |
| 2 | Did you define the business purpose in one sentence? |  |
| 3 | Did you define the expected workflow, not just CRUD? |  |
| 4 | Did every query filter by `tenant_id`? |  |
| 5 | Did every entity-specific query filter/check `entity_id` where required? |  |
| 6 | Did the backend API check permission? |  |
| 7 | Did you avoid frontend-only security? |  |
| 8 | Did you check subscription entitlement where needed? |  |
| 9 | Did you check module enablement where needed? |  |
| 10 | Did you check feature flag where needed? |  |
| 11 | Did you check runtime mode where needed? |  |
| 12 | Did you check record visibility/privacy where needed? |  |
| 13 | Did you create audit events for important actions? |  |
| 14 | Did you use standard error response format? |  |
| 15 | Did you prevent raw backend/database errors? |  |
| 16 | Did you avoid creating duplicate shared services inside a module? |  |
| 17 | Did you avoid direct cross-module table access? |  |
| 18 | Did you use idempotency for external writes/retries? |  |
| 19 | Did you include positive tests? |  |
| 20 | Did you include negative tests? |  |
| 21 | Did you test wrong tenant access? |  |
| 22 | Did you test no-permission access? |  |
| 23 | Did you test disabled module or not-entitled feature where relevant? |  |
| 24 | Did you test duplicate/replay where relevant? |  |
| 25 | Did you attach API request/response samples? |  |
| 26 | Did you attach screenshot evidence where UI exists? |  |
| 27 | Did you provide branch name and commit hash? |  |
| 28 | Did you provide migration fresh-run and rollback evidence? |  |
| 29 | Did you list known limitations honestly? |  |
| 30 | Did you avoid claiming module/platform complete beyond the approved scope? |  |

## Forbidden Completion Claims
```text
Done but not tested.
Done but no screenshot.
Done but only frontend.
Done but no negative tests.
Done but no audit.
Done but cannot show commit.
Done but not deployed.
Done but AI generated it.
```

## Required Completion Statement Format
```text
I implemented [service/feature] under [ADR / phase / block].
Branch: [branch]
Commit: [hash]
Scope completed: [specific list]
Positive tests: [summary]
Negative tests: [summary]
Evidence attached: [links/files]
Known limitations: [list]
I am not claiming completion beyond this scope.
```
