# ADR 000 — AceNova Shared Platform Services Architecture Pack

## Purpose

This pack defines the shared platform-service architecture that all AceNova ERP modules must consume.

It prevents duplicated module-local engines, direct cross-module table access, inconsistent entitlement checks, weak audit trails, uncontrolled AI access, unsafe integrations, and unsupported engineering completion claims.

## Contents

1. `01_ADR_000_SHARED_PLATFORM_SERVICES_ARCHITECTURE.md`
2. `02_SHARED_SERVICE_CONTRACT_TEMPLATE.md`
3. `03_MODULE_CONTRACT_TEMPLATE.md`
4. `04_RUNTIME_MODE_MATRIX.md`
5. `05_SUBSCRIPTION_TIER_ENTITLEMENT_MATRIX.md`
6. `06_EVALUATION_ORDER_AND_DEPENDENCY_RULES.md`
7. `07_MATURITY_ERROR_NFR_EVIDENCE.md`
8. `08_ARCHITECTURE_EXCEPTION_AND_CLAIM_BOUNDARIES.md`
9. `09_ENGINEER_IMPLEMENTATION_INSTRUCTION.md`
10. `manifest.json`

## Status

Draft for Approval.

## Critical Rule

Shared services are platform-owned. Domain modules consume shared services and own only domain-specific business logic.

No module may recreate shared services internally unless a documented architecture exception is approved with owner, risk, expiry date, and refactor plan.


## v2 Addition

This v2 pack adds the missing shared service catalog and priority matrix:

- `10_SHARED_SERVICE_CATALOG_AND_PRIORITY_MATRIX.md`
- `10_SHARED_SERVICE_CATALOG_AND_PRIORITY_MATRIX.csv`
- `11_SHARED_SERVICE_PRIORITY_SUMMARY.md`

The ADR 000 pack is not complete without these files because the 15 pillars require a service-level backlog and implementation priority.


## v3 Junior-Engineer Implementation Layer
This v3 pack adds maximum-expectation guardrails to reduce rework by junior engineers, interns, and AI coding agents.

Additional files:
- 12_USER_ROLE_AND_PERMISSION_PERSONA_MATRIX.md
- 13_P0_SHARED_SERVICE_WORKFLOWS.md
- 14_MINIMUM_UI_BEHAVIOUR_GUIDE.md
- 15_CORRECT_VS_WRONG_IMPLEMENTATION_EXAMPLES.md
- 16_P0_DELIVERY_BLOCKS_AND_SPRINT_SEQUENCE.md
- 17_JUNIOR_ENGINEER_ACCEPTANCE_CHECKLIST.md
- 18_QA_NEGATIVE_TEST_MASTERLIST.md
- 19_AI_CODING_AGENT_INSTRUCTION.md
- 20_GLOSSARY_LAYMAN_TERMS.md

Do not send only the architecture pillar list to junior engineers. Send this v3 pack and require the acceptance checklist for every task.
