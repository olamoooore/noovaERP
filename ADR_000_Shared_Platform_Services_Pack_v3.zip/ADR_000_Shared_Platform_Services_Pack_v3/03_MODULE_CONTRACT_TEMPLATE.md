# Module Contract Template

Every AceNova module must complete this contract before implementation or production release.

## 1. Module Name

`[Module Name]`

## 2. Module Key

`[module_key]`

## 3. Module Owner

```text
Product owner:
Technical owner:
Support owner:
```

## 4. Runtime Mode

Declare one or more supported modes:

```text
Coupled Mode
Decoupled Mode
External Integration Mode
```

## 5. Subscription Entitlement Dependencies

State required tier or add-on entitlement:

```text
Enterprise Custom
Enterprise Standard
SME Growth
SME Essential
Add-on required:
```

## 6. Feature Dependencies

List required feature flags.

## 7. Shared Service Dependencies

List consumed ADR 000 shared services.

## 8. Owned Domain Data

List domain-owned tables/entities.

## 9. Does Not Own

Explicitly list platform services the module must not recreate.

## 10. Provided APIs

List APIs exposed by this module.

## 11. Consumed APIs

List APIs consumed from shared services or other approved modules.

## 12. Published Events

List domain events published by this module.

## 13. Consumed Events

List events consumed by this module.

## 14. Permissions

List module-specific permissions.

## 15. Activation Rules

State activation prerequisites:

```text
tenant active
subscription entitled
module enabled
feature flag enabled
runtime mode valid
setup complete
required shared services available
```

## 16. Deactivation Rules

State deactivation safety rules and historical record behaviour.

## 17. External Reference Rules

Required for External Integration Mode and external writes.

## 18. Idempotency Rules

Define idempotency keys for write operations, webhooks, imports, and sync jobs.

## 19. AI Capabilities

State AI capabilities and restrictions:

```text
AI summary allowed?
AI suggestion allowed?
AI write action allowed?
Approval required?
Restricted data excluded?
```

## 20. Setup Pack

List setup pack requirements.

## 21. Migration Rules

State migration/import requirements.

## 22. Positive Tests

List positive path tests.

## 23. Negative Tests

List negative path tests.

## 24. Evidence Pack

Required evidence:

```text
module contract registration
runtime mode evidence
entitlement evidence
permission evidence
tenant/entity isolation evidence
API/event evidence
audit evidence
idempotency evidence
safe error evidence
known limitation list
```

## 25. Known Limitations

List limitations before release.
