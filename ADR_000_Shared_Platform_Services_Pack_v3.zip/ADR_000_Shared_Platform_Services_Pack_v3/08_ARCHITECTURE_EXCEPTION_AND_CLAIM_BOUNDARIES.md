# Architecture Exception Rule and Engineer Claim Boundaries

## 1. Architecture Exception Rule

Any bypass requires architecture exception.

Required fields:

```text
exception_uuid
service_or_module
exception_type
reason
risk_level
approved_by
approved_at
expires_at
refactor_plan
owner
status
evidence_reference
```

Allowed temporary exception types:

```text
temporary_direct_table_access
temporary_unregistered_field
temporary_export_bypass
temporary_search_bypass
temporary_ai_bypass
temporary_lifecycle_bypass
temporary_permission_bypass
temporary_entitlement_bypass
temporary_runtime_mode_bypass
```

Security/privacy/tenant-isolation bypasses are not allowed unless explicitly approved by architecture owner with expiry and remediation plan.

No exception without expiry date is accepted.

## 2. Engineer Claim Boundaries

### Allowed Claims

```text
[Service Name] reached maturity level L3 and evidence pack is attached.
[Module Name] contract registered and validated.
[Module Name] Coupled Mode implementation tested and evidenced.
[Feature Name] entitlement, permission, visibility, privacy, audit, and negative tests passed.
```

### Not Allowed Claims

```text
Shared services completed.
Architecture completed.
Module completed.
Platform ready.
AI ready.
Security completed.
Compliance completed.
Tested successfully.
Implemented using AI agent.
No issue found.
```

## 3. Final Claim Rule

Every claim must be tied to:

```text
service or module name
maturity level
runtime mode if module-related
subscription entitlement if feature-related
positive tests
negative tests
audit evidence
tenant/entity evidence
known limitations
```
