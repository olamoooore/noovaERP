# Runtime Mode Matrix

Runtime mode defines module integration behaviour. It is not subscription tier.

| Runtime Mode | Meaning | Data Ownership | Integration Rule | Example |
|---|---|---|---|---|
| Coupled Mode | Native AceNova module inside platform | AceNova owns data and workflow | Uses shared services directly | AceNova Accounting uses Contact Master, Tax, Numbering, Audit |
| Decoupled Mode | Standalone AceNova-compatible module | Module owns domain data but follows AceNova contracts | Uses approved APIs/events/contracts | Property module runs separately but follows Contact/Billing/Notification contracts |
| External Integration Mode | Third-party system owns module logic | External system owns source data | AceNova stores mappings, sync status, idempotency, audit | Xero/Odoo/AutoCount/POS integration |

## Required Per-Mode Controls

| Control | Coupled | Decoupled | External Integration |
|---|---:|---:|---:|
| Tenant isolation | Required | Required | Required |
| Entity isolation | Required | Required | Required where applicable |
| Backend permission | Required | Required | Required |
| Audit trail | Required | Required | Required |
| Idempotency | Required for writes/retries | Required for writes/retries | Mandatory |
| External reference mapping | Optional | Required if cross-system | Mandatory |
| Module contract | Mandatory | Mandatory | Mandatory |
| API/event contract | Mandatory | Mandatory | Mandatory |
| AI policy | Required if AI-capable | Required if AI-capable | Required if AI-capable |
| Evidence pack | Mandatory | Mandatory | Mandatory |

## Non-Negotiable Rule

```text
Runtime mode changes integration behaviour.
It does not remove platform security, audit, privacy, idempotency, or evidence requirements.
```
