# ADR 000 — AceNova Shared Platform Services Architecture

## Implementation Status

**Draft for Approval**

## Product

AceNova ERP Platform

## Scope

Platform Core / Shared Business Core / Shared Governance Core / Shared AI and Integration Controls

## Decision Owner

Product / Platform Architecture Lead

---

# 1. Architecture Purpose

AceNova ERP is a modular SaaS ERP platform. The platform must support Enterprise Custom, Enterprise Standard, SME Growth, and SME Essential subscription tiers while allowing domain modules to run in Coupled Mode, Decoupled Mode, or External Integration Mode.

This ADR defines the shared platform services that must be consumed by all modules.

The purpose is to prevent:

```text
module-local duplicate shared services
inconsistent permissions
inconsistent tenant/entity isolation
inconsistent audit logs
uncontrolled setup flows
uncontrolled AI access
hardcoded entitlement checks
unversioned APIs/events
direct cross-module database access
unsafe integrations
unsafe migration
unsupported engineer completion claims
```

AceNova modules must consume shared services and retain only domain-specific business logic.

---

# 2. Platform Ownership Rule

## 2.1 Core Rule

```text
Shared services are platform-owned.
Domain modules consume shared services.
Domain modules must not recreate shared services internally.
```

## 2.2 Shared Service Ownership Requirements

Every shared service must declare:

```text
service owner
service boundary
owned data
consumed-by modules
provided APIs
published events
consumed events
permissions
tenant/entity scope
audit events
idempotency rule
privacy classification
AI access policy
export policy
error codes
test evidence
known limitations
```

## 2.3 Forbidden Pattern

```text
accounting_audit_service
crm_attachment_service
hr_numbering_service
property_workflow_engine
project_template_engine
pos_permission_service
module_specific_ai_access_rule
```

## 2.4 Correct Pattern

```text
Platform Audit Trail Service
Platform File and Attachment Service
Platform Document Numbering Service
Platform Workflow and Approval Service
Platform Template Service
Platform Permission Evaluation Service
Platform AI Access Control Service
```

Modules may configure shared services for their own domain use, but may not duplicate the shared service.

---

# 3. Fifteen Core Shared Service Pillars

## Pillar 1 — Identity, Tenant, Entity, and Access Core

Owns:

```text
tenant
workspace
entity
company
branch
department
user
role
permission
record-level access
session
MFA
SSO
SCIM
delegation
service account
```

Does not own domain-specific approval, document, contact profile, accounting posting, HR payroll, property billing, or project costing logic.

## Pillar 2 — Security, Risk, and Trust Controls

Owns:

```text
tenant isolation
entity isolation
segregation of duties
admin override
support access
rate limiting
abuse control
security incident register
encryption policy
secret management
data residency
trusted service access
```

## Pillar 3 — Contact and Master Data Core

Owns:

```text
Contact Master
contact roles
contact identifiers
contact addresses
contact methods
contact relationships
contact visibility
contact profile registry
contact hierarchy
duplicate control
contact migration safety
shared reference dictionaries
```

Does not own:

```text
product master
chart of accounts
payroll rules
property unit master
inventory item master
project WBS master
```

Those remain domain-owned unless formally promoted into shared platform services.

## Pillar 4 — Module Registry, Runtime Mode, and Contract Control

Owns:

```text
module registry
module contracts
module owner
runtime mode
Coupled Mode
Decoupled Mode
External Integration Mode
dependencies
owned entities
provided APIs
consumed APIs
published events
consumed events
permissions
activation rules
deactivation rules
external reference rules
idempotency rules
AI capability declaration
evidence requirements
```

No module is allowed to go live without a registered module contract.

## Pillar 5 — Commercial Entitlement, Subscription, and Packaging Core

Owns:

```text
Enterprise Custom
Enterprise Standard
SME Growth
SME Essential
plan entitlement
feature entitlement
module entitlement
user limits
entity limits
storage limits
API limits
AI usage limits
integration limits
support SLA
customization allowance
trial lifecycle
upgrade / downgrade
suspension
reactivation
offboarding
data portability
```

No module may hardcode subscription-tier checks internally.

## Pillar 6 — Workflow, Policy, Approval, and Orchestration

Owns:

```text
workflow status
policy engine
approval matrix
task
reminder
escalation
SLA
exception queue
human-in-the-loop approval
scheduled jobs
bulk workflow
```

Domain modules may define domain-specific conditions, but routing, approval state, escalation, audit, and evidence must use platform services.

## Pillar 7 — Audit, Evidence, Privacy, and Compliance Core

Owns:

```text
audit trail
system log
evidence pack
data classification
privacy consent
retention
legal hold
export control
restricted masking
data subject request
compliance evidence vault
```

This pillar provides compliance-readiness controls. It does not guarantee legal compliance without customer configuration, process discipline, and legal review.

## Pillar 8 — Documents, Content, Communication, and Templates

Owns:

```text
document numbering
document templates
attachments
archive
PDF generation
email templates
WhatsApp templates
notices
secure share links
digital signature
document versioning
message delivery log
communication channel registry
```

Document generation, template versioning, delivery, access control, and delivery evidence must be connected.

## Pillar 9 — Search, Navigation, Related Records, and Reporting

Owns:

```text
global search
search index
related record registry
smart buttons
dashboard widgets
report registry
report export
navigation registry
tags
categories
user preferences
```

No direct table query from one module into another module is allowed for search, reporting, Contact 360, dashboards, or smart buttons.

## Pillar 10 — Integration, Events, Automation, and Idempotency

Owns:

```text
API gateway
webhook manager
connector registry
external reference mapping
idempotency keys
domain event bus
retry policy
error queue
background jobs
integration health
```

Every external write must have external reference and idempotency control.

## Pillar 11 — Finance, Tax, Payment, Pricing, and Billing Rules Core

Owns:

```text
currency
FX rates
tax configuration
fiscal calendar
payment gateway registry
payment reference
price list
discount rule
credit control policy
billing schedule
recurring charge rule
settlement references
```

This pillar is not SaaS subscription entitlement. Subscription entitlement belongs to Pillar 5.

## Pillar 12 — AI Governance, Context, and Data Quality Core

Owns:

```text
AI access control
AI context builder
AI instruction templates
AI reasoning record
AI approval control
AI usage and cost control
AI safety rules
data quality rules
data quality scores
AI-safe summaries
```

AI must not read raw module tables directly. AI must consume permission-filtered, policy-approved context only.

## Pillar 13 — Data Platform, Analytics, Lineage, and Portability

Owns:

```text
data catalog
data lineage
analytics views
data warehouse export
BI connector
reporting model
data anonymization
data portability
data ownership metadata
data retention analytics
```

Operational module tables are not the same as analytics/reporting data products.

## Pillar 14 — Observability, Reliability, Release, and Operations

Owns:

```text
performance monitoring
product telemetry
API latency
job queue monitoring
incident management
status page
backup
restore
disaster recovery
release management
environment management
deployment evidence
```

No production module release is accepted without observability and rollback evidence.

## Pillar 15 — Product Operations, Support, and Customer Success

Owns:

```text
company setup wizard
industry templates
setup health check
guided go-live checklist
in-app help
knowledge base
support ticket
training mode
demo data
customer success health
tenant health dashboard
```

This pillar supports SaaS operations and user adoption. It must not become Accounting, CRM, HR, Property, or Project business logic.

---

# 4. Shared Service Contract Template

Every shared service must use the standard contract template defined in `02_SHARED_SERVICE_CONTRACT_TEMPLATE.md`.

Minimum required sections:

```text
Service Name
Pillar
Owner
Purpose
Consumers
Owned Data
Does Not Own
APIs
Events Published
Events Consumed
Permissions
Tenant Scope
Entity Scope
Audit Events
Idempotency Requirement
Privacy Classification
AI Access Policy
Export Policy
Error Codes
Positive Tests
Negative Tests
Evidence Pack
Known Limitations
```

---

# 5. Module Contract Template

Every module must use the standard module contract template defined in `03_MODULE_CONTRACT_TEMPLATE.md`.

Minimum required sections:

```text
Module Name
Module Key
Module Owner
Runtime Mode
Subscription Entitlement Dependencies
Feature Dependencies
Shared Service Dependencies
Owned Domain Data
Does Not Own
Provided APIs
Consumed APIs
Published Events
Consumed Events
Permissions
Activation Rules
Deactivation Rules
External Reference Rules
Idempotency Rules
AI Capabilities
Setup Pack
Migration Rules
Positive Tests
Negative Tests
Evidence Pack
Known Limitations
```

---

# 6. Runtime Mode Matrix

Runtime mode controls how a module operates and integrates.

It is not the same as subscription tier.

| Runtime Mode | Meaning | Data Ownership | Integration Rule |
|---|---|---|---|
| Coupled Mode | Native AceNova module running inside the platform | AceNova owns data and workflow | Uses shared services directly |
| Decoupled Mode | Standalone AceNova-compatible module | Module owns domain data but follows AceNova contracts | Uses approved APIs/events/contracts |
| External Integration Mode | Third-party system owns module logic | External system owns source data | AceNova stores mappings, sync status, idempotency, audit |

Non-negotiable:

```text
Runtime mode changes integration behaviour.
Runtime mode does not remove tenant isolation, permission checks, audit, idempotency, privacy, or evidence requirements.
```

---

# 7. Subscription Tier Entitlement Matrix

Subscription tier controls commercial entitlement.

It is not the same as runtime mode.

| Tier | Purpose | Configuration Depth | Support Level | Customization |
|---|---|---|---|---|
| Enterprise Custom | Large clients requiring custom deployment/process | High | Custom SLA | High |
| Enterprise Standard | Enterprise-ready standard package | Medium-high | Enterprise SLA | Controlled |
| SME Growth | Growing SME requiring broader modules | Medium | Standard | Limited |
| SME Essential | Basic SME package | Low | Basic | Minimal |

Non-negotiable:

```text
Modules must call Entitlement Service.
Modules must not hardcode subscription tier rules internally.
```

---

# 8. Evaluation Order

Every request must be evaluated in this order:

```text
1. Tenant active?
2. Subscription tier entitled?
3. Module enabled?
4. Feature flag enabled?
5. Runtime mode valid?
6. User authenticated?
7. User has permission?
8. Entity visibility allowed?
9. Record visibility allowed?
10. Privacy policy allows?
11. Approval required?
12. Audit recorded?
```

Critical interpretation rules:

```text
Passing permission does not override subscription entitlement.
Passing entitlement does not override permission.
Passing module enablement does not override privacy restriction.
Passing runtime mode does not override idempotency, audit, or evidence.
Passing frontend visibility does not prove backend access.
```

---

# 9. Dependency Direction Rules

## 9.1 Allowed Direction

```text
Platform Core
    ↓
Shared Business Core Services
    ↓
Domain Modules
    ↓
External Integrations / UI / AI Consumers
```

## 9.2 Forbidden Dependency

```text
Platform Core depends on Accounting.
Contact Master directly queries Accounting invoices.
CRM directly queries HR staff private data.
Dashboard directly queries all module tables.
AI reads raw module tables.
```

## 9.3 Correct Dependency

```text
Accounting consumes Contact Master API.
CRM consumes Contact Master API.
Contact 360 uses Related Records Registry.
Dashboard uses Report Registry / approved summary APIs.
AI uses AI Context Builder.
External connector uses Connector Registry and Idempotency Service.
```

---

# 10. Shared Service Maturity Model

Every shared service must declare maturity level.

| Level | Name | Meaning |
|---:|---|---|
| L0 | Not Implemented | No usable implementation |
| L1 | Registry / Contract Only | Declared but no production API |
| L2 | Basic API | API exists with basic validation and permission |
| L3 | Evidence-Ready | API, permission, audit, positive/negative tests, evidence |
| L4 | Multi-Tenant Production-Grade | Tenant/entity isolation, monitoring, rollback, performance, safe errors |
| L5 | Enterprise-Grade | Admin UI, policy control, enterprise monitoring, migration support, support evidence |

Completion claims must state maturity level.

Rejected:

```text
Document Numbering Service completed.
```

Accepted:

```text
Document Numbering Service reached L3: API, permissions, audit events, positive tests, negative tests, and evidence pack completed.
```

---

# 11. Error Response Standard

All APIs must return standard error structure.

```json
{
  "success": false,
  "error": {
    "code": "MODULE_NOT_ENABLED",
    "message": "This module is not enabled for this tenant.",
    "details": {},
    "request_id": "REQ-2026-000001"
  }
}
```

Mandatory error codes:

```text
TENANT_ACCESS_DENIED
ENTITY_ACCESS_DENIED
PERMISSION_DENIED
MODULE_NOT_ENABLED
FEATURE_NOT_ENTITLED
RUNTIME_MODE_INVALID
VALIDATION_FAILED
DUPLICATE_RECORD
IDEMPOTENCY_REPLAY
RESTRICTED_DATA_DENIED
APPROVAL_REQUIRED
EXTERNAL_SYNC_FAILED
SYSTEM_ERROR
```

Raw route, stack trace, database error, ORM error, secret, token, file path, or internal infrastructure detail must not be exposed to users.

---

# 12. Non-Functional Requirements Baseline

Minimum NFR baseline for production shared services:

```text
Tenant isolation on every query
Entity isolation where applicable
Backend permission enforcement
Standard error response
Request ID propagation
Audit event for sensitive actions
Idempotency for external writes and retries
Database indexes for primary filters
Migration fresh-run evidence
Rollback evidence
Positive tests
Negative tests
Known limitation list
Observability/logging
Safe timeout and retry behaviour
Export expiry where applicable
Restricted data masking where applicable
```

Recommended measurable targets must be defined per service before implementation:

```text
availability target
backup frequency
restore time objective
restore point objective
API latency target
background job retry policy
audit retention
log retention
file retention
export expiry
rate limits
maximum import size
maximum export size
maximum attachment size
concurrency control
record locking
```

---

# 13. Evidence Pack Standard

No completion claim is accepted without evidence.

Minimum evidence pack:

```text
Git branch name
commit hash
file diff
migration files
migration fresh-run output
migration rollback output
database schema
index list
route list
API request/response samples
permission test evidence
tenant isolation evidence
entity visibility evidence
audit log samples
idempotency evidence where applicable
privacy/masking evidence where applicable
AI policy evidence where applicable
positive test result
negative test result
safe error response samples
observability/logging evidence
known limitation list
```

Generic statements such as “tested successfully” are not accepted.

---

# 14. Architecture Exception Rule

Any bypass requires architecture exception.

Required fields:

```text
exception_uuid
service_or_module
exception_type
reason
risk_level
approved_by
approved_at
expires_at
refactor_plan
owner
status
evidence_reference
```

Allowed temporary exception types:

```text
temporary_direct_table_access
temporary_unregistered_field
temporary_export_bypass
temporary_search_bypass
temporary_ai_bypass
temporary_lifecycle_bypass
temporary_permission_bypass
temporary_entitlement_bypass
temporary_runtime_mode_bypass
```

Security/privacy/tenant-isolation bypasses are not allowed unless explicitly approved by architecture owner with expiry and remediation plan.

No exception without expiry date is accepted.

---

# 15. Engineer Claim Boundaries

## Allowed Claims

```text
[Service Name] reached maturity level L3 and evidence pack is attached.
[Module Name] contract registered and validated.
[Module Name] Coupled Mode implementation tested and evidenced.
[Feature Name] entitlement, permission, visibility, privacy, audit, and negative tests passed.
```

## Not Allowed Claims

```text
Shared services completed.
Architecture completed.
Module completed.
Platform ready.
AI ready.
Security completed.
Compliance completed.
Tested successfully.
Implemented using AI agent.
No issue found.
```

Claims must be tied to service, module, maturity level, test evidence, and known limitations.

---

# Final Engineering Rule

```text
If a capability is used by two or more modules, or affects security, audit, workflow, documents, AI access, module activation, integration, evidence, numbering, templates, contact identity, export, entitlement, runtime mode, or compliance-readiness control, it must be reviewed as a shared platform service first.
```
