# ADR 000 v3 — Correct vs Wrong Implementation Examples

## Purpose
This file is for junior engineers and AI coding agents. It shows exactly what must not be built.

| Topic | Wrong Implementation | Correct Implementation |
|---|---|---|
| Permission | Hide button in frontend only | Backend API checks permission and rejects unauthorized request |
| Tenant Isolation | Query by record ID only | Every query filters by `tenant_id` and required entity scope |
| Contact Master | Create `customer_master` in Accounting | Use `core_contacts` + customer role + accounting customer profile |
| Vendor Master | Create `vendor_master` in Purchase | Use shared Contact Master + vendor role + vendor profile |
| Staff Master | Store staff details in generic contacts table | Use Contact Master + HR staff profile with restricted controls |
| Module Enablement | Simple ON/OFF toggle | Entitlement check + module contract + dependency check + setup pack + audit |
| Runtime Mode | Hardcode external mode in module code | Declare Coupled/Decoupled/External mode in module contract |
| Subscription Tier | `if plan == SME` inside Accounting | Call Entitlement Service |
| Feature Flag | Hardcode beta feature visible | Use Feature Flag Service and audit rollout |
| Document Numbering | Each module creates own number generator | All modules call Document Numbering Service |
| Attachments | Each module stores file path separately | Use File and Attachment Service with classification/access policy |
| Audit | Write plain text log | Store actor, action, old value, new value, request ID, timestamp |
| Export | Direct CSV download from table | Use Export Control Service with masking, expiry, audit |
| External Webhook | Insert payload directly | Validate source, external ref, idempotency, permission scope, audit |
| Idempotency | Retry creates another invoice/contact | Replay returns same result or blocks duplicate safely |
| Related Records | Contact Master queries invoice table | Use Related Records Registry / approved module API |
| Smart Button | Fake count hardcoded | Registered permission-aware count from owning module |
| AI | AI queries database tables directly | AI uses AI Context Builder with permission-filtered context |
| AI Action | AI posts transaction automatically | AI creates suggestion/draft; approval required for sensitive action |
| Error Handling | Show SQL/stack trace | Return standard safe error response with request ID |
| Tests | Only happy-path test | Positive and negative tests with tenant/entity/permission/audit evidence |
| Evidence | “Done, tested locally” | Branch, commit, API samples, screenshots, tests, limitations |

## Hard Rejection Examples
```text
Created table only = rejected.
Created route only = rejected.
Frontend-only permission = rejected.
No negative tests = rejected.
No audit event = rejected.
No tenant/entity evidence = rejected.
No standard error response = rejected.
AI-generated explanation without proof = rejected.
```
