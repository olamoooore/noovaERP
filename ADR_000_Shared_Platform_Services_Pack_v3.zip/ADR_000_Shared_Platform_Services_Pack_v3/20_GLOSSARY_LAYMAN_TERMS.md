# ADR 000 v3 — Glossary in Layman Terms

## Purpose
This glossary helps interns and junior engineers understand architecture terms in simple language.

| Term | Layman Meaning | Example |
|---|---|---|
| Tenant | One customer workspace | ABC Sdn Bhd using AceNova |
| Entity | One company/branch/outlet inside a tenant | ABC KL Branch, ABC SG Pte Ltd |
| Module | A business app | Accounting, CRM, HR, POS |
| Shared Service | Common platform function used by many modules | Audit Trail, Contact Master, Numbering |
| Domain Module | Module with business-specific logic | Accounting owns invoice posting logic |
| Platform Core | Shared foundation all modules use | Permission, tenant, audit, contact identity |
| Runtime Mode | How a module operates/integrates | Coupled, Decoupled, External Integration |
| Coupled Mode | Native AceNova module | AceNova Accounting |
| Decoupled Mode | Standalone but contract-compliant module | Separate Property module using AceNova APIs |
| External Integration Mode | Third-party system owns logic | Xero/Odoo/POS connected to AceNova |
| Subscription Tier | What the customer paid for | Enterprise Custom, SME Growth |
| Entitlement | Whether tenant is allowed to use feature | SME Essential not entitled to HR module |
| Feature Flag | Controlled rollout switch | Enable beta report for one tenant |
| Permission | Whether user can perform action | Accountant can post invoice |
| Visibility | Whether user can see record | Sales user only sees assigned entity contacts |
| Privacy Restriction | Whether data is sensitive/restricted | HR emergency phone hidden from sales |
| Idempotency | Prevent duplicate write from repeated request | Same webhook does not create two payments |
| External Reference | ID from another system | Xero Contact ID, MyInvois UUID |
| Audit Trail | Proof of who changed what and when | User A changed credit limit at 10:01 |
| Evidence Pack | Proof engineer actually built/tested | Commit, API sample, test result, screenshot |
| Architecture Exception | Temporary approved bypass | Direct query allowed until date with refactor plan |
| Service Contract | Written rule for how service is used | API, events, permissions, audit, tests |
| Module Contract | Written rule for module behaviour | Dependencies, runtime mode, owned data |
| Negative Test | Test that proves wrong action is blocked | No-permission user cannot export HR data |
| Data Quality | Whether data is complete and usable | Customer missing billing email warning |
| AI Context | Safe data summary given to AI | Contact summary excluding restricted data |

## Simple Rule
```text
If you do not understand the business purpose of a function, do not build CRUD blindly.
Ask for the user role, workflow, expected outcome, and failure cases first.
```
