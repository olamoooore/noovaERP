# Shared Service Contract Template

Every shared platform service must complete this template before implementation.

## 1. Service Name

`[Service Name]`

## 2. Pillar

`[One of the 15 ADR 000 pillars]`

## 3. Owner

```text
Platform owner:
Technical owner:
Product owner:
```

## 4. Purpose

Explain what the service controls and why it is platform-owned.

## 5. Consumers

List consuming modules:

```text
Accounting
CRM
Sales
Purchase
Inventory
POS
HR
Property
Project
Portal
Membership
Loyalty
External Integration
AI
```

## 6. Owned Data

List tables/entities owned by this service.

## 7. Does Not Own

Explicitly state what remains domain-owned.

## 8. APIs

List API endpoints and purpose.

## 9. Events Published

List domain/platform events emitted by this service.

## 10. Events Consumed

List events this service consumes.

## 11. Permissions

List backend permissions required.

## 12. Tenant Scope

Define tenant isolation rule.

## 13. Entity Scope

Define entity/branch/department scope where applicable.

## 14. Audit Events

List audit events.

## 15. Idempotency Requirement

State whether idempotency is required.

If required, define uniqueness key:

```text
tenant_id + source_system + idempotency_key
```

## 16. Privacy Classification

Define field/record classification:

```text
public
internal
confidential
restricted
sensitive_personal
```

## 17. AI Access Policy

Define whether AI access is:

```text
allowed
summary_only
restricted
prohibited
```

## 18. Export Policy

Define export policy:

```text
exportable
masked_by_default
restricted_export_required
not_exportable
```

## 19. Error Codes

List expected error codes.

## 20. Positive Tests

List expected positive path tests.

## 21. Negative Tests

List expected negative path tests.

## 22. Evidence Pack

Required evidence:

```text
branch
commit hash
diff
migration evidence
route list
API samples
tests
audit samples
idempotency samples where applicable
safe error samples
known limitations
```

## 23. Known Limitations

State what is not yet implemented.

## 24. Maturity Level

Declare current level:

```text
L0 / L1 / L2 / L3 / L4 / L5
```
