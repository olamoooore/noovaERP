# ADR 000 v3 — QA Negative Test Masterlist

## Purpose
Every junior engineer must prove the system blocks wrong behaviour. Happy-path testing is not enough.

## Mandatory Negative Tests

| Test ID | Negative Test | Expected Error / Result |
|---|---|---|
| NEG-001 | User from Tenant A accesses Tenant B record | TENANT_ACCESS_DENIED |
| NEG-002 | User accesses entity they are not assigned to | ENTITY_ACCESS_DENIED |
| NEG-003 | User without permission calls protected API | PERMISSION_DENIED |
| NEG-004 | Disabled module API is called | MODULE_NOT_ENABLED |
| NEG-005 | Non-entitled feature is used | FEATURE_NOT_ENTITLED |
| NEG-006 | Invalid runtime mode action attempted | RUNTIME_MODE_INVALID |
| NEG-007 | Frontend button hidden but API called directly | API rejects request |
| NEG-008 | Duplicate external reference submitted | DUPLICATE_EXTERNAL_REFERENCE |
| NEG-009 | Same idempotency key replayed | IDEMPOTENCY_REPLAY returns safe result |
| NEG-010 | Webhook invalid signature | WEBHOOK_SIGNATURE_INVALID |
| NEG-011 | Raw database error occurs | Standard SYSTEM_ERROR, no raw leak |
| NEG-012 | Restricted field viewed without permission | RESTRICTED_DATA_DENIED |
| NEG-013 | Restricted field exported without permission | EXPORT_RESTRICTED_DENIED |
| NEG-014 | Approval-required action submitted without approval | APPROVAL_REQUIRED |
| NEG-015 | Audit event missing for sensitive action | Test fails / not accepted |
| NEG-016 | AI requests raw table access | AI_RAW_ACCESS_DENIED |
| NEG-017 | AI context includes restricted HR/private data | Test fails / blocked |
| NEG-018 | Contact duplicate auto-merged | Blocked; human approval required |
| NEG-019 | Module creates local duplicate shared service | Architecture review fails |
| NEG-020 | Cross-module direct table query added | Architecture review fails |
| NEG-021 | Import writes directly to live table | Rejected; staging required |
| NEG-022 | File linked to wrong tenant/entity | FILE_ACCESS_DENIED |
| NEG-023 | Export file accessed after expiry | EXPORT_EXPIRED |
| NEG-024 | User limit exceeded under subscription | SUBSCRIPTION_LIMIT_EXCEEDED |
| NEG-025 | Setup incomplete but module used | SETUP_INCOMPLETE |

## Evidence Required Per Negative Test
```text
Test name
Test user/role
Tenant/entity used
API endpoint or UI screen
Request sample
Response sample
Screenshot/log/test output
Commit hash
```

## Rule
```text
A feature without negative tests is not production-ready, even if the happy path works.
```
