# Evaluation Order and Dependency Direction Rules

## 1. Request Evaluation Order

Every request must be evaluated in this order:

```text
1. Tenant active?
2. Subscription tier entitled?
3. Module enabled?
4. Feature flag enabled?
5. Runtime mode valid?
6. User authenticated?
7. User has permission?
8. Entity visibility allowed?
9. Record visibility allowed?
10. Privacy policy allows?
11. Approval required?
12. Audit recorded?
```

## 2. Critical Rules

```text
Passing permission does not override subscription entitlement.
Passing entitlement does not override permission.
Passing module enablement does not override privacy restriction.
Passing runtime mode does not override idempotency, audit, privacy, or evidence.
Frontend visibility is not backend authorization.
```

## 3. Dependency Direction

Allowed direction:

```text
Platform Core
    ↓
Shared Business Core Services
    ↓
Domain Modules
    ↓
External Integrations / UI / AI Consumers
```

## 4. Forbidden Dependencies

```text
Platform Core depends on Accounting.
Contact Master directly queries Accounting invoices.
CRM directly queries HR staff private data.
Dashboard directly queries all module tables.
AI reads raw module tables.
Domain module recreates audit, numbering, attachment, workflow, or permission engine.
```

## 5. Correct Patterns

```text
Accounting consumes Contact Master API.
CRM consumes Contact Master API.
Contact 360 uses Related Records Registry.
Dashboard uses Report Registry or approved summary APIs.
AI uses AI Context Builder.
External connector uses Connector Registry and Idempotency Service.
Domain module publishes events for related record summaries.
```
