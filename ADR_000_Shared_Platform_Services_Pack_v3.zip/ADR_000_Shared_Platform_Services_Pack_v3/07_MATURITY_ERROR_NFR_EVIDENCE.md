# Maturity Model, Error Standard, NFR Baseline, and Evidence Pack

## 1. Shared Service Maturity Model

| Level | Name | Meaning |
|---:|---|---|
| L0 | Not Implemented | No usable implementation |
| L1 | Registry / Contract Only | Declared but no production API |
| L2 | Basic API | API exists with basic validation and permission |
| L3 | Evidence-Ready | API, permission, audit, positive/negative tests, evidence |
| L4 | Multi-Tenant Production-Grade | Tenant/entity isolation, monitoring, rollback, performance, safe errors |
| L5 | Enterprise-Grade | Admin UI, policy control, enterprise monitoring, migration support, support evidence |

Completion claim must state maturity level.

## 2. Error Response Standard

```json
{
  "success": false,
  "error": {
    "code": "MODULE_NOT_ENABLED",
    "message": "This module is not enabled for this tenant.",
    "details": {},
    "request_id": "REQ-2026-000001"
  }
}
```

Mandatory error codes:

```text
TENANT_ACCESS_DENIED
ENTITY_ACCESS_DENIED
PERMISSION_DENIED
MODULE_NOT_ENABLED
FEATURE_NOT_ENTITLED
RUNTIME_MODE_INVALID
VALIDATION_FAILED
DUPLICATE_RECORD
IDEMPOTENCY_REPLAY
RESTRICTED_DATA_DENIED
APPROVAL_REQUIRED
EXTERNAL_SYNC_FAILED
SYSTEM_ERROR
```

No raw route, stack trace, SQL/ORM error, token, secret, file path, or infrastructure error may be shown to users.

## 3. Non-Functional Requirements Baseline

Minimum baseline:

```text
Tenant isolation on every query
Entity isolation where applicable
Backend permission enforcement
Standard error response
Request ID propagation
Audit event for sensitive actions
Idempotency for external writes and retries
Database indexes for primary filters
Migration fresh-run evidence
Rollback evidence
Positive tests
Negative tests
Known limitation list
Observability/logging
Safe timeout and retry behaviour
Export expiry where applicable
Restricted data masking where applicable
```

Per-service measurable NFRs must include where applicable:

```text
availability target
backup frequency
restore time objective
restore point objective
API latency target
background job retry policy
audit retention
log retention
file retention
export expiry
rate limits
maximum import size
maximum export size
maximum attachment size
concurrency control
record locking
```

## 4. Evidence Pack Standard

Minimum evidence pack:

```text
Git branch name
commit hash
file diff
migration files
migration fresh-run output
migration rollback output
database schema
index list
route list
API request/response samples
permission test evidence
tenant isolation evidence
entity visibility evidence
audit log samples
idempotency evidence where applicable
privacy/masking evidence where applicable
AI policy evidence where applicable
positive test result
negative test result
safe error response samples
observability/logging evidence
known limitation list
```

Generic statements such as “tested successfully” are rejected.
