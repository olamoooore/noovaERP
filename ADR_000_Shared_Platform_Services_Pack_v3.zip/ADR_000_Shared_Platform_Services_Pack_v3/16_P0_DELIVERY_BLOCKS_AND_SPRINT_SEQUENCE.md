# ADR 000 v3 — P0 Delivery Blocks and Sprint Sequence

## Purpose
P0 contains many services. Junior teams must not attempt to build all P0 services randomly. This file converts P0 into delivery blocks.

## Rule
```text
Do not start a later P0 block if earlier block foundations are missing, unless architecture owner approves controlled parallel delivery.
```

## P0-A — Tenant, Entity, User, Permission, Audit
**Objective:** Establish minimum secure platform boundary.

### Included Services
Tenant Management, Entity Management, User Management, RBAC, Record-Level Access, Permission Evaluation, Authentication, Audit Trail, System Log.

### Acceptance
- Tenant isolation enforced.
- Entity visibility enforced.
- Backend permission enforced.
- Audit recorded for create/update/delete/security actions.
- Standard errors returned.

### Required Negative Tests
Wrong tenant blocked, wrong entity blocked, no permission blocked, raw error not shown.

---

## P0-B — Module Registry, Entitlement, Feature Flag, Runtime Mode
**Objective:** Prevent modules from becoming uncontrolled silos.

### Included Services
Module Registry, Module Contract, Module Enablement, Feature Flag, Subscription Entitlement, Runtime Mode declaration.

### Acceptance
- No module enabled without entitlement.
- No module goes live without contract.
- Runtime mode declared.
- Dependencies validated.

---

## P0-C — Contact Master Shared Identity
**Objective:** Prevent disconnected customer/vendor/staff/member/tenant records.

### Included Services
Contact Master, Contact Roles, Contact Identifiers, Contact Addresses, Contact Methods, Contact Relationships, Contact Visibility, Contact Profile Registry.

### Acceptance
- No disconnected master table.
- Every module profile links to `core_contact_uuid`.
- Search/visibility/audit/privacy enforced.

---

## P0-D — Numbering, Files, Templates, Error Standard
**Objective:** Standardize documents and user-facing outputs.

### Included Services
Document Numbering, Document Template, File Attachment, PDF Generation, Email/Notice Templates, Error Response Standard.

### Acceptance
- Modules do not build their own numbering/file/template engines.
- File access follows classification.
- Errors use standard response.

---

## P0-E — API Gateway, Idempotency, External References, Event Bus
**Objective:** Prevent duplicate writes and unsafe integrations.

### Included Services
API Gateway, Webhook Manager, Connector Registry, External Reference Mapping, Idempotency Keys, Domain Event Bus, Retry Policy, Error Queue.

### Acceptance
- Webhook replay does not create duplicates.
- External references unique.
- Failed jobs visible.
- Events follow versioned contract.

---

## P0-F — Workflow, Approval, Task, Exception Queue
**Objective:** Ensure sensitive actions follow controlled process.

### Included Services
Workflow Status Engine, Approval Workflow, Approval Policy, Task/Reminder, Escalation, Exception Management.

### Acceptance
- Approval required actions cannot bypass approval.
- Exceptions require owner, reason, expiry, refactor plan.

---

## P0-G — Search, Related Records, Report Registry
**Objective:** Prevent direct cross-module drill-down.

### Included Services
Global Search, Search Index, Related Records Registry, Smart Buttons, Report Registry, Navigation Registry.

### Acceptance
- Related counts are permission-aware.
- No direct cross-module table query.
- Reports use registry and export controls.

---

## P0-H — AI Access Boundary, Data Quality, Evidence Pack
**Objective:** Prepare AI safely and force proof of completion.

### Included Services
AI Access Control, AI Context Builder, AI Reasoning Record, AI Approval Control, Data Quality Rules, Data Quality Scores, Evidence Pack.

### Acceptance
- AI cannot read raw tables.
- Restricted data excluded.
- Evidence pack required for completion.

---

## P0-I — Observability, Release, Architecture Compliance
**Objective:** Make production releases monitorable and reviewable.

### Included Services
Performance Monitoring, Product Telemetry, Integration Health, Backup/Restore, Release Management, Environment Management, Architecture Compliance Review.

### Acceptance
- Deployment has rollback evidence.
- Monitoring exists.
- Existing code classified before broad expansion.

## Sprint Usage Rule
Each sprint must state:
```text
Delivery block
Services included
User roles affected
APIs built
UI screens built
Positive tests
Negative tests
Evidence pack
Known limitations
```
