# Engineer Implementation Instruction — ADR 000

Use this as direct instruction to the engineer.

```text
ADR 000 defines AceNova shared platform services.

Do not implement shared services separately inside Accounting, CRM, Sales, Purchase, Inventory, POS, HR, Property, Project, Portal, Membership, Loyalty, or External Integration modules.

Shared services are platform-owned.
Domain modules consume shared services and own only domain-specific business logic.

Every shared service must have a Shared Service Contract.
Every domain module must have a Module Contract.

Every module must declare runtime mode:
- Coupled Mode
- Decoupled Mode
- External Integration Mode

Do not confuse runtime mode with subscription tier.

Subscription tiers are:
- Enterprise Custom
- Enterprise Standard
- SME Growth
- SME Essential

Modules must call Entitlement Service.
Modules must not hardcode subscription tier rules.

Every request must follow this evaluation order:
1. Tenant active?
2. Subscription tier entitled?
3. Module enabled?
4. Feature flag enabled?
5. Runtime mode valid?
6. User authenticated?
7. User has permission?
8. Entity visibility allowed?
9. Record visibility allowed?
10. Privacy policy allows?
11. Approval required?
12. Audit recorded?

No direct cross-module table access is allowed.
Use approved APIs, events, registry, or governed summary contracts.

No AI feature may read raw module tables directly.
AI must consume policy-filtered context only.

No external write is accepted without external reference and idempotency control.

No production module release is accepted without:
- module contract
- shared service dependency list
- tenant/entity isolation tests
- backend permission tests
- positive tests
- negative tests
- safe error response samples
- audit evidence
- idempotency evidence where applicable
- known limitation list

Do not claim completion using generic statements.
Claims must state maturity level and attach evidence.
```
