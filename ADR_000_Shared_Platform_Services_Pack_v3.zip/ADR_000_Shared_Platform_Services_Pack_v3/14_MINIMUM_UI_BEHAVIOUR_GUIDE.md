# ADR 000 v3 — Minimum UI Behaviour Guide

## Purpose
This file prevents junior engineers from creating generic tables/forms that do not serve user workflows.

## UI Rule
```text
Every UI must explain status, next action, permission result, and error recovery.
A screen that only displays database rows is not accepted for workflow features.
```

## Required Standard UI Patterns

| UI Situation | Required Behaviour | Not Accepted |
|---|---|---|
| Permission Denied | Show safe message, required permission, request ID, no sensitive data | Blank page or raw 403 stack error |
| Module Not Enabled | Explain module disabled, show who can enable, link setup if allowed | Generic “not found” |
| Feature Not Entitled | Explain feature not included in current subscription tier | Hidden failure |
| Approval Required | Show approval status, approver, reason box, history | Silent block |
| Setup Incomplete | Show checklist with Pass/Warning/Fail and Fix buttons | One generic error message |
| Validation Error | Show field-level errors and correction guidance | Raw database constraint error |
| Duplicate Warning | Show candidate summary, match reason, safe restricted masking | Auto-merge or ignore |
| Import Staging | Show uploaded rows, errors, warnings, duplicate candidates, confirm action | Direct import into live table |
| Audit Trail | Show actor, timestamp, action, old/new value where allowed, request ID | Simple text log only |
| Evidence Pack | Show branch, commit, tests, screenshots, limitations, reviewer status | Free-text “done” note |
| Error Queue | Show failed job/event, reason, retry/cancel/investigate actions | Hidden background failures |
| Job Status | Show queued/running/succeeded/failed, progress, retry count | No feedback after submit |
| Tenant Health | Show setup/integration/security/data/job health | No admin health view |
| Data Quality Warning | Show issue, severity, affected record, fix action, owner | Red icon without explanation |
| AI Suggestion | Show AI suggestion, data sources summary, approval requirement, accept/reject | AI writes directly without review |

## Setup Checklist UI Minimum
Each setup checklist item must show:
```text
Status: Pass / Warning / Failed / Not Started
Owner role
Why this matters
Fix action
Last checked time
Audit link if changed
```

## Error Screen Minimum
Every error screen must show:
```text
User-safe message
Error code
Request ID
Suggested next action
No raw stack trace
No database table/column leak
```

## Approval UI Minimum
Every approval screen must show:
```text
Requested action
Requester
Approver
Reason required
Business impact
Approval history
Approve / Reject buttons
Audit reference
```

## Import UI Minimum
Every import staging screen must show:
```text
Batch ID
Total rows
Valid rows
Error rows
Warning rows
Duplicate candidates
Confirm live write button
Rollback reference after posting
```
