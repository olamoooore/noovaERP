# Subscription Tier Entitlement Matrix

Subscription tier controls commercial entitlement. It is not module runtime mode.

| Tier | Purpose | Configuration Depth | Support Level | Customization | Typical Controls |
|---|---|---|---|---|---|
| Enterprise Custom | Large clients requiring custom deployment/process | High | Custom SLA | High | custom modules, higher limits, private workflows, custom integrations |
| Enterprise Standard | Enterprise-ready standard package | Medium-high | Enterprise SLA | Controlled | enterprise controls, SSO/SoD, more entities, advanced audit |
| SME Growth | Growing SME requiring broader modules | Medium | Standard | Limited | multi-module access, practical automation, standard limits |
| SME Essential | Basic SME package | Low | Basic | Minimal | limited modules, simple setup, lower usage limits |

## Entitlement Categories

```text
module entitlement
feature entitlement
user limit
entity limit
storage limit
API limit
AI usage limit
integration limit
support SLA
customization allowance
setup assistance level
export limit
import limit
```

## Required Rule

```text
Modules must call Entitlement Service.
Modules must not hardcode subscription tier rules internally.
```

## Interpretation

```text
Enterprise / SME tier controls what the tenant may use.
Coupled / Decoupled / External Integration Mode controls how a module integrates.
Permission controls what a user may do.
Visibility controls what record the user may see.
Privacy controls what data may be exposed.
```
