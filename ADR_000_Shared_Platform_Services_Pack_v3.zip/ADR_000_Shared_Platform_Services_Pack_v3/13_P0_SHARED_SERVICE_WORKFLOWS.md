# ADR 000 v3 — P0 Shared Service Workflows

## Purpose
This file converts P0 architecture services into real workflows. Junior engineers must build workflow behaviour, not isolated generic CRUD tables.

## Standard Workflow Format
Each P0 workflow must define:
```text
Actor
Trigger
Preconditions
Steps
Expected Result
Failure Cases
Audit Events
Evidence Required
```

---

# Workflow 1 — Tenant Creation
**Actor:** Platform Owner / Sales Operations / Tenant Owner  
**Trigger:** New customer tenant is approved.

## Preconditions
- Subscription tier selected.
- Tenant owner email verified.
- Initial tenant name and country set.

## Steps
1. Create tenant record.
2. Assign subscription tier.
3. Create tenant owner user.
4. Apply default tenant policy.
5. Create default entity if required.
6. Create audit event.
7. Generate setup checklist.

## Expected Result
Tenant exists, owner can log in, setup checklist is visible.

## Failure Cases
- Duplicate tenant slug.
- Invalid subscription tier.
- Tenant owner email already linked incorrectly.

## Audit Events
`tenant.created`, `subscription.assigned`, `tenant.owner_assigned`.

---

# Workflow 2 — Entity Setup
**Actor:** Tenant Admin / Entity Admin

## Steps
1. Add legal entity, branch, outlet, or department.
2. Validate entity belongs to tenant.
3. Assign entity admin.
4. Apply inherited tenant settings.
5. Record entity audit.

## Failure Cases
- User creates entity outside tenant.
- Duplicate entity code.
- Missing required registration/tax information where policy requires.

---

# Workflow 3 — User Invitation and Permission Assignment
**Actor:** Tenant Admin / Entity Admin

## Steps
1. Invite user by email.
2. Select role.
3. Select entity/department access.
4. System checks entitlement user limit.
5. User accepts invitation.
6. User status becomes active.
7. Audit invitation and role assignment.

## Failure Cases
- User limit exceeded.
- Role assignment exceeds inviter authority.
- Entity access invalid.

---

# Workflow 4 — Module Enablement
**Actor:** Tenant Admin

## Correct Workflow
```text
Tenant subscription checked
→ Module entitlement checked
→ Module contract loaded
→ Dependencies checked
→ Runtime mode selected
→ Setup pack loaded
→ Setup validation run
→ Navigation updated
→ Audit recorded
```

## Failure Cases
- Module not entitled.
- Required dependency missing.
- Invalid runtime mode.
- Setup validation failed.

## Wrong Implementation
```text
Create a simple ON/OFF toggle only.
```

---

# Workflow 5 — Feature Flag Check
**Actor:** Any API request

## Steps
1. Confirm tenant active.
2. Confirm subscription tier entitlement.
3. Confirm module enabled.
4. Confirm feature flag enabled for tenant/entity/user if applicable.
5. Continue only if all pass.

## Failure Case
Return `FEATURE_NOT_ENABLED` or `FEATURE_NOT_ENTITLED` with standard error format.

---

# Workflow 6 — Runtime Mode Declaration
**Actor:** Platform Architect / Module Owner

## Steps
1. Register module contract.
2. Select runtime mode: Coupled, Decoupled, or External Integration.
3. Declare owned data and consumed services.
4. Declare APIs/events/external references/idempotency.
5. Submit architecture review evidence.

## Failure Cases
- Missing contract.
- Runtime mode conflicts with data ownership.
- External mode lacks external reference mapping.

---

# Workflow 7 — Contact Master Creation
**Actor:** Allowed business user

## Steps
1. Check tenant, module, permission, entity visibility.
2. Create `core_contact`.
3. Assign role if requested through explicit role API.
4. Assign identifier if requested through explicit identifier API.
5. Add address/method if provided.
6. Record audit.

## Wrong Implementation
```text
Accounting creates customer_master directly.
```

---

# Workflow 8 — Document Numbering Usage
**Actor:** Any document-creating module

## Steps
1. Module requests next number from Document Numbering Service.
2. Service validates tenant, entity, module, sequence rule.
3. Number is reserved/assigned atomically.
4. Document saves with assigned number.
5. Audit number generation.

## Failure Cases
- No active sequence.
- Duplicate sequence collision.
- Entity/module mismatch.

---

# Workflow 9 — File Upload
**Actor:** User / Portal User / Integration

## Steps
1. Upload file.
2. Validate size/type/security policy.
3. Apply classification and access policy.
4. Link file to allowed record.
5. Audit upload.

## Failure Cases
- Restricted file uploaded without permission.
- File linked to wrong tenant/entity.
- Unsupported file type.

---

# Workflow 10 — Approval Request
**Actor:** Business User / AI / Automation

## Steps
1. User triggers sensitive action.
2. Policy engine determines approval required.
3. Approval request created.
4. Approver notified.
5. Approver approves/rejects.
6. Action proceeds only if approved.
7. Audit full decision path.

---

# Workflow 11 — External Webhook Write
**Actor:** External system

## Steps
1. Receive webhook.
2. Validate signature/source.
3. Check external reference.
4. Check idempotency key.
5. If replay, return previous result safely.
6. Process event.
7. Record audit and integration log.

## Failure Cases
- Invalid signature.
- Duplicate external reference conflict.
- Idempotency replay creates duplicate — must be blocked.

---

# Workflow 12 — AI Context Request
**Actor:** AI Service Account / User using AI

## Steps
1. Identify requesting user.
2. Check tenant/entity/user permission.
3. Load AI policy.
4. Build filtered context.
5. Exclude restricted/prohibited fields.
6. Record AI reasoning/audit event.
7. Return context summary, not raw tables.

## Failure Cases
- AI raw table access.
- Restricted HR/private data included.
- No reasoning record.

---

# Workflow 13 — Evidence Pack Submission
**Actor:** Engineer

## Steps
1. Attach branch and commit hash.
2. Attach migration evidence.
3. Attach API samples.
4. Attach positive tests.
5. Attach negative tests.
6. Attach screenshots where UI exists.
7. List known limitations.
8. Submit for review.

## Failure Case
Written explanation without evidence is rejected.
